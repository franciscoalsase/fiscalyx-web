import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        brand: {
          dark: '#0B1120',    // Negro azulado
          blue: '#0F62FE',    // Azul Tech
          gold: '#C9A227',    // Dorado
          surface: '#F8FAFC'  // Blanco roto
        }
      },
      fontFamily: {
        sans: ['var(--font-jakarta)', 'sans-serif'],
      }
    },
  },
  plugins: [],
};
export default config;
