import Link from "next/link";
import { Logo } from '@/components/Logo';
import { Footer } from '@/components/Footer';
import { FadeIn } from '@/components/FadeIn';

export const metadata = {
  title: 'Sobre Fiscalyx | Economistas y Abogados en Alicante',
  description: 'Conoce al equipo detrás de Fiscalyx. 30 años de experiencia en Callosa de Segura evolucionados a la asesoría online líder.',
}

export default function NosotrosPage() {
  return (
    <main className="font-sans text-slate-600 bg-white min-h-screen">
      
      <nav className="sticky top-0 z-50 bg-white/95 backdrop-blur border-b border-slate-100 shadow-sm">
        <div className="max-w-7xl mx-auto px-6 h-20 flex justify-between items-center">
          <Link href="/"><Logo /></Link>
          <Link href="/" className="text-sm font-bold text-brand-blue hover:text-brand-dark transition">← Volver</Link>
        </div>
      </nav>

      {/* HERO HISTORIA */}
      <header className="py-20 px-6 bg-slate-900 text-white text-center">
        <FadeIn direction="up">
            <h1 className="text-4xl md:text-6xl font-extrabold mb-6">No somos una App.<br/>Somos Asesores con Tecnología.</h1>
            <p className="text-xl text-slate-300 max-w-2xl mx-auto leading-relaxed">
                Fiscalyx nace de la evolución de un despacho tradicional con 30 años de historia en la Vega Baja. 
                Mantenemos el rigor del economista colegiado, pero eliminamos el papel y los desplazamientos.
            </p>
        </FadeIn>
      </header>

      {/* LOS SOCIOS */}
      <section className="py-24 px-6 max-w-6xl mx-auto">
        <div className="grid md:grid-cols-2 gap-16 items-center">
            <FadeIn direction="right">
                <img src="https://images.unsplash.com/photo-1556157382-97eda2d62296?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" className="rounded-2xl shadow-2xl" alt="Socios Fiscalyx" />
            </FadeIn>
            
            <FadeIn direction="left">
                <h2 className="text-3xl font-bold text-brand-dark mb-6">El Equipo Directivo</h2>
                
                <div className="mb-8">
                    <h3 className="text-xl font-bold text-brand-blue">Francisco Seva Soriano</h3>
                    <p className="text-sm font-bold text-brand-dark mb-2">Socio Director | Área Fiscal</p>
                    <p className="text-slate-600 mb-2">Economista Colegiado Nº 4174 y Ejerciente Nº 1761.</p>
                    <p className="text-sm text-slate-500">"Mi obsesión es que el cliente entienda sus números. La tecnología nos permite dedicar el tiempo a asesorar, no a picar datos."</p>
                </div>

                <div className="border-t border-slate-100 pt-8">
                    <h3 className="text-xl font-bold text-brand-gold">Emilio Escudero Soler</h3>
                    <p className="text-sm font-bold text-brand-dark mb-2">Socio Director | Área Jurídica</p>
                    <p className="text-slate-600 mb-2">Abogado experto en Derecho Mercantil y Sucesiones.</p>
                    <p className="text-sm text-slate-500">"Blindamos jurídicamente a nuestros clientes. Desde la constitución de la sociedad hasta la planificación de herencias."</p>
                </div>
            </FadeIn>
        </div>
      </section>

      {/* VALORES */}
      <section className="bg-slate-50 py-20 px-6 text-center">
        <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold text-brand-dark mb-12">Nuestros 3 Pilares</h2>
            <div className="grid md:grid-cols-3 gap-8">
                <div className="bg-white p-6 rounded-xl shadow-sm">
                    <div className="text-4xl mb-4">🚀</div>
                    <h3 className="font-bold text-brand-dark mb-2">Velocidad</h3>
                    <p className="text-sm text-slate-500">Respuestas en menos de 24h. Trámites telemáticos inmediatos.</p>
                </div>
                <div className="bg-white p-6 rounded-xl shadow-sm">
                    <div className="text-4xl mb-4">🔒</div>
                    <h3 className="font-bold text-brand-dark mb-2">Seguridad</h3>
                    <p className="text-sm text-slate-500">Tus datos encriptados y seguro de Responsabilidad Civil incluido.</p>
                </div>
                <div className="bg-white p-6 rounded-xl shadow-sm">
                    <div className="text-4xl mb-4">🤝</div>
                    <h3 className="font-bold text-brand-dark mb-2">Cercanía</h3>
                    <p className="text-sm text-slate-500">Digitales, pero si nos llamas, te contesta tu asesor, no una máquina.</p>
                </div>
            </div>
        </div>
      </section>

      <Footer />
    </main>
  );
}