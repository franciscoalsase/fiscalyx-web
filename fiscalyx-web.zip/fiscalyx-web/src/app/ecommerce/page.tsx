import Link from "next/link";
import { Logo } from '@/components/Logo';
import { Footer } from '@/components/Footer';

export const metadata = {
  title: 'Asesoría Amazon FBA y E-commerce | Expertos en IVA OSS y Dropshipping',
  description: 'Gestoría especializada en vendedores de Amazon, Shopify y Dropshipping. Gestionamos tu IVA intracomunitario (OSS) y tus importaciones. Servicio 100% Online.',
}

export default function EcommercePage() {
  return (
    <main className="font-sans text-slate-600 bg-white min-h-screen">
      
      {/* NAV */}
      <nav className="sticky top-0 z-50 bg-white/95 backdrop-blur border-b border-slate-100 shadow-sm">
        <div className="max-w-7xl mx-auto px-6 h-20 flex justify-between items-center">
          <Link href="/" className="z-50"><Logo /></Link>
          <Link href="/" className="text-sm font-bold text-brand-blue hover:text-brand-dark transition">← Volver al Inicio</Link>
        </div>
      </nav>

      {/* HERO E-COMMERCE */}
      <header className="relative pt-20 pb-32 overflow-hidden bg-slate-900 text-white">
        <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-orange-500/10 rounded-full blur-[120px] -translate-y-1/2 translate-x-1/2"></div>
        
        <div className="max-w-7xl mx-auto px-6 relative z-10 grid lg:grid-cols-2 gap-12 items-center">
            <div>
                <span className="inline-block py-1 px-3 rounded-full bg-orange-500/20 border border-orange-400/30 text-orange-300 text-xs font-bold uppercase tracking-widest mb-6">
                    Especialistas en Negocio Digital
                </span>
                <h1 className="text-4xl md:text-6xl font-extrabold mb-6 leading-tight">
                    Tú vendes en <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-yellow-200">Amazon</span>.<br/>
                    Nosotros nos peleamos con Hacienda.
                </h1>
                <p className="text-lg text-slate-300 mb-8 leading-relaxed">
                    Vender online implica IVA intracomunitario, Ventanilla Única (OSS) y aduanas. 
                    No dejes que la burocracia frene tu escalabilidad.
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                    <Link href="/presupuesto" className="px-8 py-4 bg-orange-600 hover:bg-orange-500 text-white font-bold rounded-xl shadow-lg transition text-center">
                        Pedir Presupuesto FBA
                    </Link>
                    <Link href="/cita" className="px-8 py-4 bg-white/10 hover:bg-white/20 text-white font-bold rounded-xl border border-white/10 transition text-center">
                        Agendar Llamada
                    </Link>
                </div>
            </div>
            
            {/* IMAGEN LOGÍSTICA */}
            <div className="relative rounded-2xl overflow-hidden shadow-2xl border border-white/10 h-[400px]">
                <img src="https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80" alt="Logística E-commerce" className="object-cover w-full h-full hover:scale-105 transition duration-700"/>
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 to-transparent"></div>
                <div className="absolute bottom-6 left-6">
                    <p className="text-white font-bold text-lg">Logística Internacional</p>
                    <p className="text-slate-400 text-xs">Control de IVA en import/export</p>
                </div>
            </div>
        </div>
      </header>

      {/* PUNTOS DE DOLOR (LO QUE TÚ RESUELVES) */}
      <section className="py-20 px-6 max-w-7xl mx-auto">
        <div className="text-center mb-16">
            <h2 className="text-3xl font-extrabold text-brand-dark">El caos fiscal del E-commerce, resuelto.</h2>
            <p className="text-slate-500 mt-4 max-w-2xl mx-auto">El 90% de las gestorías tradicionales no saben qué es el OSS o cómo contabilizar una factura de Amazon Luxemburgo. Nosotros sí.</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
            <div className="p-8 border border-slate-100 rounded-2xl hover:shadow-xl transition bg-white group">
                <div className="text-4xl mb-4 group-hover:scale-110 transition duration-300">📦</div>
                <h3 className="font-bold text-xl text-brand-dark mb-3">Amazon FBA y Pan-EU</h3>
                <p className="text-sm text-slate-500">Si almacenas stock en Alemania o Francia, tienes obligaciones fiscales allí. Te ayudamos a gestionar el IVA paneuropeo sin volverte loco.</p>
            </div>

            <div className="p-8 border border-slate-100 rounded-2xl hover:shadow-xl transition bg-white group">
                <div className="text-4xl mb-4 group-hover:scale-110 transition duration-300">🌍</div>
                <h3 className="font-bold text-xl text-brand-dark mb-3">Ventanilla Única (OSS)</h3>
                <p className="text-sm text-slate-500">¿Vendes más de 10.000€ a particulares en Europa? Debes darte de alta en el OSS. Nosotros presentamos el Modelo 369 por ti cada trimestre.</p>
            </div>

            <div className="p-8 border border-slate-100 rounded-2xl hover:shadow-xl transition bg-white group">
                <div className="text-4xl mb-4 group-hover:scale-110 transition duration-300">🛒</div>
                <h3 className="font-bold text-xl text-brand-dark mb-3">Shopify y Dropshipping</h3>
                <p className="text-sm text-slate-500">¿Compras en China y vendes en España? Gestionamos las facturas de proveedores extracomunitarios y el Recargo de Equivalencia si eres minorista.</p>
            </div>
        </div>
      </section>

      {/* FAQ ECOMMERCE */}
      <section className="bg-slate-50 py-20 px-6">
        <div className="max-w-3xl mx-auto">
            <h2 className="text-2xl font-bold text-brand-dark mb-8 text-center">Dudas frecuentes de vendedores</h2>
            <div className="space-y-4">
                <details className="bg-white p-6 rounded-xl shadow-sm cursor-pointer">
                    <summary className="font-bold text-brand-dark">¿Tengo que darme de alta si vendo poco?</summary>
                    <p className="text-sm text-slate-600 mt-2">Sí. La Seguridad Social obliga al alta si es habitual, aunque no llegues al SMI. Hacienda obliga desde el primer euro. No te arriesgues.</p>
                </details>
                <details className="bg-white p-6 rounded-xl shadow-sm cursor-pointer">
                    <summary className="font-bold text-brand-dark">¿Qué hago con las facturas de Amazon?</summary>
                    <p className="text-sm text-slate-600 mt-2">Amazon emite facturas complejas (con y sin IVA según el país). Nosotros descargamos tus informes y los procesamos correctamente.</p>
                </details>
            </div>
        </div>
      </section>

      {/* CTA FINAL */}
      <section className="bg-brand-dark py-20 text-center text-white">
        <div className="max-w-4xl mx-auto px-6">
            <h2 className="text-3xl font-extrabold mb-6">¿Tu negocio escala, pero tu gestoría no?</h2>
            <p className="text-slate-400 mb-8 text-lg">Pásate a Fiscalyx y ten tus números controlados.</p>
            <Link href="/presupuesto" className="inline-block bg-orange-600 hover:bg-orange-500 text-white font-bold py-4 px-10 rounded-xl transition shadow-xl">
                SOLICITAR PRESUPUESTO
            </Link>
        </div>
      </section>

      <Footer />
    </main>
  );
}