import { MetadataRoute } from 'next'
 
export default function robots(): MetadataRoute.Robots {
  return {
    rules: {
      userAgent: '*',
      disallow: '/', // 👈 ESTO BLOQUEA A GOOGLE (Cámbialo a allow: '/' el día del lanzamiento)
    },
    sitemap: 'https://fiscalyx.com/sitemap.xml',
  }
}