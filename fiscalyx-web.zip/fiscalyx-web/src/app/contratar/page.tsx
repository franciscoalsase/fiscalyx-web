'use client';

import { useState, useEffect, Suspense } from 'react'; 
import { useSearchParams } from 'next/navigation'; 
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { FadeIn } from '@/components/FadeIn';

// Definimos la estructura de los planes para evitar errores de TypeScript
interface Plan {
  name: string;
  price: number;
  basePeriod: string;
  description: string;
  features: string[];
  cta: string;
  popular: boolean;
  stripeLink: string;
  highlight?: boolean;
  customAction?: boolean;
}

// --- CONFIGURACIÓN DE PLANES AUTÓNOMOS ---
const PLANES_AUTONOMO: Plan[] = [
  {
    name: 'Basic',
    price: 59,
    basePeriod: 'monthly',
    description: 'La gestión esencial automatizada. Para autónomos digitales que quieren dormir tranquilos sin pagar de más.',
    features: [
        'Presentación Impuestos (303, 130, 390)', 
        'Licencia Software Incluida', 
        'Contabilidad Bancaria Automática', 
        'Soporte Email en <24h',
        '+ Laboral opcional (15€/empl)'
    ],
    cta: 'Empezar Basic',
    popular: false,
    stripeLink: 'https://buy.stripe.com/tu-link-basic' 
  },
  {
    name: 'Pro',
    price: 89,
    basePeriod: 'monthly',
    description: 'Tu propio Director Financiero. Un economista colegiado vigila tus números y te atiende por WhatsApp.',
    features: [
        'Todo lo incluido en el plan Basic', 
        'WhatsApp Directo con tu Asesor', 
        'Declaración Renta (Mod 100) Incluida', 
        'Revisión Proactiva de Gastos', 
        'Planificación Fiscal Pre-Cierre',
        '+ Laboral opcional (15€/empl)'
    ],
    cta: 'Empezar Pro',
    popular: true,
    stripeLink: 'https://buy.stripe.com/tu-link-pro' 
  }
];

// --- CONFIGURACIÓN DE PLANES EMPRESA ---
const PLANES_EMPRESA: Plan[] = [
  {
    name: 'Startup',
    price: 129,
    basePeriod: 'monthly',
    description: 'Para S.L. de servicios o patrimoniales que necesitan cumplir con todo el rigor mercantil.',
    features: [
        'Fiscalidad S.L. Completa', 
        'Impuesto Sociedades (200)', 
        'Cuentas Anuales y Libros', 
        '1 Nómina Incluida',
        'Gestión Notificaciones NEOS'
    ],
    cta: 'Contratar Startup',
    popular: false,
    stripeLink: '#' 
  },
  {
    name: 'Crecimiento',
    price: 249,
    basePeriod: 'monthly',
    description: 'Para Pymes con equipo que necesitan control de costes y gestión laboral integrada.',
    features: [
        'Todo lo del plan Startup', 
        'Gestión Laboral hasta 5 empleados', 
        'Portal del Empleado', 
        'Reunión Mensual de Estrategia', 
        'Analítica de Costes'
    ],
    cta: 'Elegir Plan',
    popular: true,
    stripeLink: '#' 
  },
  {
    name: 'Gran Empresa',
    price: 0, // Se muestra como "Consultar"
    basePeriod: 'custom',
    description: 'Soluciones a medida para facturaciones >1M€, Holdings o Ecommerce internacional.',
    features: [
        'Consolidación Fiscal', 
        'Auditoría Interna', 
        'Operaciones Vinculadas', 
        'Fiscalidad Internacional (IVA OSS)',
        'Abogado Mercantilista Asignado'
    ],
    cta: 'Pedir Presupuesto',
    popular: false,
    customAction: true, 
    stripeLink: '#' 
  }
];

// --- CONFIGURACIÓN DE PLANES CRIPTO (SEPARADO) ---
const PLANES_CRIPTO: Plan[] = [
    {
      name: 'Pack HODL',
      price: 150,
      basePeriod: 'annual',
      description: 'Para inversores pasivos que solo compran y mantienen (Holding) con pocas operaciones.',
      features: [
          'Hasta 50 transacciones anuales',
          'Informe Fiscal Renta',
          'Resolución de dudas básicas',
          'Software NO incluido'
      ],
      cta: 'Contratar HODL',
      popular: false,
      stripeLink: '#' 
    },
    {
      name: 'Trader Pro',
      price: 350,
      basePeriod: 'annual',
      description: 'Blindaje total. Auditoría experta de tu operativa DeFi/Staking para evitar sanciones.',
      features: [
          'Hasta 3.500 transacciones anuales',
          'Informe Fiscal Anti-Sanciones', 
          'Modelo 714 (Patrimonio) Incluido', 
          'Licencia CoinTracking Pro (Ahorras 200€)',
          'Soporte Operativo por Videollamada'
      ],
      cta: 'Auditar Cripto',
      popular: true,
      highlight: true, 
      stripeLink: 'https://buy.stripe.com/tu-link-cripto' 
    },
    {
      name: 'DeFi Whale',
      price: 0,
      basePeriod: 'custom',
      description: 'Para grandes volúmenes, Farming complejo, NFTs y casuísticas especiales.',
      features: [
          'Transacciones Ilimitadas',
          'Análisis de Smart Contracts',
          'Trazabilidad manual de fondos',
          'Planificación de salida a FIAT',
          'Defensa jurídica incluida'
      ],
      cta: 'Consultar Caso',
      popular: false,
      customAction: true,
      stripeLink: '#' 
    }
  ];

function ContratarContent() {
  const [billing, setBilling] = useState<'monthly' | 'annual'>('monthly');
  const [segment, setSegment] = useState<'autonomo' | 'empresa' | 'cripto'>('autonomo'); // Añadido 'cripto'
  
  const searchParams = useSearchParams();
  
  useEffect(() => {
    const tab = searchParams.get('tab');
    if (tab === 'empresa') setSegment('empresa');
    if (tab === 'cripto') setSegment('cripto'); // Detectar tab cripto
  }, [searchParams]);

  let activePlans = PLANES_AUTONOMO;
  if (segment === 'empresa') activePlans = PLANES_EMPRESA;
  if (segment === 'cripto') activePlans = PLANES_CRIPTO;

  // Lógica de Precios corregida
  const getDisplayPrice = (plan: Plan) => {
    if (plan.basePeriod === 'custom') return 'Consultar';
    if (plan.basePeriod === 'annual') return plan.price; 
    return billing === 'annual' ? plan.price * 10 : plan.price;
  };

  const getDisplayPeriod = (plan: Plan) => {
    if (plan.basePeriod === 'custom') return '';
    if (plan.basePeriod === 'annual') return '/año';
    return billing === 'annual' ? '/año' : '/mes';
  };

  return (
    <>
      <section className="pt-32 pb-20 text-center px-6">
        <FadeIn>
            <h1 className="text-4xl md:text-5xl font-black text-brand-dark mb-6">
              Invierte en tu tranquilidad fiscal
            </h1>
            <p className="text-xl text-slate-500 max-w-2xl mx-auto mb-10">
              Tecnología para ahorrar tiempo. Expertos para ahorrar dinero. <br/>
              Sin permanencia, cancela con un clic cuando quieras.
            </p>

            {/* SELECTOR SEGMENTO (AHORA SON 3) */}
            <div className="inline-flex flex-wrap justify-center bg-white p-1 rounded-xl border border-slate-200 shadow-sm mb-8 gap-1">
                <button 
                    onClick={() => setSegment('autonomo')}
                    className={`px-4 sm:px-6 py-2 rounded-lg text-sm font-bold transition-all ${segment === 'autonomo' ? 'bg-brand-blue text-white shadow-md' : 'text-slate-500 hover:text-brand-dark'}`}
                >
                    Soy Autónomo
                </button>
                <button 
                    onClick={() => setSegment('empresa')}
                    className={`px-4 sm:px-6 py-2 rounded-lg text-sm font-bold transition-all ${segment === 'empresa' ? 'bg-brand-dark text-white shadow-md' : 'text-slate-500 hover:text-brand-dark'}`}
                >
                    Soy Empresa (S.L.)
                </button>
                <button 
                    onClick={() => setSegment('cripto')}
                    className={`px-4 sm:px-6 py-2 rounded-lg text-sm font-bold transition-all ${segment === 'cripto' ? 'bg-purple-600 text-white shadow-md' : 'text-slate-500 hover:text-purple-600'}`}
                >
                    💎 Inversor Cripto
                </button>
            </div>

            {/* TOGGLE MENSUAL / ANUAL (Solo visible si no es Cripto, ya que Cripto es anual) */}
            {segment !== 'cripto' && (
                <div className="flex justify-center items-center gap-4 mb-16 animate-in fade-in">
                    <span className={`text-sm font-bold ${billing === 'monthly' ? 'text-brand-dark' : 'text-slate-400'}`}>Mensual</span>
                    <button 
                        onClick={() => setBilling(billing === 'monthly' ? 'annual' : 'monthly')}
                        className="w-14 h-8 bg-brand-blue rounded-full p-1 relative transition-colors duration-300 focus:outline-none"
                    >
                        <div className={`w-6 h-6 bg-white rounded-full shadow-md transform transition-transform duration-300 ${billing === 'annual' ? 'translate-x-6' : ''}`}></div>
                    </button>
                    <span className={`text-sm font-bold ${billing === 'annual' ? 'text-brand-dark' : 'text-slate-400'}`}>
                        Anual <span className="text-green-500 text-xs ml-1">(-2 meses gratis)</span>
                    </span>
                </div>
            )}
            
            {/* Mensaje especial para Cripto */}
            {segment === 'cripto' && (
                 <div className="mb-16 text-sm text-slate-400 font-medium animate-in fade-in">
                    Los planes cripto son de pago único anual (Campaña Renta).
                 </div>
            )}
        </FadeIn>

        {/* GRILLA DE PRECIOS DINÁMICA */}
        <div className={`max-w-6xl mx-auto grid gap-8 items-start ${activePlans.length === 2 ? 'md:grid-cols-2 max-w-4xl' : 'md:grid-cols-3'}`}>
            {activePlans.map((plan, idx) => {
                const displayPrice = getDisplayPrice(plan);
                const displayPeriod = getDisplayPeriod(plan);

                return (
                <FadeIn key={plan.name} delay={idx * 0.1} 
                    className={`relative rounded-2xl p-8 shadow-sm border transition-all duration-300 hover:shadow-xl hover:-translate-y-2 
                    ${plan.highlight ? 'bg-[#0B0F19] text-white border-slate-700' : 'bg-white text-slate-600 border-slate-200'} 
                    ${plan.popular ? 'border-brand-blue ring-2 ring-brand-blue/20 shadow-xl' : ''}`}
                >
                    
                    {plan.popular && (
                        <div className={`absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full text-xs font-bold uppercase tracking-wide ${segment === 'empresa' ? 'bg-brand-dark text-white' : segment === 'cripto' ? 'bg-purple-600 text-white' : 'bg-brand-blue text-white'}`}>
                            {segment === 'empresa' ? 'Más Completo' : 'Recomendado'}
                        </div>
                    )}

                    <h3 className={`text-xl font-bold mb-2 ${plan.highlight ? 'text-white' : 'text-brand-dark'}`}>{plan.name}</h3>
                    <p className={`text-sm mb-6 leading-relaxed ${plan.highlight ? 'text-slate-400' : 'text-slate-500'}`}>{plan.description}</p>
                    
                    <div className="mb-8 border-b border-slate-100/10 pb-8">
                        <span className={`text-4xl font-black ${plan.highlight ? 'text-white' : 'text-brand-dark'}`}>
                            {typeof displayPrice === 'number' 
                                ? displayPrice.toLocaleString() + '€' 
                                : displayPrice}
                        </span>
                        <span className={`text-sm ${plan.highlight ? 'text-slate-500' : 'text-slate-400'}`}>
                            {displayPeriod}
                        </span>
                        
                        {billing === 'annual' && plan.basePeriod === 'monthly' && (
                            <div className="text-xs text-green-500 font-bold mt-2">
                                ¡Ahorras {plan.price * 2}€ al año!
                            </div>
                        )}
                         {/* Espaciador para mantener altura visual */}
                         {((plan.basePeriod === 'annual' || plan.basePeriod === 'custom') && billing === 'annual' && segment !== 'cripto') && (
                            <div className="text-xs text-slate-500 font-bold mt-2 opacity-0">.</div> 
                        )}
                    </div>

                    <ul className="space-y-4 mb-8 text-left">
                        {plan.features.map((feature) => (
                            <li key={feature} className="flex items-start gap-3 text-sm">
                                <span className={plan.highlight ? 'text-green-400 font-bold' : 'text-green-500 font-bold'}>✓</span>
                                <span className={plan.highlight ? 'text-slate-300' : 'text-slate-600'}>{feature}</span>
                            </li>
                        ))}
                    </ul>

                    {plan.customAction ? (
                        <button 
                            onClick={() => window.open('https://calendly.com/francisco-alsase/30min', '_blank')}
                            className="block w-full py-4 rounded-xl font-bold text-center border-2 border-slate-300 text-slate-600 hover:bg-slate-50 transition-all"
                        >
                            {plan.cta}
                        </button>
                    ) : (
                        <a 
                            href={plan.stripeLink} 
                            target="_blank"
                            className={`block w-full py-4 rounded-xl font-bold text-center transition-all ${plan.highlight ? 'bg-brand-blue hover:bg-blue-600 text-white' : plan.popular ? 'bg-brand-blue hover:bg-blue-600 text-white shadow-lg shadow-blue-500/30' : 'border-2 border-brand-blue text-brand-blue hover:bg-blue-50'}`}
                        >
                            {plan.cta}
                        </a>
                    )}
                    
                    {!plan.customAction && (
                        <p className="text-xs text-center mt-4 text-slate-400 flex items-center justify-center gap-1">
                            🔒 Pago seguro vía Stripe
                        </p>
                    )}
                </FadeIn>
            )})}
        </div>
      </section>

      {/* FAQ DE CIERRE */}
      <section className="py-20 bg-white">
        <div className="max-w-3xl mx-auto px-6">
            <h2 className="text-3xl font-black text-brand-dark mb-12 text-center">Preguntas Frecuentes antes de contratar</h2>
            <div className="space-y-8">
                <div>
                    <h4 className="font-bold text-brand-dark mb-2">¿Qué pasa después de pagar?</h4>
                    <p className="text-slate-600 text-sm">Recibirás un email automático de bienvenida con el acceso inmediato a tu Área Privada y un enlace exclusivo para agendar tu sesión de Onboarding (Videollamada) con Francisco.</p>
                </div>
                <div>
                    <h4 className="font-bold text-brand-dark mb-2">¿Tengo permanencia?</h4>
                    <p className="text-slate-600 text-sm">Ninguna. Somos tan buenos que no necesitamos atarte. Si el servicio no te convence, puedes cancelar tu suscripción en cualquier momento con un solo clic desde tu panel.</p>
                </div>
                <div>
                    <h4 className="font-bold text-brand-dark mb-2">¿Cómo hago el cambio desde mi antigua gestoría?</h4>
                    <p className="text-slate-600 text-sm">Nosotros nos encargamos del "traspaso de poderes". Te pediremos una autorización simple y solicitaremos toda tu documentación fiscal anterior a tu antiguo gestor. Tú no tienes que pelearte con nadie ni pedir papeles incómodos.</p>
                </div>
            </div>
        </div>
      </section>
    </>
  );
}

export default function ContratarPage() {
  return (
    <main className="font-sans text-slate-600 bg-slate-50 min-h-screen">
      <Navbar />
      {/* Envolvemos el contenido que usa useSearchParams en Suspense para evitar errores de build */}
      <Suspense fallback={<div className="text-center py-20">Cargando planes...</div>}>
        <ContratarContent />
      </Suspense>
      <Footer />
    </main>
  );
}