import Link from "next/link";
import { Logo } from '@/components/Logo';
import { Footer } from '@/components/Footer';

export const metadata = {
  title: 'Planificación Renta 2025 | Ahorra Impuestos antes de fin de año',
  description: 'No esperes a abril. Planifica tu cierre fiscal 2025 ahora. Deducciones autonómicas Valencianas (Deporte, Salud) y ajuste de tramos autónomos.',
}

export default function RentaLanding() {
  return (
    <main className="font-sans text-slate-600 bg-white min-h-screen">
      
      {/* HEADER */}
      <header className="py-6 px-6 flex justify-between items-center border-b border-slate-100 sticky top-0 bg-white/95 backdrop-blur z-50">
        <Link href="/"><Logo /></Link>
        <Link href="/cita" className="bg-brand-blue text-white px-6 py-2 rounded-lg font-bold text-sm hover:bg-blue-700 transition shadow-lg shadow-blue-500/20">
            Pedir Cita Planificación
        </Link>
      </header>

      {/* HERO CIERRE FISCAL */}
      <section className="py-24 px-6 bg-gradient-to-br from-slate-50 to-blue-50 text-center">
        <span className="inline-block py-1 px-3 rounded-full bg-orange-100 text-orange-600 text-xs font-bold uppercase tracking-widest mb-6 animate-pulse">
            ⚠️ Cierre Fiscal 2025 en curso
        </span>
        <h1 className="text-4xl md:text-6xl font-extrabold text-brand-dark mb-6 max-w-4xl mx-auto leading-tight">
            El momento de ahorrar impuestos es <span className="text-brand-blue">AHORA</span>.
        </h1>
        <p className="text-xl text-slate-600 max-w-2xl mx-auto mb-10 leading-relaxed">
            En abril de 2026 ya será tarde. Si quieres aplicar las <strong>nuevas deducciones valencianas</strong> (Gimnasio, Salud Mental, Gafas) o ajustar tus tramos de autónomo, debes actuar antes del 31 de diciembre.
        </p>
        <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link href="/cita" className="px-8 py-4 bg-brand-dark text-white font-bold rounded-xl shadow-xl hover:scale-105 transition">
                Solicitar Estudio Pre-Cierre
            </Link>
        </div>
      </section>

   {/* NOVEDADES 2025 (Gancho de Valor) - CORREGIDO */}
      <section className="py-20 px-6 max-w-5xl mx-auto">
        <h2 className="text-3xl font-bold text-brand-dark text-center mb-12">Novedades Fiscales 2025 (Comunidad Valenciana)</h2>
        <div className="grid md:grid-cols-3 gap-8 text-left">
            
            <div className="p-8 border border-slate-200 rounded-2xl hover:shadow-xl transition bg-white">
                <div className="text-4xl mb-4">🏋️‍♂️</div> {/* Emoji corregido */}
                <h3 className="font-bold text-xl text-brand-dark mb-3">Deducción Deporte y Gimnasio</h3>
                <p className="text-sm text-slate-500 mb-4">
                    Hasta un <strong>30% de las cuotas</strong> de gimnasio, clubes deportivos o federaciones. Es vital guardar las facturas correctamente desglosadas.
                </p>
                <div className="text-xs font-bold text-brand-blue uppercase tracking-wide">Novedad 2025</div>
            </div>

            <div className="p-8 border border-slate-200 rounded-2xl hover:shadow-xl transition bg-white">
                <div className="text-4xl mb-4">👓</div> {/* Emoji corregido */}
                <h3 className="font-bold text-xl text-brand-dark mb-3">Salud: Gafas y Dentista</h3>
                <p className="text-sm text-slate-500 mb-4">
                    Nuevas deducciones autonómicas para gastos de salud bucodental no estética, cristales graduados, lentes de contacto y salud mental.
                </p>
                <div className="text-xs font-bold text-brand-blue uppercase tracking-wide">Hasta 150€ deducibles</div>
            </div>

            <div className="p-8 border border-slate-200 rounded-2xl hover:shadow-xl transition bg-white">
                <div className="text-4xl mb-4">📉</div> {/* Emoji corregido */}
                <h3 className="font-bold text-xl text-brand-dark mb-3">Autónomos: Ajuste MEI</h3>
                <p className="text-sm text-slate-500 mb-4">
                    El Mecanismo de Equidad Intergeneracional sube al <strong>0.8%</strong>. Revisamos tu previsión de ingresos para evitar el "hachazo" de la regularización en 2026.
                </p>
                <div className="text-xs font-bold text-red-500 uppercase tracking-wide">Atención Prioritaria</div>
            </div>

        </div>
      </section>

      {/* PRECIOS PLANIFICACIÓN */}
      <section className="py-20 px-6 bg-brand-dark text-white">
        <div className="max-w-5xl mx-auto">
            <h2 className="text-3xl font-bold text-center mb-12">Pack Cierre Fiscal 2025</h2>
            <div className="grid md:grid-cols-2 gap-8 items-center">
                
                <div className="bg-slate-800 border border-slate-700 p-8 rounded-2xl">
                    <h3 className="text-xl font-bold mb-2 text-slate-300">Revisión Renta Básica</h3>
                    <div className="text-4xl font-extrabold text-white mb-4">50€</div>
                    <p className="text-sm text-slate-400 mb-6">
                        Análisis de deducciones familiares, alquiler y vivienda habitual. Te decimos qué papeles preparar para abril.
                    </p>
                    <Link href="/cita" className="block w-full py-3 bg-slate-700 text-white font-bold rounded-lg hover:bg-slate-600 transition text-center">
                        Agendar Revisión
                    </Link>
                </div>

                <div className="bg-white border-4 border-brand-blue p-8 rounded-2xl relative text-slate-800 shadow-2xl transform md:scale-105">
                    <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-brand-blue text-white px-4 py-1 text-xs font-bold rounded-full tracking-widest uppercase">
                        Autónomos e Inversores
                    </div>
                    <h3 className="text-xl font-bold text-brand-dark mb-2">Planificación Integral</h3>
                    <div className="text-4xl font-extrabold text-brand-blue mb-4">90€</div>
                    <p className="text-sm text-slate-500 mb-6">
                        Simulación de cierre fiscal. Ajuste de tramos de autónomo. Análisis de cartera Cripto (pérdidas/ganancias) para compensar antes de fin de año.
                    </p>
                    <Link href="/cita" className="block w-full py-4 bg-brand-blue text-white font-bold rounded-lg hover:bg-blue-700 transition shadow-lg text-center">
                        Optimizar mis Impuestos
                    </Link>
                </div>

            </div>
        </div>
      </section>

      <Footer />
    </main>
  );
}