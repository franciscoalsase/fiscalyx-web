import Link from 'next/link';
import { Logo } from '@/components/Logo';

export default function Privacidad() {
  return (
    <main className="bg-white min-h-screen text-slate-600 font-sans">
      <div className="max-w-4xl mx-auto px-6 py-12">
        <div className="mb-8">
            <Link href="/" className="inline-block mb-8 hover:opacity-80"><Logo /></Link>
            <h1 className="text-3xl font-black text-brand-dark mb-2">Política de Privacidad</h1>
            <p className="text-sm text-slate-400">Adaptada al RGPD y LOPDGDD</p>
        </div>

        <div className="prose prose-slate max-w-none prose-headings:font-bold prose-headings:text-brand-dark prose-a:text-brand-blue">
          
          <p className="lead">
            En FiscalYX nos tomamos tu privacidad tan en serio como tu fiscalidad. La confidencialidad es la base de nuestra relación profesional.
          </p>

          <h3>1. Responsable del Tratamiento</h3>
          <ul className="list-none pl-0 text-sm">
            <li><strong>Identidad:</strong> [TU NOMBRE O EMPRESA]</li>
            <li><strong>NIF:</strong> [TU NIF]</li>
            <li><strong>Dirección:</strong> [TU DIRECCIÓN]</li>
            <li><strong>Email PD:</strong> [TU EMAIL]@fiscalyx.com</li>
          </ul>

          <h3>2. Finalidad del tratamiento ¿Para qué usamos tus datos?</h3>
          <p>Tratamos la información que nos facilitas para las siguientes finalidades:</p>
          <ul>
            <li><strong>Gestión de Consultas y "FiscalQuiz":</strong> Utilizaremos los datos introducidos en el formulario interactivo (Rango de facturación, tipo de perfil, email y teléfono) exclusivamente para elaborar un diagnóstico preliminar y contactar contigo para ofrecerte la sesión estratégica.</li>
            <li><strong>Prestación del Servicio:</strong> Gestión fiscal, contable y laboral contratada, incluyendo la presentación de impuestos en tu nombre ante la AEAT.</li>
            <li><strong>Comunicaciones Comerciales:</strong> Solo si nos has dado tu consentimiento expreso, te enviaremos novedades fiscales o recordatorios de plazos (ej: Campaña de Renta).</li>
          </ul>

          <h3>3. Legitimación</h3>
          <p>La base legal para el tratamiento de tus datos es:</p>
          <ul>
            <li><strong>Consentimiento del interesado:</strong> Al enviar el formulario o Quiz y marcar la casilla de aceptación.</li>
            <li><strong>Ejecución de un contrato:</strong> En caso de contratar nuestros servicios (Basic, Pro, Enterprise).</li>
            <li><strong>Interés legítimo:</strong> Para responder a tus consultas pre-contractuales.</li>
          </ul>

          <h3>4. Destinatarios ¿A quién comunicamos tus datos?</h3>
          <p>FiscalYX no vende datos a terceros. Jamás. Sin embargo, para prestar el servicio, podemos compartir datos estrictamente necesarios con:</p>
          <ul>
            <li><strong>Administración Pública:</strong> Agencia Tributaria (AEAT), Seguridad Social, Registros Públicos.</li>
            <li><strong>Proveedores Tecnológicos (Encargados de Tratamiento):</strong>
                <ul>
                    <li>Vercel Inc. (Hosting web)</li>
                    <li>Calendly LLC (Gestión de citas)</li>
                    <li>Quipu / Software de Contabilidad (Si contratas el servicio)</li>
                    <li>Google / Microsoft (Servicios de correo y nube)</li>
                </ul>
            </li>
          </ul>
          <p>Todos nuestros proveedores cumplen con las normativas de seguridad adecuadas.</p>

          <h3>5. Datos Sensibles y Confidencialidad</h3>
          <p>
            Como economistas colegiados, estamos sujetos al <strong>Secreto Profesional</strong>. Toda la información económica, patrimonial o estratégica (incluyendo carteras de Criptomonedas) será tratada con la máxima confidencialidad y medidas de seguridad reforzadas.
          </p>

          <h3>6. Derechos del Usuario</h3>
          <p>Puedes ejercer tus derechos de Acceso, Rectificación, Supresión, Limitación, Portabilidad y Oposición enviando un email a [TU EMAIL]@fiscalyx.com, adjuntando copia de tu DNI.</p>

          <h3>7. Conservación</h3>
          <p>
            Los datos de consultas se conservarán durante 1 año si no se formaliza el servicio. Los datos de clientes se conservarán durante los años necesarios para cumplir con las obligaciones legales (mínimo 5 años según Ley General Tributaria y 10 años para prevención de Blanqueo de Capitales).
          </p>

        </div>
        
        <div className="mt-12 pt-8 border-t border-slate-200">
            <Link href="/" className="text-brand-blue font-bold hover:underline">← Volver al Inicio</Link>
        </div>
      </div>
    </main>
  );
}