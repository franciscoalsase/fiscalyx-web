import Link from 'next/link';
import { Logo } from '@/components/Logo';

export default function AvisoLegal() {
  return (
    <main className="bg-white min-h-screen text-slate-600 font-sans">
      <div className="max-w-4xl mx-auto px-6 py-12">
        <div className="mb-8">
            <Link href="/" className="inline-block mb-8 hover:opacity-80"><Logo /></Link>
            <h1 className="text-3xl font-black text-brand-dark mb-2">Aviso Legal</h1>
            <p className="text-sm text-slate-400">Última actualización: Noviembre 2024</p>
        </div>

        <div className="prose prose-slate max-w-none prose-headings:font-bold prose-headings:text-brand-dark prose-a:text-brand-blue">
          
          <h3>1. Datos Identificativos</h3>
          <p>
            En cumplimiento con el deber de información recogido en el artículo 10 de la Ley 34/2002, de 11 de julio, de Servicios de la Sociedad de la Información y del Comercio Electrónico (LSSI-CE), se exponen los siguientes datos identificativos del titular del sitio web:
          </p>
          <ul className="list-none pl-0 bg-slate-50 p-6 rounded-xl border border-slate-200">
            <li><strong>Razón Social / Titular:</strong> [TU NOMBRE COMPLETO O NOMBRE DE LA SL]</li>
            <li><strong>NIF/CIF:</strong> [TU DNI O CIF]</li>
            <li><strong>Domicilio Social:</strong> [TU DIRECCIÓN FISCAL COMPLETA]</li>
            <li><strong>Email de contacto:</strong> [TU EMAIL @FISCALYX.COM]</li>
            <li><strong>Datos Registrales:</strong> [Si eres SL: Inscrita en el Registro Mercantil de Alicante, Tomo X, Folio Y... Si eres Autónomo: puedes borrar esta línea]</li>
            <li className="mt-4 pt-4 border-t border-slate-200"><strong>Datos Profesionales (Obligatorio LSSI):</strong></li>
            <li><strong>Colegio Profesional:</strong> Ilustre Colegio de Economistas de Alicante</li>
            <li><strong>Número de Colegiado:</strong> 4174</li>
            <li><strong>Título Oficial:</strong> Economista (Obtenido en España)</li>
            <li><strong>Normas profesionales aplicables:</strong> Estatutos del Colegio de Economistas y Código Deontológico.</li>
          </ul>

          <h3>2. Objeto y Ámbito de Aplicación</h3>
          <p>
            Las presentes condiciones regulan el uso de la web <strong>FiscalYX</strong>. El acceso a la misma implica la aceptación sin reservas del presente Aviso Legal. FiscalYX se reserva el derecho a modificar la presentación, configuración y contenidos de la Web, así como las condiciones requeridas para su acceso y/o utilización.
          </p>

          <h3>3. Propiedad Intelectual e Industrial</h3>
          <p>
            Todos los contenidos de la web (textos, el "FiscalQuiz", logotipos, gráficos, código fuente) son propiedad intelectual de FiscalYX o de terceros que han autorizado su uso, estando protegidos por la legislación nacional e internacional vigente. Queda prohibida la reproducción, distribución o comunicación pública sin autorización expresa.
          </p>

          <h3>4. Responsabilidad y Garantía (Disclaimer Fiscal)</h3>
          <p>
            La información contenida en esta web, incluyendo los resultados del "Diagnóstico Fiscal Preliminar" o "Calculadoras", tiene carácter meramente <strong>informativo y orientativo</strong>. No constituye, en ningún caso, asesoramiento jurídico o tributario vinculante.
          </p>
          <p>
            FiscalYX no se hace responsable de las decisiones tomadas por el usuario basadas únicamente en la información de la web sin la contratación previa de un servicio de asesoramiento personalizado y la revisión documental pertinente.
          </p>
          <p>
            En materia de <strong>Criptoactivos</strong>, el usuario reconoce la volatilidad y complejidad regulatoria del sector. FiscalYX prestará sus servicios basándose en la normativa vigente en el momento de la consulta, no haciéndose responsable de cambios legislativos retroactivos o interpretaciones de la AEAT posteriores.
          </p>

          <h3>5. Enlaces Externos</h3>
          <p>
            Esta web puede contener enlaces a sitios de terceros (ej: Calendly, Quipu, CoinTracking, AEAT). FiscalYX no asume responsabilidad alguna por el contenido, políticas de privacidad o prácticas de dichos sitios.
          </p>

          <h3>6. Ley Aplicable y Jurisdicción</h3>
          <p>
            Para la resolución de todas las controversias o cuestiones relacionadas con el presente sitio web, será de aplicación la legislación española, siendo competentes los Juzgados y Tribunales de <strong>[TU CIUDAD, EJ: ALICANTE]</strong>.
          </p>

        </div>
        
        <div className="mt-12 pt-8 border-t border-slate-200">
            <Link href="/" className="text-brand-blue font-bold hover:underline">← Volver al Inicio</Link>
        </div>
      </div>
    </main>
  );
}