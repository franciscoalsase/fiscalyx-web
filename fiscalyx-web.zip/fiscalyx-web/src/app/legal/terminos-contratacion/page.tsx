import Link from 'next/link';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';

export default function TerminosPage() {
  return (
    <main className="font-sans text-slate-600 bg-white">
      <Navbar />
      
      <article className="max-w-4xl mx-auto px-6 pt-32 pb-20">
        <div className="mb-12">
            <h1 className="text-3xl md:text-4xl font-black text-brand-dark mb-4">
                Términos y Condiciones de Contratación
            </h1>
            <p className="text-slate-500 text-sm">
                Última actualización: Diciembre 2025. Este documento regula la relación contractual entre FiscalYX y el Cliente.
            </p>
        </div>

        <div className="prose prose-slate max-w-none text-sm">
            
            <h3>1. Objeto del Servicio</h3>
            <p>
                FiscalYX (nombre comercial de <strong>Francisco Seva Soriano</strong>, con NIF [PON TU NIF AQUÍ]) presta servicios de asesoramiento y gestión fiscal, contable y laboral en modalidad online. El alcance exacto de los servicios depende del plan contratado (Basic, Pro, Enterprise o Cripto) detallado en la web.
            </p>

            <h3>2. Obligaciones del Cliente (Muy Importante)</h3>
            <p>Para que podamos cumplir con nuestras obligaciones, el Cliente se compromete a:</p>
            <ul>
                <li><strong>Subir la documentación en plazo:</strong> Las facturas y movimientos deben estar en la plataforma (Quipu) antes del día 5 del mes siguiente al cierre del trimestre. FiscalYX no se hace responsable de declaraciones fuera de plazo si la documentación no se entregó a tiempo.</li>
                <li><strong>Veracidad de los datos:</strong> El Cliente declara que los gastos deducidos y los ingresos declarados son reales. FiscalYX no audita la veracidad de cada ticket, solo su validez formal.</li>
                <li><strong>Conexión Bancaria:</strong> Mantener activa la conexión bancaria o facilitar los extractos para la conciliación.</li>
            </ul>

            <h3>3. Exclusiones del Servicio (Lo que NO incluye)</h3>
            <p>Salvo contratación específica adicional, la cuota mensual NO incluye:</p>
            <ul>
                <li>Asistencia presencial ante Inspecciones de Hacienda (se presupuesta aparte).</li>
                <li>Recursos contencioso-administrativos.</li>
                <li>Declaraciones complementarias por errores u omisiones del cliente.</li>
            </ul>

            <h3>4. Precios y Pagos</h3>
            <p>
                El cobro se realiza por adelantado mediante tarjeta de crédito/débito (Stripe). La falta de pago supondrá la suspensión inmediata del servicio y la no presentación de los impuestos del periodo en curso.
            </p>

            <h3>5. Cancelación y Permanencia</h3>
            <p>
                No existe permanencia. El cliente puede cancelar su suscripción en cualquier momento avisando con <strong>15 días de antelación</strong> al siguiente cobro.
            </p>

            <h3>6. Responsabilidad Profesional</h3>
            <p>
                FiscalYX cuenta con un Seguro de Responsabilidad Civil de 300.000€. Nuestra responsabilidad se limita a errores técnicos en la confección de los impuestos, nunca a la falta de veracidad de los datos aportados por el cliente.
            </p>

            <h3>7. Criptoactivos</h3>
            <p>
                En los planes Cripto, el cálculo FIFO se realiza en base a la información extraída de las APIs/CSVs facilitadas. Si el cliente omite wallets o exchanges, el cálculo será erróneo y FiscalYX no asume responsabilidad por esa omisión.
            </p>

        </div>
      </article>
      <Footer />
    </main>
  );
}