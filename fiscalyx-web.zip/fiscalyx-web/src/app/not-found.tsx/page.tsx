import Link from 'next/link'
import { Footer } from '@/components/Footer'
 
export default function NotFound() {
  return (
    <main className="min-h-screen bg-slate-50 font-sans text-slate-600 flex flex-col">
        <div className="flex-grow flex flex-col items-center justify-center text-center px-6">
            <h2 className="text-9xl font-black text-brand-blue/20">404</h2>
            <h1 className="text-3xl font-bold text-brand-dark -mt-12 mb-4">Vaya, te has perdido</h1>
            <p className="text-lg mb-8 max-w-md">
                Esta página no existe. Pero no te preocupes, en temas fiscales nosotros somos tu brújula.
            </p>
            <Link href="/" className="px-8 py-3 bg-brand-blue text-white font-bold rounded-xl hover:bg-blue-600 transition shadow-lg">
                Volver al Inicio
            </Link>
        </div>
        <Footer />
    </main>
  )
}