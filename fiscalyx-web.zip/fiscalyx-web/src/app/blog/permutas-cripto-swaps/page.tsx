import Link from 'next/link';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Cálculo FIFO en Criptomonedas: Guía Técnica y Errores | FiscalYX',
  description: 'El método First In First Out es obligatorio en España. Aprende a calcular la ganancia patrimonial en permutas complejas y evitar la paralela.',
};

export default function BlogPost() {
  return (
    <main className="font-sans text-slate-900 bg-white selection:bg-purple-500 selection:text-white">
      <Navbar />
      
      <header className="relative pt-32 pb-20 bg-[#0B0F19] text-white overflow-hidden">
        <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-purple-600/20 rounded-full blur-[120px] -translate-y-1/2"></div>
        <div className="max-w-4xl mx-auto px-6 relative z-10 text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-purple-900/50 border border-purple-500/30 text-purple-300 text-sm font-bold uppercase tracking-widest mb-8">
              <span className="w-2 h-2 rounded-full bg-purple-400 animate-pulse"></span> Cálculo de Impuestos
            </div>
            <h1 className="text-5xl md:text-7xl font-black mb-8 leading-[1.1] tracking-tight">
                Permutas y FIFO: La matemática detrás de tus impuestos
            </h1>
            <p className="text-2xl text-slate-400 leading-relaxed max-w-3xl mx-auto mb-10 font-medium">
                Hacienda no acepta LIFO ni coste medio. Te explicamos cómo calcular tus ganancias reales en un Swap.
            </p>
        </div>
      </header>

      <article className="max-w-3xl mx-auto px-6 py-20">
        
        <div className="prose prose-xl prose-slate max-w-none 
            prose-headings:font-black prose-headings:text-slate-900 
            prose-strong:text-purple-600 prose-strong:font-black">
            
            <p>
                Muchos inversores calculan sus ganancias como: <em>"Metí 10.000€ y saqué 12.000€, gané 2.000€"</em>. 
                <strong>ERROR GRAVE.</strong> Hacienda no funciona por flujos de caja, funciona por <strong>alteración patrimonial individualizada</strong>.
            </p>

            <h2 className="text-4xl mt-16 mb-8">¿Qué es el Criterio FIFO?</h2>
            <p>
                FIFO significa <strong>First In, First Out</strong> (Lo primero que entra es lo primero que sale). Es el método obligatorio en España para activos homogéneos (como Bitcoin).
            </p>
            
            <div className="bg-slate-50 border-2 border-slate-200 p-8 my-10 rounded-2xl not-prose">
                <h4 className="font-black text-slate-900 text-2xl mb-4">🧮 Ejemplo Práctico (El Desastre)</h4>
                <ul className="space-y-3 text-lg">
                    <li className="flex justify-between border-b border-slate-200 pb-2">
                        <span><strong>Compra 1:</strong> Enero 2021</span>
                        <span>1 BTC a 20.000€</span>
                    </li>
                    <li className="flex justify-between border-b border-slate-200 pb-2">
                        <span><strong>Compra 2:</strong> Nov 2021</span>
                        <span>1 BTC a 60.000€</span>
                    </li>
                    <li className="flex justify-between pt-2 text-purple-700 font-bold">
                        <span><strong>Venta:</strong> Enero 2024</span>
                        <span>Vendes 1 BTC a 50.000€</span>
                    </li>
                </ul>
                <p className="mt-6 text-base text-slate-600">
                    <strong>Tu lógica:</strong> "Vendí el que compré a 60k, así que he perdido 10.000€. ¡No pago impuestos!"
                    <br/>
                    <strong>La lógica de Hacienda (FIFO):</strong> "Has vendido el primero que compraste (el de 20k). Has ganado 30.000€. ¡Paga!"
                </p>
            </div>

            <p>
                Como ves, aplicar mal el criterio puede convertir una supuesta pérdida en una ganancia tributable enorme.
            </p>

            <h2 className="text-4xl mt-16 mb-8">¿Y las comisiones (Gas Fees)?</h2>
            <p>
                Buenas noticias: <strong>Son deducibles.</strong>
                <br/>
                El valor de adquisición es: (Precio Compra + Comisiones Compra).
                <br/>
                El valor de transmisión es: (Precio Venta - Comisiones Venta).
            </p>
            <p>
                Si has operado en Ethereum en 2021, puedes tener miles de euros en Gas Fees. Si no los sumas al coste, estás pagando impuestos de más. Nuestro software rastrea cada fee de transacción para deducirlo.
            </p>

        </div>

        <div className="mt-24 bg-slate-900 text-white p-12 md:p-16 rounded-[2rem] text-center shadow-2xl border border-slate-800 relative overflow-hidden">
             <div className="relative z-10">
                <h3 className="text-3xl font-black mb-6">Hacemos los números por ti</h3>
                <p className="text-slate-300 text-xl mb-10 max-w-2xl mx-auto">
                    Importamos tus datos, aplicamos FIFO estricto y deducimos todas las comisiones posibles. Entregamos el informe listo para la casilla de la Renta.
                </p>
                <Link href="/contratar?tab=cripto" className="inline-block px-10 py-5 bg-purple-600 hover:bg-purple-500 text-white font-black text-lg rounded-2xl transition hover:-translate-y-1">
                    Pack Renta Cripto (350€)
                </Link>
            </div>
        </div>
      </article>
      <Footer />
    </main>
  );
}