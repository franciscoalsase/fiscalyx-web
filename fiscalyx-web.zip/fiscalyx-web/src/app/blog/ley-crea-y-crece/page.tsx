import Link from 'next/link';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'S.L. con 1 euro: La letra pequeña de la Ley Crea y Crece | FiscalYX',
  description: 'Ya no necesitas 3.000€. Pero crear una sociedad "gratis" tiene riesgos de responsabilidad solidaria. Te explicamos la verdad.',
};

export default function BlogPost() {
  return (
    <main className="font-sans text-slate-900 bg-white selection:bg-green-500 selection:text-white">
      <Navbar />
      
      <header className="relative pt-32 pb-20 bg-white border-b border-slate-100 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] [background-size:16px_16px] opacity-50"></div>
        <div className="max-w-4xl mx-auto px-6 relative z-10 text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-green-50 border border-green-200 text-green-700 text-sm font-bold uppercase tracking-widest mb-8">
              <span className="w-2 h-2 rounded-full bg-green-600 animate-pulse"></span> Emprendedores 2025
            </div>
            <h1 className="text-5xl md:text-7xl font-black text-slate-900 mb-8 leading-[1.1] tracking-tight">
                Crear una empresa con 1 euro: La verdad detrás del titular
            </h1>
            <p className="text-2xl text-slate-600 leading-relaxed max-w-3xl mx-auto mb-10 font-medium">
                La Ley Crea y Crece ha eliminado la barrera de los 3.000€. Pero la responsabilidad ilimitada sigue ahí escondida.
            </p>
        </div>
      </header>

      <article className="max-w-3xl mx-auto px-6 py-20">
        
        <div className="bg-green-50/80 border-2 border-green-100 rounded-3xl p-8 md:p-10 mb-16 shadow-sm">
             <h3 className="text-green-900 font-black text-2xl mb-6 flex items-center gap-3">
                🚀 Lo Bueno y Lo Malo
             </h3>
             <ul className="space-y-4 text-slate-800 text-lg font-medium">
                 <li className="flex gap-4 items-start"><span className="text-green-600 text-2xl mt-1">✓</span> <span><strong>Sin Capital Inicial:</strong> No necesitas bloquear 3.000€ en el banco para ir al notario.</span></li>
                 <li className="flex gap-4 items-start"><span className="text-green-600 text-2xl mt-1">✓</span> <span><strong>Rápido:</strong> Constitución telemática en 24-48h.</span></li>
                 <li className="flex gap-4 items-start"><span className="text-red-500 text-2xl mt-1">⚠</span> <span><strong>La Trampa:</strong> Sigues respondiendo con tu dinero personal hasta cubrir los 3.000€ si hay deudas.</span></li>
             </ul>
        </div>

        <div className="prose prose-xl prose-slate max-w-none 
            prose-headings:font-black prose-headings:tracking-tight prose-headings:text-slate-900 
            prose-p:text-slate-600 prose-p:leading-8 
            prose-strong:text-green-700 prose-strong:font-black">
            
            <h2 className="text-4xl mt-16 mb-8">La Responsabilidad Solidaria (El detalle clave)</h2>
            <p>
                El gobierno te deja crear la S.L. con 1 euro, pero <strong>no elimina la garantía frente a acreedores</strong>.
            </p>
            <p>
                La ley dice claramente: <em>"Los socios responderán solidariamente frente a terceros hasta la cifra de 3.000 euros."</em>
            </p>
            <p>
                <strong>¿Qué significa esto?</strong> Que si tu empresa quiebra debiendo 10.000€ a un proveedor y solo pusiste 1€ de capital, el juez puede ir a por tu cuenta personal y embargarte 2.999€ para cubrir esa diferencia legal.
            </p>

            <h2 className="text-4xl mt-16 mb-8">La Obligación de Ahorrar</h2>
            <p>
                Además, no puedes repartir dividendos libremente. Estás obligado a destinar el <strong>20% del beneficio anual</strong> a la Reserva Legal hasta que, sumada al capital, alcances esos 3.000€.
            </p>
            <p>
                Básicamente, el Estado te dice: "Empieza gratis, pero ve llenando la hucha poco a poco".
            </p>

            <h2 className="text-4xl mt-16 mb-8">¿Compensa?</h2>
            <p>
                <strong>Sí, para empezar.</strong> Es ideal para negocios digitales que no requieren inversión inicial (consultores, dropshipping, agencias). Te permite tener NIF de sociedad y facturar como empresa desde el día 1 sin descapitalizarte.
            </p>
        </div>

        <div className="mt-24 bg-brand-dark text-white p-12 md:p-16 rounded-[2rem] text-center shadow-2xl border border-slate-800 relative overflow-hidden">
            <div className="relative z-10">
                <h3 className="text-3xl md:text-5xl font-black mb-6 tracking-tight">Constitución Express</h3>
                <p className="text-slate-300 text-xl mb-10 max-w-2xl mx-auto leading-relaxed">
                    Nosotros redactamos los estatutos, pedimos la denominación y te acompañamos al notario. En 48h tienes tu S.L. operativa.
                </p>
                <div className="flex flex-col sm:flex-row justify-center gap-4">
                    <Link href="/contratar?tab=empresa" className="inline-block px-10 py-5 bg-green-600 hover:bg-green-500 text-white font-black text-lg rounded-2xl transition shadow-xl hover:-translate-y-1">
                        Ver Plan Startup (129€/mes)
                    </Link>
                </div>
            </div>
        </div>
      </article>
      <Footer />
    </main>
  );
}