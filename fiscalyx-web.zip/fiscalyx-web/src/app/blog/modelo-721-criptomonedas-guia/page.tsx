import Link from 'next/link';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Modelo 721: La Verdad sobre el "Gran Hermano" Cripto | FiscalYX',
  description: 'No es solo declarar lo que tienes. Es evitar la multa de 20€ por dato. Análisis detallado de Custodios, DeFi y el límite de 50k.',
};

export default function BlogPost() {
  return (
    <main className="font-sans text-slate-900 bg-white selection:bg-blue-500 selection:text-white">
      <Navbar />
      
      <header className="relative pt-32 pb-20 bg-white border-b border-slate-100 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] [background-size:16px_16px] opacity-50"></div>
        
        <div className="max-w-4xl mx-auto px-6 relative z-10 text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-purple-50 border border-purple-200 text-purple-700 text-sm font-bold uppercase tracking-widest mb-8">
              <span className="w-2 h-2 rounded-full bg-purple-600 animate-pulse"></span> Campaña Cripto 2025
            </div>
            <h1 className="text-5xl md:text-7xl font-black text-slate-900 mb-8 leading-[1.1] tracking-tight">
                Modelo 721: O lo presentas bien, o preparas la cartera
            </h1>
            <p className="text-2xl text-slate-600 leading-relaxed max-w-3xl mx-auto mb-10 font-medium">
                Hacienda ya no avisa, sanciona. Te explicamos la diferencia crítica entre "Wallet Custodia" y "Self-Custody" que puede salvarte de la multa.
            </p>
             <div className="flex items-center justify-center gap-4 text-sm font-bold text-slate-500 border-t border-slate-200 pt-8 w-fit mx-auto uppercase tracking-wide">
                <span>⏱ Lectura 8 min</span>
                <span>•</span>
                <span>Por Francisco Seva</span>
            </div>
        </div>
      </header>

      <article className="max-w-3xl mx-auto px-6 py-20">
        
        <div className="bg-purple-50/80 border-2 border-purple-100 rounded-3xl p-8 md:p-10 mb-16 shadow-sm">
            <h3 className="text-purple-900 font-black text-2xl mb-6 flex items-center gap-3">
                ⚡ Puntos Críticos
            </h3>
            <ul className="space-y-4 text-slate-800 text-lg font-medium">
                <li className="flex gap-4 items-start"><span className="text-purple-600 text-2xl mt-1">➜</span> <span><strong className="text-purple-700 font-black">El Límite Real:</strong> Solo declaras si superas los 50.000€ de saldo conjunto a 31 de diciembre (o saldo medio del Q4).</span></li>
                <li className="flex gap-4 items-start"><span className="text-purple-600 text-2xl mt-1">➜</span> <span><strong className="text-purple-700 font-black">Ledger y Trezor:</strong> La gran victoria. Las wallets frías NO se declaran en el 721 (salvo cambio de criterio).</span></li>
                <li className="flex gap-4 items-start"><span className="text-purple-600 text-2xl mt-1">➜</span> <span><strong className="text-purple-700 font-black">Binance/Coinbase:</strong> SÍ se declaran. Son "Custodios Extranjeros" y Hacienda tiene sus datos vía DAC8.</span></li>
            </ul>
        </div>

        <div className="prose prose-xl prose-slate max-w-none 
            prose-headings:font-black prose-headings:tracking-tight prose-headings:text-slate-900 
            prose-p:text-slate-600 prose-p:leading-8 
            prose-li:text-slate-600 
            prose-strong:text-purple-600 prose-strong:font-black">
            
            <p className="lead text-2xl text-slate-800 font-semibold mb-12 border-l-4 border-purple-500 pl-6 italic">
                El Modelo 721 es una trampa informativa. No pagas nada al presentarlo, pero si te equivocas en un dato, la sanción es automática. Es el "detector de mentiras" para tu Renta.
            </p>

            <h2 className="text-4xl mt-16 mb-8">1. ¿Tengo que presentarlo? El Test Rápido</h2>
            <p>
                No importa si has ganado o perdido dinero. Lo que importa es el <strong>saldo</strong>. Debes sumar el valor en Euros de TODAS tus criptos depositadas en exchanges extranjeros (no españoles) a fecha 31/12.
            </p>
            <p>
                Si la suma da <strong>49.999€</strong>, te libras. Si da <strong>50.001€</strong>, estás obligado.
            </p>
            
            <div className="bg-yellow-50 border-l-8 border-yellow-500 p-8 my-10 rounded-r-2xl shadow-sm not-prose">
                <h4 className="font-black text-yellow-900 text-2xl mb-3">⚠️ La Trampa del "Saldo Medio"</h4>
                <p className="text-yellow-800 text-lg m-0 leading-relaxed">
                    Cuidado: Aunque a 31 de diciembre tengas 0€, si tu <strong>saldo medio del último trimestre (Q4)</strong> superó los 50.000€, también estás obligado. Muchos inversores venden todo el 30 de diciembre pensando que son listos, y Hacienda les caza por el saldo medio.
                </p>
            </div>

            <h2 className="text-4xl mt-16 mb-8">2. Cold Wallets vs Exchanges: La Frontera</h2>
            <p>
                Aquí está la clave técnica que pocos asesores entienden. El Modelo 721 se basa en la <strong>"Custodia de Claves"</strong>.
            </p>
            <ul className="marker:text-purple-500">
                <li><strong>Exchanges (Binance, Kraken):</strong> Ellos tienen tus claves. Son custodios. El dinero está "fuera". <strong>Se declara.</strong></li>
                <li><strong>DeFi / Cold Wallets (Metamask, Ledger):</strong> Tú tienes las claves. Tú eres tu propio banco. Técnicamente, el activo está "donde estés tú" (España). <strong>NO se declara en el 721.</strong></li>
            </ul>

            <h2 className="text-4xl mt-16 mb-8">3. Las Multas (El Dolor)</h2>
            <p>
                Aunque Europa tumbó las multas confiscatorias del 720, las del 721 siguen doliendo. Hablamos de <strong>20€ por cada dato no declarado</strong> con un mínimo de 300€ por declaración.
            </p>
            <p>
                Y lo peor: Si no lo presentas y Hacienda te requiere, la sanción se agrava. Si lo presentas fuera de plazo voluntariamente, se reduce a la mitad.
            </p>

        </div>

        <div className="mt-24 bg-slate-900 text-white p-12 md:p-16 rounded-[2rem] text-center shadow-2xl border border-slate-800 relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-purple-900/40 via-transparent to-transparent"></div>
            <div className="relative z-10">
                <h3 className="text-3xl md:text-5xl font-black mb-6 tracking-tight">¿Dudas si llegas a los 50k?</h3>
                <p className="text-slate-300 text-xl mb-10 max-w-2xl mx-auto leading-relaxed">
                    Conectamos nuestra herramienta de auditoría a tus APIs (solo lectura) y te decimos al céntimo si estás obligado o no. Dormir tranquilo cuesta menos que la multa.
                </p>
                <div className="flex flex-col sm:flex-row justify-center gap-4">
                    <Link href="/contratar?tab=cripto" className="inline-block px-10 py-5 bg-purple-600 hover:bg-purple-500 text-white font-black text-lg rounded-2xl transition shadow-xl hover:-translate-y-1">
                        Auditar mis Saldos
                    </Link>
                </div>
            </div>
        </div>
      </article>
      <Footer />
    </main>
  );
}