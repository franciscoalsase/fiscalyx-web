import Link from 'next/link';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: '¿Autónomo o S.L.? La cifra exacta para cambiar | FiscalYX',
  description: 'Analizamos el límite de los 40.000€. Ventajas fiscales, protección de patrimonio y el coste oculto de "sacar el dinero" de la empresa.',
};

export default function BlogPost() {
  return (
    <main className="font-sans text-slate-900 bg-white selection:bg-brand-dark selection:text-white">
      <Navbar />
      
      <header className="relative pt-32 pb-20 bg-[#0f172a] text-white overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-slate-800 via-slate-900 to-transparent opacity-50"></div>
        <div className="max-w-4xl mx-auto px-6 relative z-10 text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-slate-800 border border-slate-700 text-slate-300 text-sm font-bold uppercase tracking-widest mb-8">
              <span className="w-2 h-2 rounded-full bg-white animate-pulse"></span> Ingeniería Fiscal
            </div>
            <h1 className="text-5xl md:text-7xl font-black mb-8 leading-[1.1] tracking-tight">
                ¿Autónomo o Sociedad? Deja de adivinar, estas son las cifras
            </h1>
            <p className="text-2xl text-slate-400 leading-relaxed max-w-3xl mx-auto mb-10 font-medium">
                Hay un momento matemático donde ser autónomo es tirar el dinero. Te decimos cuál es y por qué tu cuñado se equivoca.
            </p>
        </div>
      </header>

      <article className="max-w-3xl mx-auto px-6 py-20">
        
        <div className="bg-slate-50 border-2 border-slate-200 rounded-3xl p-8 md:p-10 mb-16 shadow-sm">
             <h3 className="text-slate-900 font-black text-2xl mb-6">⚖️ El Cara a Cara</h3>
             <div className="grid md:grid-cols-2 gap-8">
                <div>
                    <h4 className="font-bold text-brand-dark text-xl mb-3 border-b border-slate-200 pb-2">Autónomo</h4>
                    <ul className="text-lg text-slate-600 space-y-3 font-medium">
                        <li>❌ Responsabilidad Ilimitada (Tu casa peligra)</li>
                        <li>❌ IRPF Progresivo (Te castiga si ganas más)</li>
                        <li>✅ Gestión Barata y Simple</li>
                    </ul>
                </div>
                <div>
                    <h4 className="font-bold text-brand-dark text-xl mb-3 border-b border-slate-200 pb-2">Sociedad Limitada</h4>
                    <ul className="text-lg text-slate-600 space-y-3 font-medium">
                        <li>✅ Patrimonio Protegido</li>
                        <li>✅ Impuesto Fijo (25% o 15%)</li>
                        <li>❌ Mayor coste de gestión</li>
                    </ul>
                </div>
             </div>
        </div>

        <div className="prose prose-xl prose-slate max-w-none 
            prose-headings:font-black prose-headings:tracking-tight prose-headings:text-slate-900 
            prose-p:text-slate-600 prose-p:leading-8 
            prose-strong:text-brand-blue prose-strong:font-black">

            <h2 className="text-4xl mt-16 mb-8">La Barrera de los 40.000€</h2>
            <p>
                El IRPF es un impuesto voraz. Cuanto más ganas, mayor es el porcentaje que pagas por el último euro ganado (tipo marginal).
            </p>
            <p>
                A partir de <strong>40.000€ - 50.000€ de beneficio neto</strong>, tu tipo de IRPF supera el 30-35%. En cambio, una S.L. paga un fijo del 25% (o el 15% los dos primeros años). Matemáticamente, ahí es donde la S.L. empieza a ahorrar dinero.
            </p>

            <div className="bg-yellow-50 border-l-8 border-yellow-500 p-8 my-10 rounded-r-2xl shadow-sm not-prose">
                <h4 className="font-black text-yellow-900 text-2xl mb-3">💸 La Trampa de "Sacar el Dinero"</h4>
                <p className="text-yellow-800 text-lg m-0 leading-relaxed">
                    Ojo: El dinero de la S.L. no es tuyo, es de la empresa. Si quieres gastarlo en viajes personales, tienes que sacarlo vía nómina o dividendos, y ahí... ¡vuelves a pagar IRPF! La S.L. es perfecta para <strong>reinvertir</strong> o acumular patrimonio, no para vivir al día.
                </p>
            </div>

            <h2 className="text-4xl mt-16 mb-8">El Escudo Patrimonial</h2>
            <p>
                Más importante que los impuestos: <strong>El Riesgo</strong>.
            </p>
            <p>
                Si eres autónomo y tienes una deuda (un despido improcedente, una multa grande, un proveedor que falla), responden tus bienes presentes y futuros. Pueden embargarte la casa.
                Con una S.L., la responsabilidad se limita al dinero que haya en la empresa. Si tienes empleados o local, la S.L. es obligatoria para dormir tranquilo.
            </p>
        </div>

        <div className="mt-24 bg-brand-dark text-white p-12 md:p-16 rounded-[2rem] text-center shadow-2xl relative overflow-hidden">
            <div className="relative z-10">
                <h3 className="text-3xl md:text-5xl font-black mb-6 tracking-tight">Creamos tu S.L. en 48h</h3>
                <p className="text-slate-300 text-xl mb-10 max-w-2xl mx-auto leading-relaxed">
                    Nos encargamos del notario, registro, NIF y alta fiscal. Tú solo tienes que ir a firmar.
                </p>
                <div className="flex flex-col sm:flex-row justify-center gap-4">
                    <Link href="/contratar?tab=empresa" className="inline-block px-10 py-5 bg-white text-brand-dark font-black text-lg rounded-2xl transition shadow-xl hover:-translate-y-1">
                        Ver Plan Startup (129€)
                    </Link>
                </div>
            </div>
        </div>
      </article>
      <Footer />
    </main>
  );
}