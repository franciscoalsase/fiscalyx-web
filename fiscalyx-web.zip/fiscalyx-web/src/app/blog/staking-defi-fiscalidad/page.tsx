import Link from 'next/link';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Guía Técnica Fiscalidad DeFi 2025: Staking, LP y Airdrops | FiscalYX',
  description: 'Análisis profundo sobre la tributación de Liquid Staking (stETH), impermanent loss y por qué Hacienda considera permuta la entrada a un Pool.',
};

export default function BlogPost() {
  return (
    <main className="font-sans text-slate-900 bg-white selection:bg-purple-500 selection:text-white">
      <Navbar />
      
      <header className="relative pt-32 pb-20 bg-[#0B0F19] text-white overflow-hidden">
        <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-purple-900/30 rounded-full blur-[120px] -translate-y-1/2"></div>
        <div className="max-w-4xl mx-auto px-6 relative z-10 text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-purple-900/50 border border-purple-500/30 text-purple-300 text-sm font-bold uppercase tracking-widest mb-8">
              <span className="w-2 h-2 rounded-full bg-purple-400 animate-pulse"></span> Fiscalidad Avanzada
            </div>
            <h1 className="text-5xl md:text-7xl font-black text-white mb-8 leading-[1.1] tracking-tight">
                La Guía Técnica del Staking y DeFi en España
            </h1>
            <p className="text-2xl text-slate-400 leading-relaxed max-w-3xl mx-auto mb-10 font-medium">
                Olvídate de generalidades. Analizamos la diferencia fiscal entre Locked Staking y Liquid Staking, y cómo tributan realmente los LP Tokens.
            </p>
        </div>
      </header>

      <article className="max-w-3xl mx-auto px-6 py-20">
        
        <div className="bg-purple-50/80 border-2 border-purple-100 rounded-3xl p-8 mb-16 shadow-sm">
            <h3 className="text-purple-900 font-black text-2xl mb-4">📌 Lo que vas a aprender</h3>
            <ul className="space-y-3 text-slate-800 text-lg font-medium">
                <li className="flex gap-3"><span>1.</span> Por qué el <strong>Liquid Staking (Lido/RocketPool)</strong> es una trampa fiscal.</li>
                <li className="flex gap-3"><span>2.</span> Cómo tributan los <strong>Airdrops</strong> (y por qué van a la Base General).</li>
                <li className="flex gap-3"><span>3.</span> La problemática de los <strong>LP Tokens</strong> al aportar liquidez.</li>
            </ul>
        </div>

        <div className="prose prose-xl prose-slate max-w-none prose-headings:font-black prose-headings:text-slate-900 prose-a:text-purple-600">
            
            <h2 className="text-4xl mt-8 mb-6">1. La Trampa del Liquid Staking (stETH, rETH)</h2>
            <p>
                Este es el error más común en consultorías. El usuario cree que al depositar ETH en Lido y recibir stETH, solo ha "depositado". <strong>Para Hacienda, eso es una permuta (Swap).</strong>
            </p>
            <p>
                Al recibir stETH, has intercambiado un activo (ETH) por otro distinto (un derivado).
                <br/><strong>Consecuencia:</strong> Tienes que aflorar la ganancia o pérdida patrimonial de tus ETH en ese momento exacto. Si compraste ETH a 100€ y lo metes en Lido a 2.000€, pagas impuestos por esa diferencia <em>aunque no hayas vendido a euros</em>.
            </p>

            <h2 className="text-4xl mt-16 mb-6">2. Locked Staking (Nativo)</h2>
            <p>
                Si haces staking nativo (ej: delegar ADA o SOL desde tu Ledger) donde <strong>no recibes un token de recibo</strong> a cambio, la interpretación cambia.
            </p>
            <p>
                Aquí no hay alteración patrimonial inicial. Solo tributas por las <strong>recompensas (Rewards)</strong> que recibes periódicamente.
            </p>
            <ul>
                <li><strong>Calificación:</strong> Rendimiento de Capital Mobiliario (Base del Ahorro, 19-28%).</li>
                <li><strong>Valoración:</strong> Precio de mercado en el momento de recepción (Claim).</li>
            </ul>

            <h2 className="text-4xl mt-16 mb-6">3. Airdrops: El golpe en la Base General</h2>
            <p>
                Recibir un Airdrop (ej: Arbitrum, Jito) no es una "ganancia de inversión", es una <strong>Ganancia Patrimonial NO derivada de transmisión</strong>.
            </p>
            <div className="bg-yellow-50 border-l-8 border-yellow-500 p-8 my-8 rounded-r-2xl shadow-sm not-prose">
                <h4 className="font-black text-yellow-900 text-2xl mb-3">⚠️ Cuidado con el tipo impositivo</h4>
                <p className="text-yellow-800 text-lg m-0 leading-relaxed">
                    A diferencia de la venta de criptos (que va al Ahorro, máx 28%), los Airdrops van a la <strong>Base General del IRPF</strong>. Se suman a tu sueldo o facturación. Si tienes un buen salario, ese Airdrop puede tributar al <strong>47% o más</strong>.
                </p>
            </div>

            <h2 className="text-4xl mt-16 mb-6">4. Aportar Liquidez (Liquidity Mining)</h2>
            <p>
                Cuando aportas par (ej: ETH/USDT) a un Pool en Uniswap, recibes a cambio un <strong>LP Token</strong>. Volvemos al problema del punto 1: <strong>Es una permuta.</strong>
            </p>
            <p>
                Estás vendiendo tu ETH y tu USDT para comprar el "LP Token". Tienes que declarar la ganancia generada hasta ese momento. Y cuando deshagas la posición, tendrás que calcular el nuevo valor, asumiendo el posible <em>Impermanent Loss</em> como menor valor de transmisión.
            </p>
            
            <p className="text-xl font-bold mt-12">¿Te explota la cabeza? Es normal.</p>
            <p>
                La normativa española es rígida para un entorno DeFi fluido. Intentar cuadrar esto en Excel es suicida. Necesitamos volcar tus datos on-chain y clasificar operación por operación.
            </p>

        </div>

        <div className="mt-20 p-10 md:p-14 rounded-[2rem] bg-slate-900 text-white text-center border border-slate-800 shadow-2xl relative overflow-hidden">
            <div className="relative z-10">
                <h3 className="text-3xl font-black mb-4">Déjanos el "Data Entry" a nosotros</h3>
                <p className="text-slate-300 text-lg mb-8 max-w-xl mx-auto">
                    En el <strong>Pack Cripto Trader</strong>, incluimos la licencia de CoinTracking y revisamos manualmente los LP Tokens y Liquid Staking para que no pagues de más por error.
                </p>
                <Link href="/contratar?tab=cripto" className="inline-block px-10 py-4 bg-purple-600 hover:bg-purple-500 font-bold rounded-xl transition transform hover:-translate-y-1">
                    Ver Servicio Auditoría
                </Link>
            </div>
        </div>
      </article>
      <Footer />
    </main>
  );
}