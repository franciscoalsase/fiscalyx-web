import Link from 'next/link';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { Calculator } from '@/components/Calculator';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Cuota Autónomos 2025: Calculadora Real y Tramos | FiscalYX',
  description: 'No te fíes de las tablas genéricas. Calcula tu cuota exacta de Seguridad Social según tu Rendimiento Neto real.',
};

export default function BlogPost() {
  return (
    <main className="font-sans text-slate-900 bg-white selection:bg-green-500 selection:text-white">
      <Navbar />
      
      <header className="relative pt-32 pb-20 bg-white border-b border-slate-100 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] [background-size:16px_16px] opacity-50"></div>
        
        <div className="max-w-4xl mx-auto px-6 relative z-10 text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-green-50 border border-green-200 text-green-700 text-sm font-bold uppercase tracking-widest mb-8">
              <span className="w-2 h-2 rounded-full bg-green-600 animate-pulse"></span> Seguridad Social 2025
            </div>
            <h1 className="text-5xl md:text-7xl font-black text-slate-900 mb-8 leading-[1.1] tracking-tight">
                Calculadora de Cuota Autónomos: ¿Cuánto te van a quitar este mes?
            </h1>
            <p className="text-2xl text-slate-600 leading-relaxed max-w-3xl mx-auto mb-10 font-medium">
                El sistema de cotización por ingresos reales es un laberinto. Usa nuestra herramienta para saber tu tramo exacto y evitar la regularización sorpresa.
            </p>
        </div>
      </header>

      <article className="max-w-3xl mx-auto px-6 py-20">
        
        <div className="prose prose-xl prose-slate max-w-none mb-12">
            <p>
                Olvídate de elegir cuánto quieres pagar. Ahora la Seguridad Social te dice cuánto <strong>tienes</strong> que pagar. Tu cuota depende de tu <strong>Rendimiento Neto</strong> (Ingresos - Gastos + 7%).
            </p>
            <p className="font-bold text-center">👇 Usa la calculadora para salir de dudas:</p>
        </div>

        {/* CALCULADORA DESTACADA */}
        <div className="my-16 transform transition-all hover:scale-[1.01] duration-500 shadow-2xl rounded-3xl overflow-hidden border-4 border-slate-100 bg-white z-20 relative">
            <Calculator />
        </div>

        <div className="prose prose-xl prose-slate max-w-none 
            prose-headings:font-black prose-headings:tracking-tight prose-headings:text-slate-900 
            prose-p:text-slate-600 prose-p:leading-8 
            prose-strong:text-green-600 prose-strong:font-black">
            
            <h2 className="text-4xl mt-16 mb-8">La Trampa de la Regularización</h2>
            <p>
                Muchos autónomos ponen la cuota mínima para tener más liquidez hoy. <strong>Error.</strong>
            </p>
            <p>
                Lo que pagas mes a mes es un "adelanto". Al año siguiente, la Seguridad Social cruza datos con Hacienda. Si has ganado más de lo que dijiste, te llegará una carta pidiendo <strong>toda la diferencia de golpe</strong>.
            </p>

            <div className="bg-yellow-50 border-l-8 border-yellow-500 p-8 my-10 rounded-r-2xl shadow-sm not-prose">
                <h4 className="font-black text-yellow-900 text-2xl mb-3">💡 Estrategia FiscalYX</h4>
                <p className="text-yellow-800 text-lg m-0 leading-relaxed">
                    Nosotros ajustamos tu cuota <strong>cada trimestre</strong>. Si vemos que estás facturando más, subimos la cuota gradualmente para que no tengas sustos de 3.000€ el año que viene.
                </p>
            </div>

            <h2 className="text-4xl mt-16 mb-8">Tarifa Plana: ¿Para quién?</h2>
            <p>
                Solo para nuevos autónomos (o si no lo has sido en 2 años). Son <strong>80€/mes</strong> durante 12 meses.
            </p>
            <p>
                <strong>El truco del año 2:</strong> Puedes prorrogarla otros 12 meses SOLO si tus ingresos netos no superan el Salario Mínimo (SMI). Si ganas un euro más, pasas a cuota normal con efectos retroactivos. Cuidado.
            </p>
        </div>

        <div className="mt-24 bg-slate-900 text-white p-12 md:p-16 rounded-[2rem] text-center shadow-2xl border border-slate-800 relative overflow-hidden">
            <div className="relative z-10">
                <h3 className="text-3xl md:text-5xl font-black mb-6 tracking-tight">Te damos de alta en 24h</h3>
                <p className="text-slate-300 text-xl mb-10 max-w-2xl mx-auto leading-relaxed">
                    Nos encargamos del papeleo en Hacienda y Seguridad Social. Pedimos tu Tarifa Plana y configuramos tu cuota óptima.
                </p>
                <div className="flex flex-col sm:flex-row justify-center gap-4">
                    <Link href="/contratar?tab=autonomo" className="inline-block px-10 py-5 bg-green-600 hover:bg-green-500 text-white font-black text-lg rounded-2xl transition shadow-xl hover:-translate-y-1">
                        Empezar Plan Basic (59€)
                    </Link>
                </div>
            </div>
        </div>
      </article>
      <Footer />
    </main>
  );
}