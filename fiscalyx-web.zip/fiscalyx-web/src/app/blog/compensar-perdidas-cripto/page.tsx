import Link from 'next/link';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Compensar Pérdidas Cripto: No pierdas tu dinero dos veces | FiscalYX',
  description: '¿Mercado bajista? Aprende a usar tus pérdidas para pagar CERO impuestos en los próximos 4 años. Guía de compensación.',
};

export default function BlogPost() {
  return (
    <main className="font-sans text-slate-900 bg-white selection:bg-red-500 selection:text-white">
      <Navbar />
      
      <header className="relative pt-32 pb-20 bg-[#0B0F19] text-white overflow-hidden">
        <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-red-900/20 rounded-full blur-[120px] -translate-y-1/2"></div>
        
        <div className="max-w-4xl mx-auto px-6 relative z-10 text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-red-900/30 border border-red-500/30 text-red-400 text-sm font-bold uppercase tracking-widest mb-8">
              <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></span> Optimización Fiscal
            </div>
            <h1 className="text-5xl md:text-7xl font-black mb-8 leading-[1.1] tracking-tight">
                ¿Perdiste dinero en Cripto? Úsalo para dejar de pagar impuestos
            </h1>
            <p className="text-2xl text-slate-400 leading-relaxed max-w-3xl mx-auto mb-10 font-medium">
                Las pérdidas patrimoniales son un activo financiero valiosísimo. Te enseñamos a guardarlas para el futuro bull-run.
            </p>
        </div>
      </header>

      <article className="max-w-3xl mx-auto px-6 py-20">
        
        <div className="bg-red-50/80 border-2 border-red-100 rounded-3xl p-8 md:p-10 mb-16 shadow-sm">
             <h3 className="text-red-900 font-black text-2xl mb-6 flex items-center gap-3">
                📉 La Estrategia
             </h3>
             <p className="text-slate-800 text-lg font-medium leading-relaxed">
                Si este año cierras en negativo, no te fustigues. Hacienda te permite guardar esa "base imponible negativa" durante <strong>4 años</strong> para restar futuros beneficios. Es como un cupón de descuento fiscal.
             </p>
        </div>

        <div className="prose prose-xl prose-slate max-w-none 
            prose-headings:font-black prose-headings:tracking-tight prose-headings:text-slate-900 
            prose-p:text-slate-600 prose-p:leading-8 
            prose-strong:text-red-600 prose-strong:font-black">
            
            <h2 className="text-4xl mt-16 mb-8">La Regla de los 4 Años</h2>
            <p>
                <em>Ejemplo Práctico:</em><br/>
                En 2024 pierdes 20.000€ con una memecoin. No pagas nada este año.
                En 2025 llega el Bull Run y ganas 15.000€ con Bitcoin.
            </p>
            <p>
                <strong>¿Cuánto pagas en 2025? CERO.</strong> Usas 15.000€ de tus pérdidas guardadas para anular la ganancia. Y aún te sobran 5.000€ para 2026.
            </p>

            <div className="bg-slate-900 text-white p-8 my-10 rounded-2xl shadow-xl not-prose">
                <h4 className="font-black text-white text-2xl mb-3">❗ El Error Fatal</h4>
                <p className="text-slate-300 text-lg m-0 leading-relaxed">
                    Para tener derecho a esto, <strong>TIENES QUE DECLARAR LA PÉRDIDA</strong> en la Renta del año en que ocurre. Muchos inversores piensan: "Como he perdido, no hago la Renta". Error. Si no la registras ahora, pierdes el derecho a usarla en el futuro.
                </p>
            </div>

            <h2 className="text-4xl mt-16 mb-8">Compensación Cruzada (Staking)</h2>
            <p>
                Además, la ley permite algo genial: Si te sobran pérdidas de venta (patrimoniales), puedes usarlas para compensar hasta un <strong>25%</strong> de tus rendimientos de capital mobiliario (intereses de cuentas, dividendos o staking pasivo).
            </p>
            <p>
                Es decir, tus malas inversiones en trading pueden bajar los impuestos que pagas por tus dividendos seguros.
            </p>
        </div>

        <div className="mt-24 bg-red-600 text-white p-12 md:p-16 rounded-[2rem] text-center shadow-2xl relative overflow-hidden">
            <div className="relative z-10">
                <h3 className="text-3xl md:text-5xl font-black mb-6 tracking-tight">No regales dinero a Hacienda</h3>
                <p className="text-red-100 text-xl mb-10 max-w-2xl mx-auto leading-relaxed">
                    Revisamos tu historial de operaciones para aflorar todas las pérdidas posibles (comisiones, gas fees, ventas a pérdidas) y optimizar tu factura.
                </p>
                <div className="flex flex-col sm:flex-row justify-center gap-4">
                    <Link href="/contratar?tab=cripto" className="inline-block px-10 py-5 bg-white text-red-700 font-black text-lg rounded-2xl transition shadow-xl hover:-translate-y-1">
                        Contratar Pack Renta
                    </Link>
                </div>
            </div>
        </div>
      </article>
      <Footer />
    </main>
  );
}