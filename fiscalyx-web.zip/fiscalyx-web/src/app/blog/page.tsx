'use client';

import { useState } from 'react';
import Link from 'next/link';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { FadeIn } from '@/components/FadeIn';

// TUS 10 ARTÍCULOS ESTRATÉGICOS
const POSTS = [
  {
    slug: 'modelo-721-criptomonedas-guia',
    title: 'Modelo 721: La Guía Definitiva para evitar multas en 2025',
    excerpt: 'Si tienes más de 50.000€ en criptomonedas en el extranjero, Hacienda te vigila. Descubre plazos, sanciones y cómo presentarlo.',
    category: 'Cripto',
    date: '28 Nov 2024',
    readTime: '8 min',
    image: '🚨',
    featured: true // Marcamos este como destacado
  },
  {
    slug: 'retirar-binance-hacienda',
    title: 'Cómo retirar fondos de Binance a tu banco sin bloqueos',
    excerpt: 'Los bancos tradicionales están bloqueando transferencias cripto. Te enseñamos la operativa segura y trazable.',
    category: 'Cripto',
    date: '15 Nov 2024',
    readTime: '5 min',
    image: '🏦',
    featured: false
  },
  {
    slug: 'gastos-deducibles-autonomos',
    title: 'Gastos Deducibles 2025: La lista completa para pagar menos',
    excerpt: '¿Puedo deducir la luz de casa? ¿Y las comidas? Desmontamos mitos y te damos la lista segura ante una inspección.',
    category: 'Autónomos',
    date: '27 Nov 2024',
    readTime: '6 min',
    image: '📉',
    featured: false
  },
  {
    slug: 'staking-defi-fiscalidad',
    title: 'Staking y DeFi: ¿Rendimiento de capital o Actividad Económica?',
    excerpt: 'La zona gris de la fiscalidad cripto. Aprende cómo clasificar tus ingresos pasivos para no tener problemas.',
    category: 'Cripto',
    date: '25 Nov 2024',
    readTime: '10 min',
    image: '🥩',
    featured: false
  },
  {
    slug: 'factura-electronica-obligatoria',
    title: 'Factura Electrónica: Todo lo que cambia para tu negocio',
    excerpt: 'La Ley Crea y Crece obliga a emitir facturas electrónicas. Te explicamos los plazos y qué software necesitas.',
    category: 'Empresa',
    date: '22 Nov 2024',
    readTime: '4 min',
    image: '⚡',
    featured: false
  },
  {
    slug: 'permutas-cripto-swaps',
    title: 'El peligro de los Swaps: Por qué debes declarar cada cambio',
    excerpt: 'Muchos inversores creen que solo se declara al pasar a Euro. Error grave. Te explicamos el criterio FIFO en permutas.',
    category: 'Cripto',
    date: '20 Nov 2024',
    readTime: '5 min',
    image: '🔄',
    featured: false
  },
  {
    slug: 'autonomo-vs-sociedad',
    title: '¿Cuándo me interesa pasar de Autónomo a Sociedad Limitada?',
    excerpt: 'Analizamos la barrera de los 40.000€ - 60.000€ de beneficio y cuándo compensa fiscalmente dar el salto.',
    category: 'Empresa',
    date: '18 Nov 2024',
    readTime: '7 min',
    image: '🏢',
    featured: false
  },
  {
    slug: 'compensar-perdidas-cripto',
    title: '¿Perdiste dinero en Cripto? Úsalo para bajar tus impuestos',
    excerpt: 'Las pérdidas no son el fin. Puedes compensarlas con ganancias de hasta 4 años siguientes. Te explicamos cómo.',
    category: 'Cripto',
    date: '10 Nov 2024',
    readTime: '4 min',
    image: '📉',
    featured: false
  },
  {
    slug: 'cuota-autonomos-2025',
    title: 'Nuevas cuotas de autónomos 2025: Tablas y Tramos',
    excerpt: 'El sistema de cotización por ingresos reales se ajusta. Mira en qué tramo estás y cuánto pagarás de cuota.',
    category: 'Autónomos',
    date: '05 Nov 2024',
    readTime: '3 min',
    image: '📊',
    featured: false
  },
  {
    slug: 'ley-crea-y-crece',
    title: 'Crear una empresa con 1 euro: Mitos y Realidades',
    excerpt: 'Ya no necesitas 3.000€ para constituir una S.L., pero hay letra pequeña en la responsabilidad. Lo analizamos.',
    category: 'Empresa',
    date: '01 Nov 2024',
    readTime: '5 min',
    image: '🚀',
    featured: false
  }
];

export default function BlogPage() {
  const [filter, setFilter] = useState('all');

  // Lógica de filtrado
  const featuredPost = POSTS.find(post => post.featured);
  const filteredPosts = POSTS.filter(post => {
    if (post.featured) return false; // El destacado ya sale arriba
    if (filter === 'all') return true;
    if (filter === 'cripto') return post.category === 'Cripto';
    if (filter === 'pymes') return post.category === 'Autónomos' || post.category === 'Empresa';
    return true;
  });

  return (
    <main className="font-sans text-slate-600 bg-white">
      <Navbar />
      
      {/* CABECERA DEL BLOG */}
      <section className="pt-32 pb-12 bg-slate-50 border-b border-slate-200">
        <div className="max-w-4xl mx-auto px-6 text-center">
            <span className="text-brand-blue font-bold tracking-widest uppercase text-xs mb-4 block">Academia FiscalYX</span>
            <h1 className="text-4xl md:text-6xl font-black text-brand-dark mb-6">
              Conocimiento es Ahorro
            </h1>
            <p className="text-xl text-slate-500 max-w-2xl mx-auto mb-8">
              Guías prácticas redactadas por economistas para proteger tu patrimonio cripto y optimizar tu negocio.
            </p>

            {/* FILTROS DE CATEGORÍA */}
            <div className="inline-flex flex-wrap justify-center gap-2 bg-white p-2 rounded-xl shadow-sm border border-slate-200">
                <button 
                    onClick={() => setFilter('all')}
                    className={`px-6 py-2 rounded-lg text-sm font-bold transition-all ${filter === 'all' ? 'bg-brand-dark text-white' : 'text-slate-500 hover:bg-slate-100'}`}
                >
                    Todos
                </button>
                <button 
                    onClick={() => setFilter('cripto')}
                    className={`px-6 py-2 rounded-lg text-sm font-bold transition-all ${filter === 'cripto' ? 'bg-purple-600 text-white' : 'text-slate-500 hover:bg-purple-50 hover:text-purple-600'}`}
                >
                    💎 Cripto & Web3
                </button>
                <button 
                    onClick={() => setFilter('pymes')}
                    className={`px-6 py-2 rounded-lg text-sm font-bold transition-all ${filter === 'pymes' ? 'bg-blue-600 text-white' : 'text-slate-500 hover:bg-blue-50 hover:text-blue-600'}`}
                >
                    🏢 Autónomos & Pymes
                </button>
            </div>
        </div>
      </section>

      <section className="py-12 md:py-20 bg-white">
        <div className="max-w-6xl mx-auto px-6">
            
            {/* POST DESTACADO (HERO POST) - Solo visible si no hay filtros o si es cripto */}
            {(filter === 'all' || filter === 'cripto') && featuredPost && (
                <div className="mb-16">
                    <Link href={`/blog/${featuredPost.slug}`} className="group block relative rounded-3xl overflow-hidden shadow-2xl aspect-[16/9] md:aspect-[21/9]">
                        <div className="absolute inset-0 bg-gradient-to-r from-brand-dark to-purple-900 transition-transform duration-700 group-hover:scale-105"></div>
                        {/* Patrón decorativo */}
                        <div className="absolute top-0 right-0 w-1/2 h-full bg-white/5 skew-x-12 transform origin-bottom-left"></div>
                        
                        <div className="absolute inset-0 flex flex-col justify-center items-start p-8 md:p-16 text-white">
                            <span className="bg-white/20 backdrop-blur-md border border-white/20 text-white text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider mb-4">
                                🔥 Artículo Destacado
                            </span>
                            <h2 className="text-3xl md:text-5xl font-black mb-4 max-w-2xl leading-tight group-hover:text-purple-200 transition">
                                {featuredPost.title}
                            </h2>
                            <p className="text-lg text-white/80 max-w-xl mb-8 hidden md:block">
                                {featuredPost.excerpt}
                            </p>
                            <span className="flex items-center gap-2 font-bold border-b border-white/30 pb-1">
                                Leer Guía Completa <span>→</span>
                            </span>
                        </div>
                    </Link>
                </div>
            )}

            {/* GRID DE ARTÍCULOS */}
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                {filteredPosts.map((post, index) => (
                    <FadeIn key={post.slug} delay={index * 0.03} className="group bg-white border border-slate-200 rounded-2xl overflow-hidden hover:shadow-xl hover:-translate-y-1 transition-all duration-300 flex flex-col h-full relative">
                        <Link href={`/blog/${post.slug}`} className="flex-1 p-8 flex flex-col">
                            
                            {/* Cabecera de tarjeta con Icono y Categoría */}
                            <div className="flex justify-between items-start mb-6">
                                <div className="w-12 h-12 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-center text-2xl shadow-sm group-hover:scale-110 transition-transform duration-300">
                                    {post.image}
                                </div>
                                <span className={`text-[10px] font-bold uppercase tracking-wider px-3 py-1 rounded-full border ${
                                    post.category === 'Cripto' 
                                    ? 'bg-purple-50 text-purple-700 border-purple-100' 
                                    : 'bg-blue-50 text-blue-700 border-blue-100'
                                }`}>
                                    {post.category}
                                </span>
                            </div>

                            {/* Título y Extracto */}
                            <h2 className="text-xl font-bold text-brand-dark mb-3 group-hover:text-brand-blue transition-colors leading-snug">
                                {post.title}
                            </h2>
                            <p className="text-sm text-slate-500 mb-8 line-clamp-3 flex-grow leading-relaxed">
                                {post.excerpt}
                            </p>

                            {/* Pie de tarjeta */}
                            <div className="flex items-center justify-between text-xs font-medium mt-auto pt-5 border-t border-slate-100">
                                <div className="flex items-center gap-2 text-slate-400">
                                    <span>📅 {post.date}</span>
                                    <span>•</span>
                                    <span>⏱ {post.readTime}</span>
                                </div>
                                <span className="text-brand-blue font-bold flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity transform translate-x-[-10px] group-hover:translate-x-0 duration-300">
                                    Leer más →
                                </span>
                            </div>
                        </Link>
                    </FadeIn>
                ))}
            </div>
        </div>
      </section>

      {/* CTA NEWSLETTER */}
      <section className="py-24 bg-brand-dark text-white relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-brand-blue/20 via-transparent to-transparent opacity-40"></div>
          
          <div className="max-w-3xl mx-auto px-6 text-center relative z-10">
              <h3 className="text-3xl font-black mb-6">¿Prefieres que lo hagamos nosotros?</h3>
              <p className="text-slate-300 mb-10 text-lg max-w-xl mx-auto leading-relaxed">
                  Si leer sobre impuestos no es lo tuyo, tenemos una solución mejor: delega en expertos.
              </p>
              <Link href="/#quiz-section" className="inline-flex items-center gap-2 px-8 py-4 bg-white text-brand-dark font-bold rounded-xl hover:bg-blue-50 transition shadow-xl hover:shadow-2xl hover:-translate-y-1">
                  <span>⚡</span> Hacer Diagnóstico Rápido
              </Link>
          </div>
      </section>

      <Footer />
    </main>
  );
}