import Link from 'next/link';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Gastos Deducibles: La lista "Insider" 2025 | FiscalYX',
  description: 'Olvídate de los consejos genéricos. Analizamos sentencias recientes sobre deducción de suministros, vehículos y dietas. Lo que tu gestor no te cuenta.',
};

export default function BlogPost() {
  return (
    <main className="font-sans text-slate-900 bg-white selection:bg-blue-500 selection:text-white">
      <Navbar />
      
      <header className="relative pt-32 pb-20 bg-white border-b border-slate-100 overflow-hidden">
        {/* Fondo sutil */}
        <div className="absolute inset-0 bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] [background-size:16px_16px] opacity-50"></div>
        
        <div className="max-w-4xl mx-auto px-6 relative z-10 text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-blue-50 border border-blue-200 text-blue-700 text-sm font-bold uppercase tracking-widest mb-8">
              <span className="w-2 h-2 rounded-full bg-blue-600 animate-pulse"></span> Estrategia Fiscal 2025
            </div>
            <h1 className="text-5xl md:text-7xl font-black text-slate-900 mb-8 leading-[1.1] tracking-tight">
                Gastos Deducibles: Dejemos de hablar de "tickets" y hablemos de dinero
            </h1>
            <p className="text-2xl text-slate-600 leading-relaxed max-w-3xl mx-auto mb-10 font-medium">
                La mayoría de autónomos pierde entre 2.000€ y 4.000€ al año por miedo a deducir gastos legítimos. Analizamos la jurisprudencia reciente para que reclames lo que es tuyo.
            </p>
             <div className="flex items-center justify-center gap-4 text-sm font-bold text-slate-500 border-t border-slate-200 pt-8 w-fit mx-auto uppercase tracking-wide">
                <span>⏱ Lectura 5 min</span>
                <span>•</span>
                <span>Por Francisco Seva</span>
            </div>
        </div>
      </header>

      <article className="max-w-3xl mx-auto px-6 py-20">
        
        {/* CAJA RESUMEN */}
        <div className="bg-blue-50/80 border-2 border-blue-100 rounded-3xl p-8 md:p-10 mb-16 shadow-sm">
            <h3 className="text-blue-900 font-black text-2xl mb-6 flex items-center gap-3">
                ⚡ Las Claves "Insider"
            </h3>
            <ul className="space-y-4 text-slate-800 text-lg font-medium">
                <li className="flex gap-4 items-start"><span className="text-blue-600 text-2xl mt-1">➜</span> <span><strong className="text-blue-700 font-black">El mito del 50% del coche:</strong> Puedes deducir el 100% del IVA si demuestras la afectación exclusiva (y te decimos cómo).</span></li>
                <li className="flex gap-4 items-start"><span className="text-blue-600 text-2xl mt-1">➜</span> <span><strong className="text-blue-700 font-black">Suministros en casa:</strong> La fórmula del 30% es una trampa. Te enseñamos a instalar contadores divisionales para deducir el 100%.</span></li>
                <li className="flex gap-4 items-start"><span className="text-blue-600 text-2xl mt-1">➜</span> <span><strong className="text-blue-700 font-black">Tickets perdidos:</strong> Cómo digitalizar facturas antiguas para recuperar IVA de hasta 4 años atrás.</span></li>
            </ul>
        </div>

        {/* AQUÍ ESTÁ LA MAGIA DEL DISEÑO:
            - prose-xl: Texto más grande por defecto.
            - prose-headings:font-black: Títulos super gruesos.
            - prose-strong:text-brand-blue: Negritas en azul corporativo.
        */}
        <div className="prose prose-xl prose-slate max-w-none 
            prose-headings:font-black prose-headings:tracking-tight prose-headings:text-slate-900 
            prose-p:text-slate-600 prose-p:leading-8 
            prose-li:text-slate-600 
            prose-strong:text-blue-600 prose-strong:font-black
            prose-a:text-blue-600 prose-a:font-bold prose-a:no-underline hover:prose-a:underline">
            
            <p className="lead text-2xl text-slate-800 font-semibold mb-12 border-l-4 border-blue-500 pl-6 italic">
                Hacienda juega con el miedo. Su estrategia es simple: hacer la norma tan ambigua que prefieras no deducir nada &quot;por si acaso&quot;. En FiscalYX, cambiamos esa dinámica aplicando la ley estrictamente a tu favor.
            </p>

            <h2 className="text-4xl mt-16 mb-8">1. Vehículos: Rompiendo la regla del 50%</h2>
            <p>
                La Agencia Tributaria (AEAT) asume por defecto que usas tu coche al 50% para ocio. Pero el <strong>Tribunal Superior de Justicia</strong> ha fallado repetidamente a favor del contribuyente cuando la prueba es sólida.
            </p>
            <p className="font-bold text-slate-900 mt-8 mb-4">¿Cómo blindar la deducción del 100%?</p>
            <ul className="marker:text-blue-500">
                <li><strong>Registro de Kilometraje:</strong> Apps que geolocalizan tus rutas profesionales.</li>
                <li><strong>Rotulación:</strong> Rotular el vehículo dificulta su uso personal y es una prueba de afectación.</li>
                <li><strong>Garaje en la oficina:</strong> Si el coche &quot;duerme&quot; en el domicilio fiscal de la actividad, la presunción mejora.</li>
            </ul>

            <h2 className="text-4xl mt-16 mb-8">2. Suministros en Casa: El truco del contador</h2>
            <p>
                Si trabajas en casa, la ley te permite deducir el 30% de la proporción de metros de tu despacho. En la práctica, esto se traduce en unos ridículos 5€ al mes de ahorro.
            </p>
            
            <div className="bg-green-50 border-l-8 border-green-500 p-8 my-10 rounded-r-2xl shadow-sm not-prose">
                <h4 className="font-black text-green-900 text-2xl mb-3">💡 El Hack del Contador Independiente</h4>
                <p className="text-green-800 text-lg m-0 leading-relaxed">
                    Si instalas un <strong>contador divisional</strong> o contratas una segunda línea de fibra exclusiva para el despacho, <strong>la deducción pasa a ser del 100%</strong> de esa factura, porque ya no hay &quot;uso mixto&quot;. La inversión en la instalación se amortiza en el primer año de ahorro fiscal.
                </p>
            </div>

            <h2 className="text-4xl mt-16 mb-8">3. Dietas: No es solo comer, es &quot;dónde&quot;</h2>
            <p>
                Puedes deducir 26,67€ diarios. Pero Hacienda cruza datos de tu tarjeta con tu ubicación.
            </p>
            <p>
                <strong>El error común:</strong> Comer al lado de tu casa. Hacienda entiende que eso es &quot;comida doméstica&quot;.
            </p>
            <p>
                <strong>La estrategia:</strong> La dieta se justifica por el desplazamiento. El gasto debe producirse en un municipio distinto al de tu domicilio fiscal o en un radio que justifique la imposibilidad de ir a casa. Guarda la agenda de reuniones. Si comiste en el Restaurante X, ten una entrada en Google Calendar a esa hora con &quot;Reunión Cliente Y&quot;.
            </p>

            <h2 className="text-4xl mt-16 mb-8">4. Gastos Tecnológicos &quot;Ocultos&quot;</h2>
            <p>Muchos clientes digitales olvidan deducir suscripciones que pagan en dólares o servicios SaaS:</p>
            <ul className="marker:text-blue-500">
                <li><strong>Hosting y Dominios:</strong> Deducibles 100%.</li>
                <li><strong>Suscripciones de Software:</strong> (Adobe, Zoom, ChatGPT Plus) Deducibles 100%.</li>
                <li><strong>Comisiones de Pasarelas de Pago:</strong> (Stripe, PayPal) Son gastos financieros deducibles.</li>
                <li><strong>Gas Fees (Ethereum):</strong> Si eres inversor profesional, las comisiones de red son un gasto necesario para tu actividad.</li>
            </ul>

            <div className="bg-red-50 border-l-8 border-red-500 p-8 my-10 rounded-r-2xl shadow-sm not-prose">
                <h4 className="font-black text-red-900 text-2xl mb-3">⛔ La Línea Roja (Danger Zone)</h4>
                <p className="text-red-800 text-lg m-0 leading-relaxed">
                    No intentes colar tickets de supermercado de fin de semana ni ropa de &quot;representación&quot; (trajes). Las sentencias son claras: la ropa solo es deducible si es uniforme o ropa de seguridad. Un traje Armani no es un EPI.
                </p>
            </div>
        </div>

        <div className="mt-24 bg-slate-900 text-white p-12 md:p-16 rounded-[2rem] text-center shadow-2xl border border-slate-800 relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-blue-900/40 via-transparent to-transparent"></div>
            <div className="relative z-10">
                <h3 className="text-3xl md:text-5xl font-black mb-6 tracking-tight">Auditoría de Gastos Inversa</h3>
                <p className="text-slate-300 text-xl mb-10 max-w-2xl mx-auto leading-relaxed">
                    En nuestro <strong>Plan Pro</strong>, no solo contabilizamos lo que nos das. Revisamos tus extractos bancarios para detectar pagos que olvidaste pedir factura y los recuperamos por ti.
                </p>
                <div className="flex flex-col sm:flex-row justify-center gap-4">
                    <Link href="/contratar?tab=autonomo" className="inline-block px-10 py-5 bg-blue-600 hover:bg-blue-500 text-white font-black text-lg rounded-2xl transition shadow-xl hover:-translate-y-1">
                        Ver Plan Pro (89€/mes)
                    </Link>
                </div>
            </div>
        </div>
      </article>
      <Footer />
    </main>
  );
}