import Link from 'next/link';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Cómo justificar fondos Cripto ante el Banco: Guía Anti-Bloqueo | FiscalYX',
  description: 'Checklist de documentos que te pedirá Compliance. Cómo hacer un dossier de trazabilidad de fondos para retirar ganancias sin miedo.',
};

export default function BlogPost() {
  return (
    <main className="font-sans text-slate-900 bg-white selection:bg-green-500 selection:text-white">
      <Navbar />
      
      <header className="relative pt-32 pb-20 bg-white border-b border-slate-100 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] [background-size:16px_16px] opacity-50"></div>
        
        <div className="max-w-4xl mx-auto px-6 relative z-10 text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-green-50 border border-green-200 text-green-700 text-sm font-bold uppercase tracking-widest mb-8">
              <span className="w-2 h-2 rounded-full bg-green-600 animate-pulse"></span> Compliance Bancario
            </div>
            <h1 className="text-5xl md:text-7xl font-black text-slate-900 mb-8 leading-[1.1] tracking-tight">
                Guía Anti-Bloqueo: Qué documentación entregar al banco al retirar Cripto
            </h1>
            <p className="text-2xl text-slate-600 leading-relaxed max-w-3xl mx-auto mb-10 font-medium">
                No basta con decir &quot;he ganado invirtiendo&quot;. Te enseñamos a montar el Dossier de Trazabilidad que exigen los departamentos de PBC (Prevención de Blanqueo).
            </p>
        </div>
      </header>

      <article className="max-w-3xl mx-auto px-6 py-20">
        
        <div className="prose prose-xl prose-slate max-w-none 
            prose-headings:font-black prose-headings:text-slate-900 
            prose-p:text-slate-600 prose-p:leading-8 
            prose-strong:text-green-700 prose-strong:font-black">
            
            <p>
                El escenario es clásico: Haces una transferencia de 20.000€ desde Kraken a tu BBVA. A las 24h, la cuenta está bloqueada y te llama tu gestor pidiendo &quot;justificantes&quot;. Si envías una captura de pantalla de la app, te cerrarán la cuenta. Necesitas ser profesional.
            </p>

            {/* CAMBIO: EL ERROR CRÍTICO AHORA VA PRIMERO PARA CAPTAR ATENCIÓN */}
            <div className="bg-red-50 border-l-8 border-red-500 p-8 my-10 rounded-r-2xl shadow-sm not-prose">
                <h4 className="font-black text-red-900 text-2xl mb-3">⛔ Error Crítico: Lo que NUNCA debes decir</h4>
                <p className="text-red-800 text-lg m-0 leading-relaxed">
                    Nunca digas &quot;fui comprando y vendiendo y no guardé nada&quot;. Si hay un hueco en la trazabilidad (&quot;Agujero Negro&quot;), el banco por política de riesgo cero te invitará a irte. Es preferible reconstruir la historia con herramientas forenses antes de hablar.
                </p>
            </div>

            <h2 className="text-4xl mt-16 mb-8">El Dossier de Origen de Fondos (SoF)</h2>
            <p>
                Para el banco, el dinero es culpable hasta que se demuestre lo contrario. Tu dossier debe responder a tres preguntas cronológicas de forma documental:
            </p>

            <div className="space-y-8 mt-8 not-prose">
                <div className="flex gap-4">
                    <div className="w-10 h-10 rounded-full bg-green-100 text-green-700 flex items-center justify-center font-bold text-xl flex-shrink-0">1</div>
                    <div>
                        <h3 className="text-xl font-bold text-slate-900 mb-2">El Origen FIAT (Entrada)</h3>
                        <p className="text-slate-600">¿De dónde salieron los primeros euros que metiste en cripto en 2018 o 2020? Necesitas extractos bancarios antiguos, nóminas o declaraciones de Renta de aquellos años.</p>
                    </div>
                </div>
                <div className="flex gap-4">
                    <div className="w-10 h-10 rounded-full bg-green-100 text-green-700 flex items-center justify-center font-bold text-xl flex-shrink-0">2</div>
                    <div>
                        <h3 className="text-xl font-bold text-slate-900 mb-2">La Trazabilidad (El camino)</h3>
                        <p className="text-slate-600">El banco necesita ver que el dinero no ha pasado por &quot;Mixers&quot; ni mercados oscuros. Entrega el CSV completo del Exchange y, si es complejo, un diagrama de flujo visual.</p>
                    </div>
                </div>
                <div className="flex gap-4">
                    <div className="w-10 h-10 rounded-full bg-green-100 text-green-700 flex items-center justify-center font-bold text-xl flex-shrink-0">3</div>
                    <div>
                        <h3 className="text-xl font-bold text-slate-900 mb-2">La Salida (El evento fiscal)</h3>
                        <p className="text-slate-600">El justificante de venta de las criptos a Euros dentro del Exchange, con fecha y hora exactas.</p>
                    </div>
                </div>
            </div>

            <h2 className="text-4xl mt-16 mb-8">La Estrategia del &quot;Banco Puente&quot;</h2>
            <p>
                BBVA, Santander o Caixabank tienen filtros AML muy agresivos. Los Neobancos (Revolut, N26) suelen ser más &quot;Crypto-Friendly&quot; porque entienden el ecosistema.
            </p>
            <div className="bg-slate-100 p-6 rounded-xl border-l-4 border-green-600 my-6">
                <p className="font-bold text-slate-900 m-0 mb-2">💡 Consejo Pro:</p>
                <p className="m-0 text-base text-slate-700">
                    Usa la ruta: <strong>Exchange -&gt; Revolut -&gt; Banco Español Principal</strong>. Esto suele reducir las fricciones operativas, aunque recuerda: la obligación de justificar el origen sigue existiendo si te preguntan.
                </p>
            </div>

            <h2 className="text-4xl mt-16 mb-8">La importancia del &quot;Sello&quot;</h2>
            <p>
                A menudo, el oficial de cumplimiento del banco no es experto en criptos. Si le entregas un Excel hecho por ti, desconfía.
                <br/>
                Si le entregas un <strong>Informe de Experto Independiente</strong> firmado por un economista colegiado (nosotros), la percepción de riesgo baja drásticamente. Es un documento oficial que valida que la operativa es coherente.
            </p>

        </div>

        <div className="mt-24 bg-green-900 text-white p-12 md:p-16 rounded-[2rem] text-center shadow-2xl relative overflow-hidden">
            <div className="relative z-10">
                <h3 className="text-3xl font-black mb-6">¿Tu banco te pide explicaciones?</h3>
                <p className="text-green-100 text-xl mb-10 max-w-2xl mx-auto">
                    No improvises. Preparamos tu Dossier de Origen de Fondos certificado para presentar a Compliance.
                </p>
                <Link href="/contratar?tab=cripto" className="inline-block px-10 py-5 bg-white text-green-900 font-black text-lg rounded-2xl transition hover:bg-green-50 shadow-xl hover:-translate-y-1">
                    Consultar Servicio
                </Link>
            </div>
        </div>
      </article>
      <Footer />
    </main>
  );
}