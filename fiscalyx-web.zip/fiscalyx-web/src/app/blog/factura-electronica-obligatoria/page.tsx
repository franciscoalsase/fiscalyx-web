import Link from 'next/link';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Factura Electrónica: La Verdad Incómoda de la Ley Crea y Crece',
  description: 'Olvídate del PDF. Te explicamos qué es Veri*Factu, los plazos reales y por qué Excel ya no sirve para facturar.',
};

export default function BlogPost() {
  return (
    <main className="font-sans text-slate-900 bg-white selection:bg-blue-500 selection:text-white">
      <Navbar />
      
      <header className="relative pt-32 pb-20 bg-white border-b border-slate-100 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] [background-size:16px_16px] opacity-50"></div>
        
        <div className="max-w-4xl mx-auto px-6 relative z-10 text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-blue-50 border border-blue-200 text-blue-700 text-sm font-bold uppercase tracking-widest mb-8">
              <span className="w-2 h-2 rounded-full bg-blue-600 animate-pulse"></span> Obligatorio B2B
            </div>
            <h1 className="text-5xl md:text-7xl font-black text-slate-900 mb-8 leading-[1.1] tracking-tight">
                Factura Electrónica: El fin del PDF y la era del "Gran Hermano" Fiscal
            </h1>
            <p className="text-2xl text-slate-600 leading-relaxed max-w-3xl mx-auto mb-10 font-medium">
                Hacienda quiere saber lo que facturas en tiempo real. Te explicamos la letra pequeña de la Ley Crea y Crece que los vendedores de software no te cuentan.
            </p>
             <div className="flex items-center justify-center gap-4 text-sm font-bold text-slate-500 border-t border-slate-200 pt-8 w-fit mx-auto uppercase tracking-wide">
                <span>⏱ Lectura 4 min</span>
                <span>•</span>
                <span>Por Francisco Seva</span>
            </div>
        </div>
      </header>

      <article className="max-w-3xl mx-auto px-6 py-20">
        
        <div className="bg-blue-50/80 border-2 border-blue-100 rounded-3xl p-8 md:p-10 mb-16 shadow-sm">
            <h3 className="text-blue-900 font-black text-2xl mb-6 flex items-center gap-3">
                ⚡ Impacto Inmediato
            </h3>
            <ul className="space-y-4 text-slate-800 text-lg font-medium">
                <li className="flex gap-4 items-start"><span className="text-blue-600 text-2xl mt-1">➜</span> <span><strong className="text-blue-700 font-black">Adiós Excel/Word:</strong> Las facturas hechas a mano ya no son válidas legalmente. Necesitas "Huella Digital".</span></li>
                <li className="flex gap-4 items-start"><span className="text-blue-600 text-2xl mt-1">➜</span> <span><strong className="text-blue-700 font-black">El Chivato Automático:</strong> Tu cliente tendrá que informar a Hacienda de cuándo paga tu factura. Se acabó el "te pago en 90 días".</span></li>
                <li className="flex gap-4 items-start"><span className="text-blue-600 text-2xl mt-1">➜</span> <span><strong className="text-blue-700 font-black">Multas de hasta 10.000€:</strong> Por no ofrecer acceso digital a tus facturas.</span></li>
            </ul>
        </div>

        <div className="prose prose-xl prose-slate max-w-none 
            prose-headings:font-black prose-headings:tracking-tight prose-headings:text-slate-900 
            prose-p:text-slate-600 prose-p:leading-8 
            prose-li:text-slate-600 
            prose-strong:text-blue-600 prose-strong:font-black">
            
            <p className="lead text-2xl text-slate-800 font-semibold mb-12 border-l-4 border-blue-500 pl-6 italic">
                Muchos autónomos creen que "factura electrónica" es enviar un PDF por email. Grave error. Para la Ley Crea y Crece, eso es papel digitalizado, no una factura estructurada.
            </p>

            <h2 className="text-4xl mt-16 mb-8">¿Qué es el sistema Veri*Factu?</h2>
            <p>
                Es el nuevo estándar técnico. Tu software de facturación debe generar un archivo XML con una "huella" o <strong>hash encadenado</strong>.
            </p>
            <p>
                Esto significa que si emites la Factura 001 y luego la borras o modificas la fecha, <strong>el sistema te delata</strong> porque la Factura 002 no encajará matemáticamente con la huella de la anterior. Se acabó la "contabilidad creativa" de borrar facturas a final de trimestre.
            </p>

            <h2 className="text-4xl mt-16 mb-8">Los Plazos Reales</h2>
            <p>
                No entres en pánico, pero tampoco te duermas. Los plazos cuentan desde la aprobación del Reglamento Técnico (que está al caer):
            </p>
            <ul className="marker:text-blue-500">
                {/* CORREGIDO: > POR &gt; */}
                <li><strong>Grandes (&gt;8M€):</strong> 1 año de margen. Ellas te obligarán a ti a recibir sus facturas electrónicas pronto.</li>
                <li><strong>Autónomos y Pymes:</strong> 2 años de margen.</li>
            </ul>

            <div className="bg-slate-900 text-white p-8 my-10 rounded-2xl shadow-xl not-prose">
                <h4 className="font-black text-white text-2xl mb-3">💡 La Jugada Maestra</h4>
                <p className="text-slate-300 text-lg m-0 leading-relaxed">
                    No esperes a la obligación. Empieza a usar un software homologado HOY. ¿Por qué? Porque digitalizarte te ahorra unas 10 horas al mes de gestión. En <strong>FiscalYX incluimos la licencia de Quipu</strong> en todos los planes para que cumplas la ley sin pagar extra.
                </p>
            </div>
        </div>

        <div className="mt-24 bg-blue-600 text-white p-12 md:p-16 rounded-[2rem] text-center shadow-2xl border border-blue-500 relative overflow-hidden">
            <div className="relative z-10">
                <h3 className="text-3xl md:text-5xl font-black mb-6 tracking-tight">Cumple la Ley sin enterarte</h3>
                <p className="text-blue-100 text-xl mb-10 max-w-2xl mx-auto leading-relaxed">
                    Contrata nuestro Plan Basic y te regalamos el software de facturación adaptado a la Ley Crea y Crece.
                </p>
                <Link href="/contratar?tab=autonomo" className="inline-block px-10 py-5 bg-white text-blue-700 font-black text-lg rounded-2xl transition shadow-xl hover:-translate-y-1">
                    Ver Plan Basic (59€/mes)
                </Link>
            </div>
        </div>
      </article>
      <Footer />
    </main>
  );
}