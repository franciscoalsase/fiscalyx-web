"use client";
import { useEffect } from "react";
import Link from "next/link";
import { Logo } from "@/components/Logo";

export default function CitaPage() {
  
  // Esto carga el script de Calendly cuando entras a la página
  useEffect(() => {
    const head = document.querySelector("head");
    const script = document.createElement("script");
    script.setAttribute("src", "https://assets.calendly.com/assets/external/widget.js");
    head?.appendChild(script);
  }, []);

  return (
    <main className="min-h-screen bg-white font-sans text-slate-600">
      
      {/* BARRA DE NAVEGACIÓN SIMPLIFICADA */}
      <nav className="sticky top-0 z-50 bg-white/95 backdrop-blur border-b border-slate-100 shadow-sm">
        <div className="max-w-7xl mx-auto px-6 h-20 flex justify-between items-center">
          <Link href="/">
            <Logo />
          </Link>
          <Link href="/" className="text-sm font-bold text-brand-blue hover:text-brand-dark transition flex items-center gap-2">
            ← Volver al Inicio
          </Link>
        </div>
      </nav>

      <section className="py-12 px-6 text-center">
        <h1 className="text-3xl md:text-4xl font-extrabold text-brand-dark mb-4">Reserva tu Cita</h1>
        <p className="text-slate-500 mb-8">Elige el día y la hora que mejor te venga. Sin esperas.</p>
        
        {/* WIDGET DE CALENDLY */}
        {/* ⚠️ CAMBIA 'data-url' POR TU ENLACE REAL DE CALENDLY */}
        <div 
          className="calendly-inline-widget w-full" 
          data-url="https://calendly.com/francisco-alsase/30min" 
          style={{ height: "700px" }} 
        ></div>
        
      </section>

      <footer className="py-8 text-center text-xs text-slate-400 border-t border-slate-100">
        © 2025 Fiscalyx Asesores SL.
      </footer>
    </main>
  );
}