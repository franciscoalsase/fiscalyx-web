'use client';

import { useSearchParams } from 'next/navigation';
import { Suspense } from 'react';
import Link from 'next/link';
import { Logo } from '@/components/Logo';
import { FadeIn } from '@/components/FadeIn';

// Componente interno para manejar la lógica del usuario
function CockpitContent() {
  const searchParams = useSearchParams();
  
  // TRUCO: Leemos el nombre de la URL. Si no hay, ponemos "Cliente"
  // Ejemplo de uso: /dashboard?user=Javier+Ruiz
  const userName = searchParams.get('user') || 'Cliente';
  
  // Calculamos las iniciales (Ej: Juan Perez -> JP)
  const initials = userName
    .split(' ')
    .map((n) => n[0])
    .join('')
    .substring(0, 2)
    .toUpperCase();

  return (
    <>
      {/* HEADER APP */}
      <nav className="bg-white border-b border-slate-200 px-6 py-3 sticky top-0 z-50 shadow-sm">
        <div className="max-w-6xl mx-auto flex justify-between items-center">
            <Link href="/" className="hover:opacity-80 transition scale-90 origin-left">
                {/* Asumiendo que tienes un Logo, si no, usa texto */}
                <Logo /> 
            </Link>
            <div className="flex items-center gap-6">
                <div className="text-right hidden sm:block">
                    <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-0.5">Estado Cuenta</div>
                    <div className="text-xs font-bold text-emerald-600 flex items-center justify-end gap-1.5 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-100">
                        <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></span> Activa
                    </div>
                </div>
                {/* INICIALES DINÁMICAS */}
                <div className="flex items-center gap-3 pl-6 border-l border-slate-100">
                    <div className="w-9 h-9 rounded-full bg-brand-dark text-white flex items-center justify-center font-bold text-sm shadow-md ring-2 ring-white cursor-default" title={userName}>
                        {initials}
                    </div>
                </div>
            </div>
        </div>
      </nav>

      <main className="max-w-6xl mx-auto px-6 py-8 lg:py-12">
        
        {/* SALUDO Y AVISOS */}
        <FadeIn direction="up" className="mb-10">
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-6">
                <div>
                    <h1 className="text-3xl md:text-4xl font-black text-brand-dark mb-2 tracking-tight">Hola, {userName}</h1>
                    <p className="text-slate-500">Bienvenido a tu centro de mando fiscal.</p>
                </div>
                <div className="text-xs text-slate-400 font-medium">
                    📅 Hoy es {new Date().toLocaleDateString('es-ES', { weekday: 'long', day: 'numeric', month: 'long' })}
                </div>
            </div>
            
            {/* TARJETA DE AVISOS IMPORTANTE */}
            <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white p-6 rounded-2xl shadow-lg shadow-blue-600/20 flex flex-col md:flex-row items-start md:items-center justify-between gap-6 border border-blue-500/50">
                <div className="flex gap-5">
                    <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center text-2xl backdrop-blur-sm flex-shrink-0">
                        🔔
                    </div>
                    <div>
                        <h4 className="font-bold text-lg mb-1">Cierre del Trimestre en curso</h4>
                        <p className="text-blue-100 text-sm max-w-xl leading-relaxed">
                            Recuerda subir todas tus facturas a <span className="font-bold text-white">Quipu</span> antes del día 15 para que podamos procesar tus impuestos a tiempo.
                        </p>
                    </div>
                </div>
                <a href="https://wa.me/34600000000" target="_blank" className="px-6 py-3 bg-white text-blue-700 font-bold rounded-xl text-sm hover:bg-blue-50 transition whitespace-nowrap shadow-sm">
                    Tengo una duda
                </a>
            </div>
        </FadeIn>

        <div className="grid lg:grid-cols-3 gap-8 items-start">
            
            {/* COLUMNA IZQUIERDA: HERRAMIENTAS */}
            <div className="lg:col-span-2 space-y-8">
                <div>
                    <h3 className="font-bold text-slate-400 text-xs uppercase tracking-wider mb-4 flex items-center gap-2">
                        <span className="w-10 h-[1px] bg-slate-300"></span> Tus Herramientas
                    </h3>
                    
                    <div className="grid md:grid-cols-2 gap-6">
                        {/* QUIPU */}
                        <FadeIn delay={0.1} className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 hover:shadow-lg hover:border-blue-300 transition group relative overflow-hidden flex flex-col">
                            <div className="absolute top-0 right-0 bg-blue-50 px-3 py-1 rounded-bl-lg text-[10px] font-bold text-blue-600 uppercase tracking-wide">Facturación</div>
                            <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-xl flex items-center justify-center text-2xl mb-4 group-hover:scale-110 transition">📊</div>
                            <h4 className="font-bold text-brand-dark text-lg mb-1">Quipu</h4>
                            <p className="text-xs text-slate-500 mb-6 leading-relaxed">Sube tickets, crea facturas y conecta tus bancos para conciliación.</p>
                            <a href="https://getquipu.com/login" target="_blank" className="mt-auto block w-full text-center py-3 rounded-xl bg-brand-dark text-white font-bold text-sm hover:bg-slate-800 transition shadow-md shadow-slate-200">
                                Entrar a Quipu
                            </a>
                        </FadeIn>

                        {/* COINTRACKING */}
                        <FadeIn delay={0.2} className="bg-[#0B0F19] p-6 rounded-2xl shadow-lg border border-slate-800 hover:border-purple-500/50 hover:shadow-purple-900/20 transition group relative overflow-hidden flex flex-col">
                            <div className="absolute top-0 right-0 bg-purple-900/50 px-3 py-1 rounded-bl-lg text-[10px] font-bold text-purple-300 uppercase tracking-wide border-l border-b border-purple-500/20">Cripto</div>
                            <div className="w-12 h-12 bg-white/10 text-white rounded-xl flex items-center justify-center text-2xl mb-4 group-hover:rotate-12 transition">₿</div>
                            <h4 className="font-bold text-white text-lg mb-1">CoinTracking</h4>
                            <p className="text-xs text-slate-400 mb-6 leading-relaxed">Auditoría de cartera, reporte fiscal y cálculo FIFO.</p>
                            <a href="https://cointracking.info" target="_blank" className="mt-auto block w-full text-center py-3 rounded-xl bg-gradient-to-r from-purple-600 to-purple-700 text-white font-bold text-sm hover:from-purple-500 hover:to-purple-600 transition shadow-lg shadow-purple-900/40">
                                Acceder Portfolio
                            </a>
                        </FadeIn>

                        {/* BILKY (DOCUMENTOS) */}
                        <FadeIn delay={0.3} className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 hover:shadow-lg hover:border-orange-300 transition group flex flex-col">
                            <div className="w-12 h-12 bg-orange-100 text-orange-600 rounded-xl flex items-center justify-center text-2xl mb-4 group-hover:scale-110 transition">📂</div>
                            <h4 className="font-bold text-brand-dark text-lg mb-1">Mis Documentos</h4>
                            <p className="text-xs text-slate-500 mb-6 leading-relaxed">Repositorio seguro. Tus impuestos presentados y escrituras.</p>
                            <a href="https://bilky.es/login" target="_blank" className="mt-auto block w-full text-center py-3 rounded-xl border-2 border-slate-100 text-slate-600 font-bold text-sm hover:border-orange-500 hover:text-orange-600 hover:bg-orange-50 transition">
                                Abrir Carpeta
                            </a>
                        </FadeIn>

                        {/* PORTAL DEL EMPLEADO */}
                        <FadeIn delay={0.4} className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 hover:shadow-lg hover:border-green-300 transition group flex flex-col">
                            <div className="w-12 h-12 bg-green-100 text-green-600 rounded-xl flex items-center justify-center text-2xl mb-4 group-hover:scale-110 transition">👥</div>
                            <h4 className="font-bold text-brand-dark text-lg mb-1">Portal RRHH</h4>
                            <p className="text-xs text-slate-500 mb-6 leading-relaxed">Gestión de nóminas, vacaciones y contratos del equipo.</p>
                            <a href="https://bilky.es/login" target="_blank" className="mt-auto block w-full text-center py-3 rounded-xl border-2 border-slate-100 text-slate-600 font-bold text-sm hover:border-green-500 hover:text-green-600 hover:bg-green-50 transition">
                                Gestionar Equipo
                            </a>
                        </FadeIn>
                    </div>
                </div>
            </div>

            {/* COLUMNA DERECHA: AYUDA Y VIDEOS */}
            <div className="space-y-8">
                <div>
                    <h3 className="font-bold text-slate-400 text-xs uppercase tracking-wider mb-4 flex items-center gap-2">
                         <span className="w-10 h-[1px] bg-slate-300"></span> Ayuda Rápida
                    </h3>
                    
                    <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 mb-6">
                        <h4 className="font-bold text-brand-dark mb-4 flex items-center gap-2">
                            🎓 Tutoriales Flash
                        </h4>
                        <ul className="space-y-4">
                            <li>
                                <a href="#" className="flex items-start gap-3 text-sm text-slate-600 hover:text-brand-blue group transition">
                                    <span className="w-6 h-6 rounded bg-slate-100 flex items-center justify-center text-[10px] group-hover:bg-blue-100 flex-shrink-0 mt-0.5 text-slate-400 group-hover:text-brand-blue">▶</span>
                                    <span className="leading-snug">Cómo subir una factura a Quipu con el móvil</span>
                                </a>
                            </li>
                            <li>
                                <a href="#" className="flex items-start gap-3 text-sm text-slate-600 hover:text-brand-blue group transition">
                                    <span className="w-6 h-6 rounded bg-slate-100 flex items-center justify-center text-[10px] group-hover:bg-blue-100 flex-shrink-0 mt-0.5 text-slate-400 group-hover:text-brand-blue">▶</span>
                                    <span className="leading-snug">Conectar tu banco (Renovar Token PSD2)</span>
                                </a>
                            </li>
                            <li>
                                <a href="#" className="flex items-start gap-3 text-sm text-slate-600 hover:text-brand-blue group transition">
                                    <span className="w-6 h-6 rounded bg-slate-100 flex items-center justify-center text-[10px] group-hover:bg-blue-100 flex-shrink-0 mt-0.5 text-slate-400 group-hover:text-brand-blue">▶</span>
                                    <span className="leading-snug">Descargar CSV de Binance/Kraken</span>
                                </a>
                            </li>
                        </ul>
                    </div>

                    <div className="bg-gradient-to-br from-slate-800 to-slate-900 p-6 rounded-2xl shadow-lg text-white relative overflow-hidden">
                        <div className="absolute top-0 right-0 w-24 h-24 bg-white/5 rounded-full blur-2xl -mr-10 -mt-10 pointer-events-none"></div>
                        <h4 className="font-bold mb-2 relative z-10">Soporte Prioritario</h4>
                        <p className="text-xs text-slate-300 mb-5 relative z-10 leading-relaxed">
                            Si tienes una notificación de Hacienda, no esperes. Escríbenos inmediatamente.
                        </p>
                        <a href="https://wa.me/34600000000" target="_blank" className="flex items-center justify-center gap-2 w-full py-3 bg-green-500 hover:bg-green-600 rounded-xl font-bold text-sm transition shadow-lg shadow-green-900/20 relative z-10">
                            <span>💬</span> Abrir WhatsApp
                        </a>
                    </div>
                </div>
            </div>

        </div>
      </main>
    </>
  );
}

export default function Cockpit() {
  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-600">
       {/* SUSPENSE: Necesario porque usamos useSearchParams en Next.js App Router */}
       <Suspense fallback={
         <div className="min-h-screen flex flex-col items-center justify-center">
            <div className="w-8 h-8 border-4 border-brand-blue border-t-transparent rounded-full animate-spin mb-4"></div>
            <p className="text-sm font-bold text-slate-400 animate-pulse">Cargando Fiscalyx Hub...</p>
         </div>
       }>
          <CockpitContent />
       </Suspense>
    </div>
  );
}