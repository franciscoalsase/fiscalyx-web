'use client';

import Link from 'next/link';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { FadeIn } from '@/components/FadeIn';

export default function ServiciosPage() {
  return (
    <main className="font-sans text-slate-600 bg-white">
      <Navbar />
      
      {/* HERO SERVICIOS - ENFOQUE PROFESIONAL */}
      <section className="relative pt-20 pb-32 bg-white border-b border-slate-100 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] [background-size:16px_16px] opacity-50"></div>
        
        <div className="max-w-4xl mx-auto px-6 text-center relative z-10">
            <div className="inline-block px-3 py-1 rounded-full bg-blue-50 border border-blue-100 text-brand-blue text-xs font-bold uppercase tracking-widest mb-6">
              Fiscal • Laboral • Contable
            </div>
            <h1 className="text-4xl md:text-6xl font-black text-brand-dark mb-6 leading-tight">
              Tu departamento financiero, <br/>
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-blue to-purple-600">externalizado.</span>
            </h1>
            <p className="text-xl text-slate-500 max-w-2xl mx-auto mb-10">
              Olvídate del papeleo. Gestionamos tus impuestos, nóminas y contabilidad con la precisión de un economista y la velocidad de una startup.
            </p>
            <div className="flex justify-center gap-4">
                <Link href="/#quiz-section" className="px-8 py-4 bg-brand-dark text-white font-bold rounded-xl hover:bg-slate-800 transition shadow-lg">
                    Presupuesto a Medida
                </Link>
            </div>
        </div>
      </section>

      {/* BLOQUE 1: FISCAL Y CONTABLE */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-6 grid md:grid-cols-2 gap-16 items-center">
            <div className="order-2 md:order-1 bg-blue-50 p-8 rounded-3xl border border-blue-100">
                <div className="w-12 h-12 bg-blue-600 text-white rounded-xl flex items-center justify-center text-2xl mb-6">📊</div>
                <h3 className="text-2xl font-black text-brand-dark mb-6">Fiscalidad Inteligente</h3>
                <ul className="space-y-4">
                    <li className="flex gap-4 items-start">
                        <span className="text-green-500 font-bold">✓</span>
                        <div>
                            <strong className="block text-brand-dark">Presentación de Impuestos</strong>
                            <span className="text-sm">Modelos 303 (IVA), 130 (IRPF), 390 (Resumen Anual), 347 (Operaciones &gt;3000€). Todo al día y sin recargos.</span>
                        </div>
                    </li>
                    <li className="flex gap-4 items-start">
                        <span className="text-green-500 font-bold">✓</span>
                        <div>
                            <strong className="block text-brand-dark">Planificación Pre-Cierre</strong>
                            <span className="text-sm">No esperes a enero. En noviembre nos reunimos para simular tu cierre y aplicar deducciones antes de que acabe el año.</span>
                        </div>
                    </li>
                    <li className="flex gap-4 items-start">
                        <span className="text-green-500 font-bold">✓</span>
                        <div>
                            <strong className="block text-brand-dark">Contabilidad Analítica</strong>
                            <span className="text-sm">Libros oficiales, balances y cuenta de pérdidas y ganancias. Sabe exactamente dónde gana (y pierde) dinero tu empresa.</span>
                        </div>
                    </li>
                </ul>
            </div>
            <div className="order-1 md:order-2">
                <h2 className="text-3xl font-black text-brand-dark mb-6">Más que presentar papeles, protegemos tu dinero.</h2>
                <p className="text-slate-600 mb-6 leading-relaxed">
                    La mayoría de gestorías online se limitan a procesar lo que tú les envías. Nosotros no. <strong>Revisamos cada factura</strong> para asegurar que es deducible y te avisamos si falta algo.
                </p>
                <p className="text-slate-600 mb-6 leading-relaxed">
                    Nuestro objetivo es que pagues lo mínimo legalmente posible, aplicando todas las bonificaciones vigentes en tu Comunidad Autónoma.
                </p>
                <div className="flex gap-3">
                    <span className="bg-slate-100 px-3 py-1 rounded-full text-xs font-bold text-slate-600">Alta Autónomos Gratis</span>
                    <span className="bg-slate-100 px-3 py-1 rounded-full text-xs font-bold text-slate-600">Constitución S.L.</span>
                </div>
            </div>
        </div>
      </section>

      {/* BLOQUE 2: LABORAL (RRHH) */}
      <section className="py-24 bg-slate-50 border-y border-slate-200">
        <div className="max-w-7xl mx-auto px-6 grid md:grid-cols-2 gap-16 items-center">
            <div>
                <h2 className="text-3xl font-black text-brand-dark mb-6">Gestión de Equipos y Nóminas</h2>
                <p className="text-slate-600 mb-6 leading-relaxed">
                    Tener empleados es una responsabilidad enorme. Nos encargamos de todo el ciclo de vida laboral para que tú solo te preocupes de liderar.
                </p>
                <div className="grid grid-cols-2 gap-4 mb-8">
                    <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
                        <h4 className="font-bold text-brand-dark">Altas y Bajas SS</h4>
                        <p className="text-xs text-slate-500">Trámites inmediatos en Sistema RED.</p>
                    </div>
                    <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
                        <h4 className="font-bold text-brand-dark">Contratos</h4>
                        <p className="text-xs text-slate-500">Redacción y registro en SEPE.</p>
                    </div>
                    <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
                        <h4 className="font-bold text-brand-dark">Nóminas</h4>
                        <p className="text-xs text-slate-500">Envío digital a tus empleados.</p>
                    </div>
                    <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
                        <h4 className="font-bold text-brand-dark">Despidos</h4>
                        <p className="text-xs text-slate-500">Cálculo de finiquitos y cartas.</p>
                    </div>
                </div>
            </div>
            <div className="bg-purple-50 p-8 rounded-3xl border border-purple-100">
                <div className="w-12 h-12 bg-purple-600 text-white rounded-xl flex items-center justify-center text-2xl mb-6">👥</div>
                <h3 className="text-2xl font-black text-brand-dark mb-6">Portal del Empleado</h3>
                <p className="text-slate-600 mb-6 text-sm">
                    Si contratas el servicio laboral, habilitamos un portal para que tus trabajadores descarguen sus nóminas automáticamente.
                </p>
                <ul className="space-y-3 text-sm">
                    <li className="flex items-center gap-2"><span className="text-purple-600">✓</span> Sin enviar emails mensuales</li>
                    <li className="flex items-center gap-2"><span className="text-purple-600">✓</span> Cumple RGPD</li>
                    <li className="flex items-center gap-2"><span className="text-purple-600">✓</span> Histórico siempre disponible</li>
                </ul>
            </div>
        </div>
      </section>

      {/* BLOQUE 3: JURÍDICO MERCANTIL */}
      <section className="py-24 bg-white">
        <div className="max-w-4xl mx-auto px-6 text-center">
            <span className="text-brand-gold font-bold tracking-widest uppercase text-xs mb-2 block">Seguridad Jurídica</span>
            <h2 className="text-3xl md:text-4xl font-black text-brand-dark mb-8">Respaldo Legal Incluido</h2>
            <p className="text-slate-600 text-lg mb-12">
                A diferencia de una gestoría "low-cost", aquí tienes un abogado mercantilista a tu disposición.
            </p>
            
            <div className="grid md:grid-cols-3 gap-6 text-left">
                <div className="p-6 border border-slate-100 rounded-2xl hover:shadow-lg transition">
                    <h4 className="font-bold text-brand-dark mb-2">Constitución de Sociedades</h4>
                    <p className="text-sm text-slate-500">Creamos tu S.L. en 48h. Pactos de socios y estatutos personalizados.</p>
                </div>
                <div className="p-6 border border-slate-100 rounded-2xl hover:shadow-lg transition">
                    <h4 className="font-bold text-brand-dark mb-2">Recursos a Hacienda</h4>
                    <p className="text-sm text-slate-500">Si llega una notificación, la contestamos nosotros. Incluido en planes Enterprise.</p>
                </div>
                <div className="p-6 border border-slate-100 rounded-2xl hover:shadow-lg transition">
                    <h4 className="font-bold text-brand-dark mb-2">Protección de Datos</h4>
                    <p className="text-sm text-slate-500">Auditoría web, textos legales y contratos de confidencialidad.</p>
                </div>
            </div>
        </div>
      </section>

      {/* CTA FINAL */}
      <section className="py-20 bg-brand-dark text-white text-center">
        <div className="max-w-3xl mx-auto px-6">
            <h2 className="text-3xl font-black mb-6">¿Hablamos de tu negocio?</h2>
            <p className="text-slate-300 mb-10 text-lg">
                La primera consulta de diagnóstico es gratuita. Sin compromiso. Analizamos tu situación y te damos un presupuesto cerrado.
            </p>
            <Link href="/#quiz-section" className="inline-block px-8 py-4 bg-brand-blue text-white font-bold rounded-xl hover:bg-blue-600 transition hover:-translate-y-1 shadow-lg shadow-blue-900/50">
                Agendar Videollamada
            </Link>
        </div>
      </section>

      <Footer />
    </main>
  );
}