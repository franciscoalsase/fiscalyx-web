'use client';

import Link from 'next/link';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { FadeIn } from '@/components/FadeIn';

export default function CriptoPage() {
  return (
    <main className="font-sans text-slate-600 bg-white">
      <Navbar />
      
      {/* HERO ESPECÍFICO - ENFOQUE NACIONAL */}
      <section className="relative pt-20 pb-32 bg-[#0B0F19] text-white overflow-hidden">
        <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-brand-blue/10 rounded-full blur-[120px]"></div>
        <div className="max-w-4xl mx-auto px-6 text-center relative z-10">
            <div className="inline-block px-3 py-1 rounded-full bg-blue-900/30 border border-blue-500/30 text-blue-400 text-xs font-bold uppercase tracking-widest mb-6">
              Servicio Online • Toda España
            </div>
            <h1 className="text-4xl md:text-6xl font-black mb-6 leading-tight">
              Auditoría y Fiscalidad <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-500">Web3</span>
            </h1>
            <p className="text-xl text-slate-400 max-w-2xl mx-auto mb-10">
              No dejes que Hacienda liquide tus ganancias. <strong>Servicio 100% remoto para inversores de toda España.</strong> Transformamos el caos de tus wallets (DeFi, Staking, NFTs) en informes fiscales blindados.
            </p>
            <div className="flex justify-center gap-4">
                <Link href="/#quiz-section" className="px-8 py-4 bg-brand-blue text-white font-bold rounded-xl hover:bg-blue-600 transition shadow-lg shadow-blue-500/20">
                    Solicitar Auditoría
                </Link>
            </div>
        </div>
      </section>

      {/* PROBLEMA / SOLUCIÓN */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-6 grid md:grid-cols-2 gap-16">
            <div>
                <h2 className="text-3xl font-black text-brand-dark mb-6">El problema del FIFO y la Trazabilidad</h2>
                <div className="prose text-slate-600">
                    <p className="mb-4">
                        La <strong>Agencia Tributaria (AEAT)</strong> exige aplicar el criterio <strong>FIFO (First In, First Out)</strong> a nivel nacional. Si has operado en varios exchanges o has hecho permutas (cambiar BTC por ETH), calcular esto manualmente es imposible y te expone a sanciones en cualquier Comunidad Autónoma.
                    </p>
                    <p className="mb-4">
                        Un error común es declarar solo cuando retiras a euros. <strong>Error grave.</strong> Cada swap es un hecho imponible. Si no lo declaras, las sanciones pueden llegar al 150% de la cuota.
                    </p>
                    <div className="bg-orange-50 border-l-4 border-orange-500 p-4 my-6">
                        <p className="text-sm text-orange-800 font-bold">
                            ⚠️ ¿Tienes más de 50.000€ en el extranjero?
                        </p>
                        <p className="text-xs text-orange-700 mt-1">
                            El Modelo 721 es obligatorio en todo el territorio nacional. El olvido puede acarrear multas fijas de hasta 10.000€.
                        </p>
                    </div>
                </div>
            </div>
            <div className="bg-slate-50 p-8 rounded-3xl border border-slate-200">
                <h3 className="text-xl font-bold text-brand-dark mb-6">Nuestra Metodología</h3>
                <ul className="space-y-4">
                    <li className="flex gap-4">
                        <div className="w-8 h-8 bg-blue-100 text-brand-blue rounded-full flex items-center justify-center font-bold">1</div>
                        <div>
                            <strong className="block text-brand-dark">Recopilación API/CSV</strong>
                            <span className="text-sm">Conectamos CoinTracking o Koinly a tus exchanges (solo lectura).</span>
                        </div>
                    </li>
                    <li className="flex gap-4">
                        <div className="w-8 h-8 bg-blue-100 text-brand-blue rounded-full flex items-center justify-center font-bold">2</div>
                        <div>
                            <strong className="block text-brand-dark">Limpieza de Datos</strong>
                            <span className="text-sm">Detectamos transferencias internas que los software marcan erróneamente como ventas.</span>
                        </div>
                    </li>
                    <li className="flex gap-4">
                        <div className="w-8 h-8 bg-blue-100 text-brand-blue rounded-full flex items-center justify-center font-bold">3</div>
                        <div>
                            <strong className="block text-brand-dark">Informe Fiscal Válido</strong>
                            <span className="text-sm">Generamos el informe final optimizado para la casilla de la Renta (Válido para todas las CC.AA).</span>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
      </section>

      {/* NUEVA SECCIÓN: TRANQUILIDAD OPERATIVA (VIDEO Y SOFTWARE) */}
      <section className="py-16 bg-blue-50/50 border-y border-blue-100">
        <div className="max-w-5xl mx-auto px-6">
            <div className="grid md:grid-cols-2 gap-8">
                
                {/* 1. SOPORTE VIDEOLLAMADA */}
                <div className="flex gap-5 p-6 rounded-2xl bg-white shadow-sm border border-blue-200 hover:shadow-md transition duration-300">
                  <div className="w-14 h-14 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center text-3xl flex-shrink-0">📹</div>
                  <div>
                    <h4 className="font-bold text-brand-dark text-lg mb-2">Soporte Operativo en Vivo</h4>
                    <p className="text-sm text-slate-600 leading-relaxed">
                        ¿Dudas al hacer un swap o staking? Nos conectamos contigo por videollamada y <strong>revisamos tus movimientos en tiempo real</strong> compartiendo pantalla para evitar errores antes de que ocurran.
                    </p>
                  </div>
                </div>

                {/* 2. SOFTWARE INCLUIDO */}
                <div className="flex gap-5 p-6 rounded-2xl bg-white shadow-sm border border-purple-200 hover:shadow-md transition duration-300">
                  <div className="w-14 h-14 bg-purple-50 text-purple-600 rounded-xl flex items-center justify-center text-3xl flex-shrink-0">🎁</div>
                  <div>
                    <h4 className="font-bold text-brand-dark text-lg mb-2">Licencia Premium Incluida</h4>
                    <p className="text-sm text-slate-600 leading-relaxed">
                        Olvídate de pagar herramientas extra. La licencia profesional de <strong>CoinTracking o Koinly está incluida en tu cuota</strong> (Te ahorras más de 200€ al año en software).
                    </p>
                  </div>
                </div>

            </div>
        </div>
      </section>

      {/* PRICING ESPECÍFICO */}
      <section className="py-20 bg-slate-50 border-t border-slate-200">
        <div className="max-w-5xl mx-auto px-6">
            <h2 className="text-3xl font-black text-center text-brand-dark mb-12">Planes de Auditoría Cripto</h2>
            <div className="grid md:grid-cols-3 gap-6">
                
                {/* PACK BÁSICO */}
                <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                    <h3 className="font-bold text-lg mb-2">Pack HODL</h3>
                    <div className="text-3xl font-black text-brand-dark mb-4">150€<span className="text-sm text-slate-400 font-normal">/año</span></div>
                    <p className="text-xs text-slate-500 mb-6">Para quien solo compra y mantiene.</p>
                    <ul className="text-sm space-y-2 mb-6">
                        <li>✓ Hasta 50 transacciones</li>
                        <li>✓ Informe Renta</li>
                        <li>✗ Sin DeFi/Staking</li>
                        <li>✗ Software no incluido</li>
                    </ul>
                    <Link href="/#quiz-section" className="block w-full py-2 border border-brand-blue text-brand-blue font-bold text-center rounded-lg hover:bg-blue-50">Elegir</Link>
                </div>

                {/* PACK TRADER */}
                <div className="bg-brand-dark text-white p-6 rounded-2xl shadow-xl border-2 border-brand-blue relative transform md:-translate-y-4">
                    <div className="absolute top-0 right-0 bg-brand-blue text-xs font-bold px-3 py-1 rounded-bl-lg">POPULAR</div>
                    <h3 className="font-bold text-lg mb-2">Pack Trader</h3>
                    <div className="text-3xl font-black mb-4">350€<span className="text-sm text-slate-400 font-normal">/año</span></div>
                    <p className="text-xs text-slate-300 mb-6">Operativa frecuente en exchanges.</p>
                    <ul className="text-sm space-y-2 mb-6">
                        <li>✓ Hasta 1000 transacciones</li>
                        <li>✓ Informe Renta + Patrimonio</li>
                        <li>✓ <strong>Software Incluido</strong></li>
                        <li>✓ <strong>Soporte Videollamada</strong></li>
                    </ul>
                    <Link href="/#quiz-section" className="block w-full py-2 bg-brand-blue text-white font-bold text-center rounded-lg hover:bg-blue-600">Elegir</Link>
                </div>

                {/* PACK DEFI */}
                <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                    <h3 className="font-bold text-lg mb-2">Pack DeFi</h3>
                    <div className="text-3xl font-black text-brand-dark mb-4">Consultar</div>
                    <p className="text-xs text-slate-500 mb-6">Farming, Pools, NFTs, Airdrops.</p>
                    <ul className="text-sm space-y-2 mb-6">
                        <li>✓ Transacciones ilimitadas</li>
                        <li>✓ Análisis Smart Contracts</li>
                        <li>✓ Modelo 721 incluido</li>
                        <li>✓ <strong>Software Incluido</strong></li>
                    </ul>
                    <Link href="/#quiz-section" className="block w-full py-2 border border-slate-300 text-slate-600 font-bold text-center rounded-lg hover:bg-slate-50">Contactar</Link>
                </div>

            </div>
        </div>
      </section>

      <Footer />
    </main>
  );
}