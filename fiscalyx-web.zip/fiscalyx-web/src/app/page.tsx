'use client';

import { useState } from 'react';
import Link from 'next/link';
import { Navbar } from '@/components/Navbar';
import { FadeIn } from '@/components/FadeIn';
import { HeroVisual } from '@/components/HeroVisual'; 
import { Footer } from '@/components/Footer';
import { FiscalQuiz } from '@/components/FiscalQuiz';
import { TechIntegration } from '@/components/TechIntegration';

// --- DATOS DE LOS PLANES ---
const PLANES: any = {
  autonomo: [
    {
      name: 'Basic',
      price: 59,
      period: '/mes',
      desc: 'Gestión esencial automatizada',
      features: ['Impuestos Trimestrales', 'App Facturación + Bancos', 'Licencia Software Incluida', 'Soporte Email <24h'],
      cta: 'Empezar Basic',
      highlight: false
    },
    {
      name: 'Pro',
      price: 89,
      period: '/mes',
      desc: 'Tu Copiloto Fiscal',
      features: ['Todo Basic +', 'Asesor Personal WhatsApp', 'Declaración Renta (Mod 100)', 'Laboral opcional (+15€)', 'Revisión de contratos'],
      cta: 'Empezar Ahora',
      highlight: false,
      popular: true
    }
  ],
  empresa: [
    {
      name: 'Startup',
      price: 129,
      period: '/mes',
      desc: 'S.L. Servicios / Patrimonial',
      features: ['Fiscalidad S.L. Completa', 'Impuesto Sociedades (200)', 'Cuentas Anuales', '1 Nómina Incluida'],
      cta: 'Contactar',
      highlight: false
    },
    {
      name: 'Crecimiento',
      price: 249,
      period: '/mes',
      desc: 'Pymes con equipo',
      features: ['Todo Startup +', 'Hasta 5 Nóminas', 'Reunión Mensual Estrategia', 'Analítica de Costes'],
      cta: 'Elegir Plan',
      highlight: false,
      popular: true
    },
    {
      name: 'Gran Empresa',
      price: 'Consultar',
      period: '',
      desc: 'Holdings o >1M€',
      features: ['Consolidación Fiscal', 'Auditoría Interna', 'Operaciones Vinculadas', 'Fiscalidad Internacional'],
      cta: 'Pedir Presupuesto',
      highlight: false
    }
  ],
  cripto: [
    {
      name: 'Pack HODL',
      price: 150,
      period: '/año',
      desc: 'Inversores pasivos',
      features: ['Hasta 50 transacciones', 'Informe Fiscal Renta', 'Resolución dudas básicas', 'Sin DeFi/Staking'],
      cta: 'Elegir HODL',
      highlight: false
    },
    {
      name: 'Trader Pro',
      price: 350,
      period: '/año',
      desc: 'Auditoría + Blindaje',
      features: ['Hasta 3.500 ops', 'Licencia CoinTracking', 'Informe Renta + 714', 'Videollamada Operativa'],
      cta: 'Auditar Cripto',
      highlight: true, // Diseño oscuro
      popular: true
    },
    {
      name: 'DeFi Whale',
      price: 'Consultar',
      period: '',
      desc: 'Altos Patrimonios / NFTs',
      features: ['Ops Ilimitadas', 'Análisis Smart Contracts', 'Trazabilidad Manual', 'Defensa Jurídica'],
      cta: 'Pedir Presupuesto',
      highlight: false
    }
  ]
};

export default function Home() {
  const openCalendly = () => {
    window.open('https://calendly.com/francisco-alsase/30min', '_blank');
  };

  const [segment, setSegment] = useState<'autonomo' | 'empresa' | 'cripto'>('autonomo');

  return (
    <main className="font-sans text-slate-600 antialiased selection:bg-brand-blue selection:text-white min-h-screen overflow-x-hidden bg-white">
      
      {/* FONDO DE PUNTOS */}
      <div className="fixed inset-0 -z-10 h-full w-full bg-white bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] [background-size:16px_16px]"></div>

      {/* BARRA SUPERIOR */}
      <div className="bg-brand-dark text-slate-300 text-sm py-3 hidden sm:block">
        <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
          <span className="font-semibold text-slate-200">🎯 ¿Te preocupa tu próxima declaración?</span>
          <button onClick={openCalendly} className="text-brand-blue hover:text-blue-300 font-bold transition">
            Agendar Consulta Gratis →
          </button>
        </div>
      </div>

      <Navbar />

      {/* ============ HERO SECTION (MÓVIL OPTIMIZADO) ============ */}
      <header className="relative pt-12 pb-20 lg:pt-20 lg:pb-32 overflow-hidden">
        <div className="max-w-7xl mx-auto px-6 grid lg:grid-cols-2 gap-12 items-center">
          
          {/* COLUMNA IZQUIERDA: MENSAJE */}
          <div className="relative z-10 flex flex-col items-start text-left">
            <FadeIn direction="right" delay={0.1}>
                <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-blue-50 border border-blue-100 text-brand-blue text-xs font-extrabold uppercase tracking-wider mb-6 shadow-sm">
                  <span className="relative flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-brand-blue opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-brand-blue"></span>
                  </span> 
                  Agenda Abierta • Campaña 2025
                </div>
            </FadeIn>
            
            <FadeIn direction="up" delay={0.2}>
                <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black text-brand-dark leading-[1.1] mb-6 tracking-tight">
                Paga menos impuestos.<br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-blue to-purple-600">Duerme tranquilo.</span>
                </h1>
            </FadeIn>
            
            <FadeIn direction="up" delay={0.3}>
                <p className="text-lg text-slate-600 mb-8 max-w-xl leading-relaxed">
                La asesoría moderna para el autónomo digital. Olvida el papel. <br/>
                <span className="text-sm font-bold text-brand-dark mt-2 block bg-blue-50/50 inline-block px-2 py-1 rounded-lg border border-blue-100">
                   📱 Todo centralizado en tu Área de Cliente Inteligente.
                </span>
                </p>
            </FadeIn>

            {/* CTA PRINCIPAL */}
            <FadeIn direction="up" delay={0.4} className="w-full sm:w-auto mb-8 lg:mb-12">
                <div className="flex flex-col sm:flex-row gap-4">
                  <Link href="#quiz-section" className="relative flex items-center justify-center px-8 py-4 text-base font-bold text-white bg-brand-blue rounded-xl leading-none transition hover:bg-blue-600 shadow-xl hover:-translate-y-1">
                      Diagnóstico Fiscal Gratis
                  </Link>
                  <Link href="/contratar" className="inline-flex justify-center items-center px-8 py-4 text-base font-bold text-brand-dark bg-white/80 border border-slate-200 rounded-xl hover:bg-white transition hover:-translate-y-1 shadow-sm">
                      Ver Planes
                  </Link>
                </div>
                <p className="text-xs text-slate-400 font-bold mt-4">
                  ✓ Economista Colegiado (#4174) | ✓ Seguro RC €300k
                </p>
            </FadeIn>

            {/* 3 OPCIONES SEGMENTADAS (VISIBLE SOLO EN TABLET/DESKTOP) */}
            <FadeIn direction="up" delay={0.5} className="hidden md:grid md:grid-cols-3 gap-4 w-full">
                  <div className="bg-gradient-to-br from-orange-50 to-white border-2 border-orange-200 p-4 rounded-xl hover:shadow-lg transition cursor-pointer group">
                    <div className="text-2xl mb-2">⚡</div>
                    <h4 className="text-sm font-bold text-brand-dark mb-1">Trader Cripto</h4>
                    <p className="text-[10px] text-slate-600 mb-2 leading-tight">Auditoría + Software.</p>
                    <Link href="/servicios/cripto" className="text-orange-600 font-bold group-hover:underline text-xs">Ver riesgo →</Link>
                  </div>

                  <div className="bg-gradient-to-br from-blue-50 to-white border-2 border-blue-200 p-4 rounded-xl hover:shadow-lg transition cursor-pointer group">
                    <div className="text-2xl mb-2">💼</div>
                    <h4 className="text-sm font-bold text-brand-dark mb-1">Soy Autónomo</h4>
                    <p className="text-[10px] text-slate-600 mb-2 leading-tight">Gestión total online.</p>
                    <Link href="/servicios?type=autonomo" className="text-brand-blue font-bold group-hover:underline text-xs">Ahorrar →</Link>
                  </div>

                  <div className="bg-gradient-to-br from-purple-50 to-white border-2 border-purple-200 p-4 rounded-xl hover:shadow-lg transition cursor-pointer group">
                    <div className="text-2xl mb-2">🏢</div>
                    <h4 className="text-sm font-bold text-brand-dark mb-1">Soy Empresa</h4>
                    <p className="text-[10px] text-slate-600 mb-2 leading-tight">Dirección financiera.</p>
                    <Link href="/servicios?type=empresa" className="text-purple-600 font-bold group-hover:underline text-xs">Plan Enterprise →</Link>
                  </div>
            </FadeIn>
          </div>
          
          {/* COLUMNA DERECHA: VISUAL 3D */}
          <FadeIn direction="left" delay={0.5} className="relative w-full mt-8 lg:mt-0">
            <HeroVisual />
          </FadeIn>

        </div>
      </header>

      {/* ============ GARANTÍAS (GRID MÓVIL) ============ */}
      <FadeIn className="border-y border-blue-100 bg-blue-50 py-8 lg:py-16">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-3 gap-2 md:flex md:justify-around md:items-center md:gap-12 text-center divide-x divide-blue-200 md:divide-x-0">
            <div className="flex flex-col items-center px-2">
              <div className="text-2xl md:text-5xl font-black text-brand-blue mb-1 md:mb-2">24h</div>
              <div className="text-[10px] md:text-sm font-bold text-slate-700 leading-tight">Respuesta<br className="md:hidden"/> Garantizada</div>
            </div>
            <div className="flex flex-col items-center px-2">
              <div className="text-2xl md:text-5xl font-black text-brand-blue mb-1 md:mb-2">300k</div>
              <div className="text-[10px] md:text-sm font-bold text-slate-700 leading-tight">Seguro<br className="md:hidden"/> Protección</div>
            </div>
            <div className="flex flex-col items-center px-2">
              <div className="text-2xl md:text-5xl font-black text-brand-blue mb-1 md:mb-2">100%</div>
              <div className="text-[10px] md:text-sm font-bold text-slate-700 leading-tight">Trato<br className="md:hidden"/> Humano</div>
            </div>
          </div>
        </div>
      </FadeIn>

      {/* ============ TECH INTEGRATION ============ */}
      <TechIntegration />

      {/* ============ CÓMO FUNCIONA ============ */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6 text-center">
             <FadeIn direction="up">
                <h2 className="text-3xl font-extrabold text-brand-dark mb-16">3 Pasos para empezar</h2>
            </FadeIn>
            <div className="grid md:grid-cols-3 gap-12 relative">
                <FadeIn delay={0.1} className="bg-white p-6">
                    <div className="w-24 h-24 mx-auto bg-blue-50 rounded-full flex items-center justify-center text-4xl mb-6 border-4 border-white shadow-lg">⚡</div>
                    <h3 className="text-xl font-bold text-brand-dark mb-3">1. Diagnóstico Rápido</h3>
                    <p className="text-slate-500 text-sm">Responde el Quiz abajo. Analizamos tu riesgo fiscal en 1 minuto.</p>
                </FadeIn>
                <FadeIn delay={0.2} className="bg-white p-6">
                    <div className="w-24 h-24 mx-auto bg-blue-50 rounded-full flex items-center justify-center text-4xl mb-6 border-4 border-white shadow-lg">✓</div>
                    <h3 className="text-xl font-bold text-brand-dark mb-3">2. Plan a Medida</h3>
                    <p className="text-slate-500 text-sm">Basic, Pro o Enterprise. Te decimos cuál te ahorra más dinero.</p>
                </FadeIn>
                <FadeIn delay={0.3} className="bg-white p-6">
                    <div className="w-24 h-24 mx-auto bg-blue-50 rounded-full flex items-center justify-center text-4xl mb-6 border-4 border-white shadow-lg">🚀</div>
                    <h3 className="text-xl font-bold text-brand-dark mb-3">3. Despegamos</h3>
                    <p className="text-slate-500 text-sm">Acceso inmediato a tu Asesor. Tu fiscalidad en piloto automático.</p>
                </FadeIn>
            </div>
        </div>
      </section>

      {/* ============ PRECIOS SEGMENTADOS (3 PESTAÑAS) ============ */}
      <section id="precios" className="py-24 bg-slate-50 border-t border-slate-200">
        <div className="max-w-7xl mx-auto px-6">
          <FadeIn direction="up">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-extrabold text-brand-dark mb-4">Planes Transparentes</h2>
              <p className="text-slate-500 mb-8">Elige el perfil que mejor encaja contigo.</p>
              
              {/* SELECTOR DE 3 PESTAÑAS */}
              <div className="inline-flex flex-wrap justify-center bg-white p-1 rounded-xl border border-slate-200 shadow-sm gap-1">
                <button 
                    onClick={() => setSegment('autonomo')}
                    className={`px-4 sm:px-6 py-2 rounded-lg text-sm font-bold transition-all ${segment === 'autonomo' ? 'bg-brand-blue text-white shadow-md' : 'text-slate-500 hover:text-brand-dark'}`}
                >
                    Soy Autónomo
                </button>
                <button 
                    onClick={() => setSegment('empresa')}
                    className={`px-4 sm:px-6 py-2 rounded-lg text-sm font-bold transition-all ${segment === 'empresa' ? 'bg-brand-dark text-white shadow-md' : 'text-slate-500 hover:text-brand-dark'}`}
                >
                    Soy Empresa (S.L.)
                </button>
                <button 
                    onClick={() => setSegment('cripto')}
                    className={`px-4 sm:px-6 py-2 rounded-lg text-sm font-bold transition-all ${segment === 'cripto' ? 'bg-purple-600 text-white shadow-md' : 'text-slate-500 hover:text-purple-600'}`}
                >
                    💎 Inversor Cripto
                </button>
              </div>
            </div>
          </FadeIn>

          <div className={`grid gap-8 mb-16 max-w-6xl mx-auto ${PLANES[segment].length === 2 ? 'md:grid-cols-2 max-w-4xl' : 'md:grid-cols-3'} animate-in slide-in-from-bottom-4 duration-500`}>
             {PLANES[segment].map((plan: any, idx: number) => (
                <FadeIn key={plan.name} delay={idx * 0.1} 
                    className={`relative rounded-2xl p-8 shadow-sm border transition-all duration-300 hover:shadow-xl hover:-translate-y-2 flex flex-col
                    ${plan.highlight ? 'bg-[#0B0F19] text-white border-slate-700 hover:border-brand-blue/50' : 'bg-white text-slate-600 border-slate-200'} 
                    ${plan.popular && !plan.highlight ? 'border-brand-blue ring-2 ring-brand-blue/20 shadow-xl' : ''}`}
                >
                    {plan.popular && (
                        <div className={`absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full text-xs font-bold uppercase tracking-wide ${plan.highlight ? 'bg-purple-600 text-white' : 'bg-brand-blue text-white'}`}>
                            {segment === 'empresa' ? 'Más Completo' : 'Recomendado'}
                        </div>
                    )}

                    <h3 className={`text-2xl font-bold mb-2 ${plan.highlight ? 'text-white' : 'text-brand-dark'}`}>{plan.name}</h3>
                    <p className={`text-sm mb-6 ${plan.highlight ? 'text-slate-400' : 'text-slate-500'}`}>{plan.desc}</p>
                    
                    <div className={`mb-6 border-b pb-6 ${plan.highlight ? 'border-slate-700' : 'border-slate-200'}`}>
                        <div className={`text-4xl font-extrabold ${plan.highlight ? 'text-white' : 'text-brand-dark'}`}>
                            {typeof plan.price === 'number' ? `${plan.price}€` : plan.price}
                            <span className={`text-xl font-normal ${plan.highlight ? 'text-slate-500' : 'text-slate-500'}`}>{plan.period}</span>
                        </div>
                    </div>

                    <ul className={`space-y-3 mb-8 text-sm flex-1 ${plan.highlight ? 'text-slate-300' : 'text-slate-600'}`}>
                        {plan.features.map((feat: string, i: number) => (
                             <li key={i} className="flex items-start gap-2">
                                <span className={`font-bold ${plan.highlight ? 'text-green-400' : 'text-green-500'}`}>✓</span> {feat}
                             </li>
                        ))}
                    </ul>

                    <Link 
                        href={`/contratar?tab=${segment}`} 
                        className={`block w-full text-center px-6 py-3 font-bold rounded-lg transition 
                            ${plan.highlight 
                                ? 'bg-white text-brand-dark hover:bg-slate-200' 
                                : plan.popular 
                                    ? 'bg-brand-blue text-white hover:bg-blue-600 shadow-lg' 
                                    : 'border-2 border-brand-blue text-brand-blue hover:bg-blue-50'
                            }`}
                    >
                        {plan.cta}
                    </Link>
                </FadeIn>
             ))}
          </div>

        </div>
      </section>

      {/* ============ ACADEMIA / BLOG (NUEVA SECCIÓN) ============ */}
      <section className="py-24 bg-slate-50 border-y border-slate-200">
        <div className="max-w-7xl mx-auto px-6">
            <FadeIn direction="up" className="text-center mb-12">
                <h2 className="text-sm font-bold text-brand-blue tracking-widest uppercase mb-2">Academia FiscalYX</h2>
                <h3 className="text-4xl font-black text-brand-dark">Aprende a proteger tu dinero</h3>
            </FadeIn>
            <div className="grid md:grid-cols-3 gap-8">
                {/* CARD BLOG 1 */}
                <Link href="/blog/modelo-721-criptomonedas-guia" className="group bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition duration-300 border border-slate-200">
                    <div className="h-48 bg-slate-900 flex items-center justify-center text-5xl group-hover:scale-105 transition duration-500">🚨</div>
                    <div className="p-6">
                        <span className="text-[10px] font-bold uppercase text-purple-600 bg-purple-50 px-2 py-1 rounded-full">Cripto</span>
                        <h4 className="font-bold text-lg text-brand-dark mt-3 mb-2 group-hover:text-brand-blue transition">Guía Definitiva Modelo 721</h4>
                        <p className="text-sm text-slate-500 line-clamp-2">Evita la multa de 300€. Claves para declarar tus criptos en el extranjero.</p>
                    </div>
                </Link>
                 {/* CARD BLOG 2 */}
                 <Link href="/blog/retirar-binance-hacienda" className="group bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition duration-300 border border-slate-200">
                    <div className="h-48 bg-green-50 flex items-center justify-center text-5xl group-hover:scale-105 transition duration-500">🏦</div>
                    <div className="p-6">
                        <span className="text-[10px] font-bold uppercase text-green-600 bg-green-50 px-2 py-1 rounded-full">Banca</span>
                        <h4 className="font-bold text-lg text-brand-dark mt-3 mb-2 group-hover:text-brand-blue transition">Retirar de Binance sin bloqueos</h4>
                        <p className="text-sm text-slate-500 line-clamp-2">Cómo hacer el Off-Ramp seguro y preparar la trazabilidad para el banco.</p>
                    </div>
                </Link>
                 {/* CARD BLOG 3 */}
                 <Link href="/blog/gastos-deducibles-autonomos" className="group bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition duration-300 border border-slate-200">
                    <div className="h-48 bg-blue-50 flex items-center justify-center text-5xl group-hover:scale-105 transition duration-500">📉</div>
                    <div className="p-6">
                        <span className="text-[10px] font-bold uppercase text-blue-600 bg-blue-50 px-2 py-1 rounded-full">Autónomos</span>
                        <h4 className="font-bold text-lg text-brand-dark mt-3 mb-2 group-hover:text-brand-blue transition">Lista de Gastos Deducibles 2025</h4>
                        <p className="text-sm text-slate-500 line-clamp-2">Desmontando mitos: El coche, la luz de casa y las comidas.</p>
                    </div>
                </Link>
            </div>
            <div className="text-center mt-12">
                <Link href="/blog" className="font-bold text-brand-blue hover:underline">Ver todos los artículos →</Link>
            </div>
        </div>
      </section>

      {/* ============ EQUIPO ============ */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-6 grid lg:grid-cols-2 gap-16 items-center">
            <FadeIn direction="right">
                <div>
                    <h2 className="text-3xl font-extrabold text-brand-dark mb-6">Expertos en Fiscalidad Digital</h2>
                    <p className="text-lg text-slate-600 mb-6 leading-relaxed">
                        FiscalYX nace para traer excelencia profesional al mundo online. Respuesta rápida, soluciones reales, sin intermediarios.
                    </p>
                    <div className="mb-8 border-l-4 border-brand-blue pl-6">
                        <h4 className="text-xl font-bold text-brand-dark">Francisco Seva Soriano</h4>
                        <p className="text-brand-blue font-bold text-sm mb-2">Economista Colegiado</p>
                        <ul className="text-sm text-slate-500 space-y-1"><li>• Nº Colegio: 4174</li><li>• Ejerciente Nº 1761</li><li>• Especialista en Cripto</li></ul>
                    </div>
                    <div className="border-l-4 border-brand-gold pl-6">
                        <h4 className="text-xl font-bold text-brand-dark">Emilio Escudero Soler</h4>
                        <p className="text-brand-gold font-bold text-sm mb-2">Abogado Colegiado</p>
                        <ul className="text-sm text-slate-500 space-y-1"><li>• Especialista Mercantil</li><li>• Segunda Oportunidad</li><li>• Asesor Legal</li></ul>
                    </div>
                </div>
            </FadeIn>
            
            <FadeIn direction="left">
                <div className="grid grid-cols-2 gap-4">
                    <div className="rounded-2xl shadow-lg w-full h-64 bg-slate-100 flex flex-col items-center justify-center text-center p-4 border-2 border-dashed border-slate-300">
                        <span className="text-4xl mb-2">📸</span>
                        <p className="text-xs font-bold text-slate-500">Sube foto real de<br/>Francisco Aquí</p>
                    </div>
                    <div className="rounded-2xl shadow-lg w-full h-64 bg-slate-100 flex flex-col items-center justify-center text-center p-4 border-2 border-dashed border-slate-300 mt-8">
                        <span className="text-4xl mb-2">📸</span>
                        <p className="text-xs font-bold text-slate-500">Sube foto real de<br/>Emilio o Despacho</p>
                    </div>
                </div>
            </FadeIn>
        </div>
      </section>

      {/* ============ TESTIMONIOS ============ */}
      <section className="py-24 bg-slate-50 border-t border-slate-200">
         <div className="max-w-7xl mx-auto px-6">
             <h2 className="text-center text-3xl font-extrabold text-brand-dark mb-16">Lo que dicen nuestros clientes</h2>
             <div className="grid md:grid-cols-3 gap-8 mb-20">
                <FadeIn delay={0.1} className="bg-white p-8 rounded-2xl border border-slate-100 shadow-sm"><div className="flex text-brand-gold mb-4">★★★★★</div><p className="text-slate-600 text-sm mb-6">"Con Francisco tengo la tranquilidad de un gestor personal pero con la rapidez online. Responde en 24h siempre."</p><div className="font-bold text-brand-dark text-sm">Antonio M. <span className="text-slate-400 font-normal">- CEO SaaS</span></div></FadeIn>
                <FadeIn delay={0.2} className="bg-white p-8 rounded-2xl border border-slate-100 shadow-sm"><div className="flex text-brand-gold mb-4">★★★★★</div><p className="text-slate-600 text-sm mb-6">"Trazabilidad de Binance perfecta. La única asesoría que entiende cripto de verdad. Me salvaron de una multa."</p><div className="font-bold text-brand-dark text-sm">Laura G. <span className="text-slate-400 font-normal">- Trader</span></div></FadeIn>
                <FadeIn delay={0.3} className="bg-white p-8 rounded-2xl border border-slate-100 shadow-sm"><div className="flex text-brand-gold mb-4">★★★★★</div><p className="text-slate-600 text-sm mb-6">"Respuestas por WhatsApp, todo claro, sin sorpresas. Finalmente un gestor que trata como se debe."</p><div className="font-bold text-brand-dark text-sm">Javier R. <span className="text-slate-400 font-normal">- Freelance</span></div></FadeIn>
             </div>
         </div>
      </section>

      {/* ============ QUIZ INTERACTIVO ============ */}
      <section id="quiz-section" className="py-24 bg-gradient-to-br from-brand-dark to-slate-900 text-white">
        <div className="max-w-3xl mx-auto px-6">
          <FadeIn direction="up" className="text-center mb-12">
            <h2 className="text-4xl font-extrabold mb-4">Diagnóstico Fiscal Preliminar</h2>
            <p className="text-slate-300 text-lg">Responde 3 preguntas y detectaremos tu potencial de ahorro o riesgo.</p>
          </FadeIn>
          
          <FiscalQuiz />
          
        </div>
      </section>

      <Footer />
    </main>
  );
}