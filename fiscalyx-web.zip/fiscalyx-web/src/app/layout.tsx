import type { Metadata } from "next";
import { Plus_Jakarta_Sans } from "next/font/google";
import { Analytics } from '@vercel/analytics/react'; // 👈 Mantenemos tus "ojos biónicos"
import "./globals.css";
import { MobileActionBar } from '@/components/MobileActionBar';
import { CookieBanner } from '@/components/CookieBanner';

// Mantenemos tu fuente original Plus Jakarta Sans (Muy Top Tier para Fintech)
const jakarta = Plus_Jakarta_Sans({ 
  subsets: ["latin"],
  variable: "--font-jakarta",
});

export const metadata: Metadata = {
  title: 'FiscalYX | Asesoría Fiscal Online para Cripto y Autónomos',
  description: 'Ahorra impuestos y evita sanciones. La primera asesoría híbrida con economistas colegiados y tecnología para inversores Cripto y Pymes.',
  keywords: ['asesoria fiscal online', 'gestoria criptomonedas', 'modelo 721', 'asesor fiscal alicante', 'alta autonomo online'],
  // Metadatos OpenGraph para que se vea profesional al compartir en WhatsApp/LinkedIn
  openGraph: {
    title: 'FiscalYX - Tu Escudo Fiscal Digital',
    description: 'Diagnóstico fiscal gratuito en 1 minuto. Expertos en Cripto y Autónomos.',
    url: 'https://fiscalyx.com',
    siteName: 'FiscalYX',
    locale: 'es_ES',
    type: 'website',
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    // Agregamos 'scroll-smooth' para la navegación suave
    <html lang="es" className="scroll-smooth">
      <body className={`${jakarta.variable} font-sans bg-white text-slate-600 antialiased`}>
        
        {children}
        
        {/* Componentes Flotantes Globales (Las mejoras Top Tier) */}
        <MobileActionBar />
        <CookieBanner />
        
        {/* Analítica de Vercel */}
        <Analytics />
      </body>
    </html>
  );
}