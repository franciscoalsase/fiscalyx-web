import type { Metadata } from 'next'
import Link from "next/link";
import { Logo } from '@/components/Logo';
import { Footer } from '@/components/Footer';

export const metadata: Metadata = {
  title: 'Guía Fiscalidad Cripto y Modelo 721 | Fiscalyx Alicante',
  description: 'Aprende cómo declarar tus criptomonedas en la Renta. Expertos en fiscalidad digital en Alicante.',
}

export default function CriptoPage() {
  return (
    <main className="font-sans text-slate-300 bg-slate-900 antialiased selection:bg-brand-blue selection:text-white min-h-screen">
      
      <nav className="sticky top-0 z-50 bg-brand-dark/95 backdrop-blur border-b border-white/10 shadow-sm">
        <div className="max-w-7xl mx-auto px-6 h-20 flex justify-between items-center">
          <Link href="/" className="z-50"><Logo isDark={true} /></Link>
          <Link href="/" className="text-sm font-bold text-brand-blue hover:text-white transition flex items-center gap-2">← Volver</Link>
        </div>
      </nav>

      <article className="max-w-3xl mx-auto px-6 py-12 bg-brand-dark border border-white/10 mt-8 mb-16 rounded-2xl">
        <div className="mb-8 rounded-xl overflow-hidden h-64 md:h-80 relative">
            <img src="https://images.unsplash.com/photo-1621416894569-0f39ed31d247?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&q=80" alt="Criptomonedas" className="object-cover w-full h-full"/>
            <div className="absolute inset-0 bg-gradient-to-t from-brand-dark to-transparent"></div>
        </div>

        <header className="mb-10">
            <span className="bg-brand-blue/20 text-brand-blue text-xs font-bold px-3 py-1 rounded-full uppercase">Crypto & Web3</span>
            <h1 className="text-3xl md:text-4xl font-extrabold text-white mt-4 mb-4 leading-tight">
                El Nuevo Modelo 721 y la Campaña de Renta: Guía para Inversores Cripto
            </h1>
            <div className="flex items-center text-sm text-slate-500 border-b border-white/10 pb-8">
                <span className="font-bold text-white">Por Fiscalyx Digital</span>
                <span className="mx-2">•</span>
                <span>Lectura: 6 min</span>
            </div>
        </header>

        <div className="prose prose-lg prose-invert text-slate-300">
            <p className="mb-6 text-lg font-medium text-white">
                La Agencia Tributaria (AEAT) ha intensificado el control. Si tienes criptomonedas en <em>exchanges</em> extranjeros como Binance o Kraken, el Modelo 721 es obligatorio si superas los 50.000€.
            </p>
            <h2 className="text-2xl font-bold text-white mt-8 mb-4">Errores comunes (IRPF)</h2>
            <ul className="list-disc pl-5 mb-6 space-y-2 bg-white/5 p-6 rounded-lg border border-white/10">
                <li><strong>Permutas:</strong> Cambiar BTC por ETH tributa.</li>
                <li><strong>FIFO:</strong> Debes aplicar el criterio "First In, First Out".</li>
                <li><strong>Staking:</strong> Tributa como Rendimiento de Capital Mobiliario.</li>
            </ul>
            <div className="bg-gradient-to-br from-brand-blue to-blue-900 text-white p-8 rounded-xl mt-12 text-center border border-white/20">
                <h3 className="text-xl font-bold mb-4">¿Tienes muchas operaciones?</h3>
                <p className="mb-6 text-blue-100">Usamos software de trazabilidad para calcular tus impuestos exactos sin errores.</p>
                <Link href="/#contacto" className="inline-block bg-white text-brand-dark hover:bg-slate-200 font-bold py-3 px-8 rounded-lg transition">
                    Hablar con Experto Cripto
                </Link>
            </div>
        </div>
      </article>

      {/* FOOTER PROPIO OSCURO PARA CRIPTO, O PODEMOS USAR EL BLANCO GENERAL */}
      {/* Para consistencia con la marca "Dark" de cripto, podemos dejar este footer simple oscuro o importar el blanco. */}
      <footer className="bg-brand-dark border-t border-white/10 pt-16 pb-8">
        <div className="max-w-7xl mx-auto px-6 text-center text-xs text-slate-500">© 2025 Fiscalyx Asesores SL.</div>
      </footer>
    </main>
  );
}