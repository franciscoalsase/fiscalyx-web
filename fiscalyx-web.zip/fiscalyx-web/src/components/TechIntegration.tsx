import { FadeIn } from '@/components/FadeIn';

export const TechIntegration = () => {
  return (
    <section className="py-24 bg-white overflow-hidden relative border-b border-slate-100">
      {/* Elemento de fondo sutil */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none opacity-40">
        <div className="absolute -top-[20%] -left-[10%] w-[50%] h-[50%] bg-blue-50 rounded-full blur-[100px]"></div>
        <div className="absolute top-[30%] -right-[10%] w-[40%] h-[60%] bg-purple-50 rounded-full blur-[100px]"></div>
      </div>

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <FadeIn>
          <div className="text-center max-w-3xl mx-auto mb-20">
            <h2 className="text-brand-blue font-bold tracking-widest uppercase text-xs mb-3">
              Stack Tecnológico
            </h2>
            <h3 className="text-4xl md:text-5xl font-black text-brand-dark mb-6 leading-tight">
              No somos una gestoría de papel.<br/>
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-slate-400 to-slate-600">Somos tu CFO Digital.</span>
            </h3>
            <p className="text-lg text-slate-600 leading-relaxed">
              Hemos seleccionado y conectado las mejores herramientas del mercado. 
              Tú tienes el control total en tiempo real; nosotros, la supervisión fiscal experta.
            </p>
          </div>
        </FadeIn>

        <div className="grid md:grid-cols-3 gap-8 relative items-start">
          
          {/* Línea conectora visual (Solo Desktop) */}
          <div className="hidden md:block absolute top-[140px] left-[16%] right-[16%] h-0.5 bg-gradient-to-r from-transparent via-blue-200 to-transparent -z-10 border-t border-dashed border-slate-300"></div>

          {/* CARD 1: QUIPU (Finanzas) */}
          <FadeIn delay={0.1} className="bg-white p-8 rounded-3xl border border-slate-200 shadow-xl hover:-translate-y-2 transition duration-300 relative group h-full flex flex-col">
            <div className="w-16 h-16 mx-auto bg-blue-50 border border-blue-100 rounded-2xl flex items-center justify-center shadow-sm mb-6 relative z-10 group-hover:scale-110 transition">
              <span className="text-3xl">📊</span>
            </div>
            <div className="text-center flex-1">
              <h4 className="text-xl font-bold text-brand-dark mb-1">Facturación & Bancos</h4>
              <p className="text-[10px] font-bold text-brand-blue uppercase mb-4 tracking-wider bg-blue-50 inline-block px-2 py-1 rounded">Powered by Quipu</p>
              <p className="text-slate-600 text-sm mb-6 leading-relaxed">
                Sube gastos con una foto. Conecta tus bancos para conciliación automática. Tu tesorería en tiempo real, sin excels arcaicos.
              </p>
            </div>
            <ul className="text-left text-xs font-medium space-y-3 bg-slate-50 p-4 rounded-xl text-slate-600 mt-auto">
                <li className="flex items-center gap-2">
                    <span className="w-4 h-4 bg-green-100 text-green-600 rounded-full flex items-center justify-center text-[10px]">✔</span> 
                    Digitalización Homologada
                </li>
                <li className="flex items-center gap-2">
                    <span className="w-4 h-4 bg-green-100 text-green-600 rounded-full flex items-center justify-center text-[10px]">✔</span> 
                    Conexión Bancaria PSD2
                </li>
            </ul>
          </FadeIn>

          {/* CARD 2: FISCALYX CORE (Tu valor) */}
          <FadeIn delay={0.2} className="bg-brand-dark text-white p-8 rounded-3xl shadow-2xl ring-4 ring-brand-blue/20 transform md:scale-110 z-20 relative h-full flex flex-col">
             <div className="w-20 h-20 mx-auto bg-brand-gold text-brand-dark rounded-full shadow-lg border-4 border-white flex items-center justify-center mb-6 relative z-10">
              <span className="text-4xl">🧠</span>
            </div>
            <div className="text-center flex-1">
              <h4 className="text-2xl font-bold text-white mb-1">Inteligencia Fiscal</h4>
              <p className="text-xs font-bold text-brand-gold uppercase mb-4 tracking-wider bg-white/10 inline-block px-2 py-1 rounded">Fiscalyx Core</p>
              <p className="text-slate-300 text-sm mb-6 leading-relaxed">
                Nuestros economistas auditan los datos que entran por tu software. Detectamos deducciones olvidadas y preparamos tus impuestos con garantía.
              </p>
              <div className="inline-block bg-gradient-to-r from-brand-blue to-blue-600 px-4 py-2 rounded-lg shadow-lg mb-4">
                <span className="text-white font-bold text-sm flex items-center gap-2">
                    🛡️ Blindaje ante Hacienda
                </span>
              </div>
            </div>
          </FadeIn>

          {/* CARD 3: BILKY (Laboral/Doc) */}
          <FadeIn delay={0.3} className="bg-white p-8 rounded-3xl border border-slate-200 shadow-xl hover:-translate-y-2 transition duration-300 relative group h-full flex flex-col">
            <div className="w-16 h-16 mx-auto bg-purple-50 border border-purple-100 rounded-2xl flex items-center justify-center shadow-sm mb-6 relative z-10 group-hover:scale-110 transition">
              <span className="text-3xl">👥</span>
            </div>
            <div className="text-center flex-1">
              <h4 className="text-xl font-bold text-brand-dark mb-1">Portal Empleado</h4>
              <p className="text-[10px] font-bold text-purple-600 uppercase mb-4 tracking-wider bg-purple-50 inline-block px-2 py-1 rounded">Powered by Bilky</p>
              <p className="text-slate-600 text-sm mb-6 leading-relaxed">
                Envía nóminas automáticamente. Tus empleados fichan, piden vacaciones y firman contratos desde la app móvil.
              </p>
            </div>
            <ul className="text-left text-xs font-medium space-y-3 bg-slate-50 p-4 rounded-xl text-slate-600 mt-auto">
                <li className="flex items-center gap-2">
                    <span className="w-4 h-4 bg-green-100 text-green-600 rounded-full flex items-center justify-center text-[10px]">✔</span> 
                    Cumplimiento RGPD
                </li>
                <li className="flex items-center gap-2">
                    <span className="w-4 h-4 bg-green-100 text-green-600 rounded-full flex items-center justify-center text-[10px]">✔</span> 
                    Firma Digital Biométrica
                </li>
            </ul>
          </FadeIn>
        </div>
        
        {/* Integraciones Logos (Social Proof Tech) */}
        <FadeIn delay={0.4} className="mt-20 pt-10 border-t border-slate-100 text-center">
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-8">Ecosistema Conectado (API)</p>
          <div className="flex flex-wrap justify-center items-center gap-8 md:gap-16 opacity-50 grayscale hover:grayscale-0 transition-all duration-500">
             {/* Textos placeholders estilizados como logos si no hay SVGs */}
             <span className="text-xl font-black text-slate-800 tracking-tight font-sans">stripe</span>
             <span className="text-xl font-bold text-slate-800 italic font-serif">Shopify</span>
             <span className="text-xl font-bold text-slate-800 tracking-tighter">PayPal</span>
             <span className="text-xl font-medium text-slate-800">PrestaShop</span>
             <span className="text-xl font-bold text-slate-800">AMAZON<span className="font-light">SELLER</span></span>
          </div>
        </FadeIn>
      </div>
    </section>
  );
};