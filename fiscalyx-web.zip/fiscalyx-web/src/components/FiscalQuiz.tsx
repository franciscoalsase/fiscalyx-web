'use client';

import { useState } from 'react';

// 👇 ID ACTUALIZADO: ESTE ES EL TUYO REAL
const FORMSPREE_ID = "xkgljdvq"; 

export const FiscalQuiz = () => {
  const [step, setStep] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false); 
  
  const [formData, setFormData] = useState({
    profile: '',
    volume: '',
    email: '',
    phone: ''
  });

  const handleOption = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    nextStep();
  };

  const nextStep = () => {
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      setStep(prev => prev + 1);
    }, 800);
  };

  const handleSubmit = async (e: any) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
        const response = await fetch(`https://formspree.io/f/${FORMSPREE_ID}`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Accept": "application/json"
            },
            body: JSON.stringify({
                email: formData.email,
                telefono: formData.phone,
                perfil: formData.profile,
                facturacion: formData.volume,
                _subject: "🚀 Nuevo Lead desde Web (FiscalQuiz)" // Asunto destacado
            })
        });

        if (response.ok) {
            // Éxito: Redirigimos
            window.location.href = 'https://calendly.com/francisco-alsase/30min';
        } else {
            // Error visible
            const data = await response.json();
            console.error("Error Formspree:", data);
            alert("Error al enviar. Por favor contáctanos por WhatsApp.");
            setIsSubmitting(false);
        }

    } catch (error) {
        console.error("Error de red:", error);
        // Fallback de seguridad: Abrimos calendario aunque falle el envío
        window.open('https://calendly.com/francisco-alsase/30min', '_blank');
        setIsSubmitting(false);
    }
  };

  return (
    <div className="bg-white rounded-3xl shadow-2xl overflow-hidden border border-slate-200 relative">
      {/* Barra de Progreso */}
      <div className="h-2 bg-slate-100 w-full">
        <div 
          className="h-full bg-brand-blue transition-all duration-500 ease-out"
          style={{ width: `${(step / 3) * 100}%` }}
        ></div>
      </div>

      <div className="p-8 md:p-12">
        
        {/* STEP 1: PERFILADO */}
        {step === 1 && (
          <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
            <h3 className="text-2xl font-black text-brand-dark mb-6 text-center text-slate-800">
              ¿Qué perfil describe mejor tu situación?
            </h3>
            <div className="grid gap-4">
              <button onClick={() => handleOption('profile', 'crypto')} className="p-4 rounded-xl border-2 border-slate-100 hover:border-brand-blue hover:bg-blue-50 transition text-left group">
                <span className="font-bold text-brand-dark block group-hover:text-brand-blue">💎 Inversor Cripto / DeFi</span>
                <span className="text-sm text-slate-500">Tengo dudas con permutas, staking o Modelo 721.</span>
              </button>
              <button onClick={() => handleOption('profile', 'autonomo')} className="p-4 rounded-xl border-2 border-slate-100 hover:border-brand-blue hover:bg-blue-50 transition text-left group">
                <span className="font-bold text-brand-dark block group-hover:text-brand-blue">💼 Autónomo / Freelance</span>
                <span className="text-sm text-slate-500">Busco pagar menos impuestos y ahorrar tiempo.</span>
              </button>
              <button onClick={() => handleOption('profile', 'empresa')} className="p-4 rounded-xl border-2 border-slate-100 hover:border-brand-blue hover:bg-blue-50 transition text-left group">
                <span className="font-bold text-brand-dark block group-hover:text-brand-blue">🏢 Empresa / PYME</span>
                <span className="text-sm text-slate-500">Necesito planificación fiscal y cierre contable.</span>
              </button>
            </div>
          </div>
        )}

        {/* STEP 2: VOLUMEN */}
        {step === 2 && !isLoading && (
          <div className="animate-in fade-in slide-in-from-right-8 duration-500">
            <h3 className="text-2xl font-black text-brand-dark mb-6 text-center text-slate-800">
              {formData.profile === 'crypto' ? '¿Volumen aproximado de cartera?' : '¿Facturación anual aproximada?'}
            </h3>
            <div className="grid gap-4">
              <button onClick={() => handleOption('volume', 'low')} className="p-5 rounded-xl border-2 border-slate-100 hover:border-brand-blue hover:bg-blue-50 transition font-bold text-slate-600 hover:text-brand-blue">
                Menos de 30.000€
              </button>
              <button onClick={() => handleOption('volume', 'mid')} className="p-5 rounded-xl border-2 border-slate-100 hover:border-brand-blue hover:bg-blue-50 transition font-bold text-slate-600 hover:text-brand-blue">
                Entre 30.000€ y 100.000€
              </button>
              <button onClick={() => handleOption('volume', 'high')} className="p-5 rounded-xl border-2 border-brand-blue bg-blue-50 transition font-bold text-brand-blue ring-2 ring-brand-blue/20">
                Más de 100.000€ (Requiere Planificación)
              </button>
            </div>
          </div>
        )}

        {/* LOADING STATE */}
        {isLoading && (
          <div className="text-center py-12 animate-pulse">
            <div className="w-16 h-16 border-4 border-brand-blue border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            <p className="font-bold text-slate-500">Analizando perfil fiscal...</p>
          </div>
        )}

        {/* STEP 3: RESULTADO + CAPTURA */}
        {step === 3 && !isLoading && (
          <div className="animate-in zoom-in duration-500 text-center">
            
            <div className="mb-8">
              <span className="inline-block px-4 py-1 rounded-full bg-red-100 text-red-600 text-xs font-black uppercase tracking-widest mb-4">
                Diagnóstico Preliminar
              </span>
              
              {formData.profile === 'crypto' ? (
                <h3 className="text-2xl font-bold text-brand-dark">
                  Atención: Tus operaciones requieren <span className="text-brand-blue decoration-wavy underline">trazabilidad FIFO</span> para evitar sanciones.
                </h3>
              ) : (
                <h3 className="text-2xl font-bold text-brand-dark">
                  Hemos detectado potencial de <span className="text-green-600">ahorro fiscal</span> no aplicado en tu tramo.
                </h3>
              )}
              
              <p className="text-slate-500 mt-4 text-sm">
                Déjanos tus datos para recibir el informe y agendar tu sesión estratégica gratuita.
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4 text-left">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Tu Email</label>
                <input 
                  type="email" 
                  name="email"
                  required 
                  value={formData.email}
                  className="w-full px-4 py-3 rounded-lg border border-slate-300 focus:ring-2 focus:ring-brand-blue focus:border-transparent outline-none transition text-slate-800 bg-white"
                  placeholder="ejemplo@email.com"
                  onChange={(e) => setFormData(prev => ({...prev, email: e.target.value}))}
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Teléfono (WhatsApp)</label>
                <input 
                  type="tel" 
                  name="phone"
                  required 
                  value={formData.phone}
                  className="w-full px-4 py-3 rounded-lg border border-slate-300 focus:ring-2 focus:ring-brand-blue focus:border-transparent outline-none transition text-slate-800 bg-white"
                  placeholder="+34 600..."
                  onChange={(e) => setFormData(prev => ({...prev, phone: e.target.value}))}
                />
              </div>
              
              <button 
                type="submit" 
                disabled={isSubmitting}
                className={`w-full text-white font-black py-4 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 ${isSubmitting ? 'bg-slate-400 cursor-wait' : 'bg-brand-blue hover:bg-blue-600 hover:-translate-y-1'}`}
              >
                {isSubmitting ? 'PROCESANDO...' : 'DESBLOQUEAR MI DIAGNÓSTICO →'}
              </button>
              <p className="text-[10px] text-slate-400 text-center">Datos protegidos bajo RGPD. Sin compromiso.</p>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};