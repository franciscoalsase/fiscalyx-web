'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';

export const CookieBanner = () => {
  const [show, setShow] = useState(false);

  useEffect(() => {
    // Comprobamos si ya aceptó las cookies antes
    const consent = localStorage.getItem('fiscalyx-cookie-consent');
    if (!consent) {
      // Esperamos 1 segundo para mostrarlo suavemente
      const timer = setTimeout(() => setShow(true), 1000);
      return () => clearTimeout(timer);
    }
  }, []);

  const acceptCookies = () => {
    localStorage.setItem('fiscalyx-cookie-consent', 'true');
    setShow(false);
  };

  if (!show) return null;

  return (
    <div className="fixed bottom-4 left-4 right-4 md:left-auto md:right-8 md:bottom-8 md:max-w-md bg-brand-dark/95 backdrop-blur-md text-white p-6 rounded-2xl shadow-2xl border border-slate-700 z-50 animate-in slide-in-from-bottom-10 fade-in duration-500">
      <div className="flex items-start gap-4">
        <div className="text-2xl">🍪</div>
        <div>
          <h4 className="font-bold text-sm mb-2">Privacidad y Cookies</h4>
          <p className="text-xs text-slate-300 mb-4 leading-relaxed">
            Usamos cookies propias y de terceros para analizar tu navegación y proteger tu seguridad. Nada de vender datos. 
            <Link href="/legal/privacidad" className="underline ml-1 hover:text-white">Ver política</Link>.
          </p>
          <div className="flex gap-3">
            <button 
              onClick={acceptCookies}
              className="bg-white text-brand-dark px-4 py-2 rounded-lg text-xs font-bold hover:bg-slate-200 transition"
            >
              Aceptar Todo
            </button>
            <button 
              onClick={() => setShow(false)}
              className="text-slate-400 px-2 py-2 text-xs font-bold hover:text-white transition"
            >
              Rechazar
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};