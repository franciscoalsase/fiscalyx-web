'use client';

export const HeroVisual = () => {
  return (
    <div className="relative w-full h-[400px] lg:h-[500px] flex items-center justify-center perspective-1000">
      {/* Fondos de luz (Glow) */}
      <div className="absolute w-[300px] h-[300px] bg-blue-400 rounded-full blur-[80px] opacity-20 animate-pulse"></div>
      <div className="absolute w-[250px] h-[250px] bg-purple-400 rounded-full blur-[80px] opacity-20 -translate-x-10 translate-y-10"></div>
      
      {/* TARJETA PRINCIPAL 3D */}
      <div className="relative z-10 bg-white p-6 rounded-2xl shadow-2xl border border-slate-100 max-w-sm w-full transform rotate-3 transition duration-500 hover:rotate-0 hover:scale-105 cursor-default">
        
        {/* Cabecera Tarjeta */}
        <div className="flex justify-between items-center mb-6">
          <div className="flex gap-2">
            <div className="w-3 h-3 rounded-full bg-red-400"></div>
            <div className="w-3 h-3 rounded-full bg-yellow-400"></div>
            <div className="w-3 h-3 rounded-full bg-green-400"></div>
          </div>
          <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">FISCALYX COCKPIT</div>
        </div>

        {/* Contenido Simulado */}
        <div className="space-y-4">
          {/* Estado Impuestos */}
          <div className="flex justify-between items-center p-3 bg-slate-50 rounded-lg border border-slate-100">
            <div className="flex items-center gap-3">
                <span className="text-lg">🏢</span>
                <span className="text-sm font-bold text-slate-600">Impuesto Sociedades</span>
            </div>
            <span className="text-xs font-bold text-green-600 bg-green-100 px-2 py-1 rounded-full">Presentado ✔</span>
          </div>

          <div className="flex justify-between items-center p-3 bg-slate-50 rounded-lg border border-slate-100">
             <div className="flex items-center gap-3">
                <span className="text-lg">📅</span>
                <span className="text-sm font-bold text-slate-600">IVA Trimestral</span>
            </div>
            <span className="text-xs font-bold text-blue-600 bg-blue-100 px-2 py-1 rounded-full animate-pulse">En proceso ↻</span>
          </div>

          {/* Gráfico de Barras */}
          <div className="h-32 bg-slate-50 rounded-lg border border-slate-100 flex items-end justify-center gap-3 p-4">
             {/* Barra 1 */}
             <div className="w-8 bg-blue-200 h-[40%] rounded-t-md relative group">
                <div className="absolute -top-6 left-1/2 -translate-x-1/2 text-[10px] text-slate-500 opacity-0 group-hover:opacity-100 transition">Q1</div>
             </div>
             {/* Barra 2 */}
             <div className="w-8 bg-blue-300 h-[60%] rounded-t-md relative group">
                <div className="absolute -top-6 left-1/2 -translate-x-1/2 text-[10px] text-slate-500 opacity-0 group-hover:opacity-100 transition">Q2</div>
             </div>
             {/* Barra 3 (Destacada) */}
             <div className="w-8 bg-brand-blue h-[85%] rounded-t-md relative group shadow-lg shadow-blue-500/30">
                 <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-slate-800 text-white text-[10px] py-1 px-2 rounded shadow-md opacity-0 group-hover:opacity-100 transition whitespace-nowrap z-20">
                    Ahorro: +15%
                 </div>
             </div>
             {/* Barra 4 */}
             <div className="w-8 bg-blue-200 h-[50%] rounded-t-md"></div>
          </div>
        </div>

        {/* Botones Footer Tarjeta */}
        <div className="mt-6 flex gap-3">
           <div className="flex-1 bg-brand-dark text-white text-center py-2 rounded-lg text-xs font-bold shadow-lg">Ver Informe</div>
           <div className="flex-1 bg-white border border-slate-200 text-slate-600 text-center py-2 rounded-lg text-xs font-bold">Descargar PDF</div>
        </div>

        {/* Notificación Flotante */}
        <div className="absolute -right-12 top-10 bg-white p-3 rounded-xl shadow-xl border border-slate-100 flex items-center gap-3 animate-bounce delay-700">
            <div className="w-8 h-8 bg-green-100 text-green-600 rounded-full flex items-center justify-center font-bold text-lg">€</div>
            <div className="text-xs">
                <div className="font-bold text-slate-800">Deducción Detectada</div>
                <div className="text-slate-500">+120€ Recuperados</div>
            </div>
        </div>

      </div>
    </div>
  );
};