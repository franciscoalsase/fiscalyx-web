import React from 'react';

export const Logo = ({ className = "", isDark = false }) => {
  // Colores dinámicos según si el fondo es oscuro o claro
  const textColor = isDark ? "text-white" : "text-brand-dark";
  const accentColor = "text-brand-blue"; // El punto azul
  const iconPrimary = "text-brand-blue"; // Parte principal del icono
  const iconSecondary = isDark ? "text-brand-gold" : "text-brand-dark"; // Parte secundaria

  return (
    <div className={`flex items-center gap-2 ${className}`}>
      {/* ÍCONO SVG VECTORIAL PROPIO */}
      <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" className="shrink-0">
        <path d="M6 26V6H16" stroke="currentColor" className={iconSecondary} strokeWidth="2.5" strokeLinecap="round"/>
        <path d="M6 16H14" stroke="currentColor" className={iconSecondary} strokeWidth="2.5" strokeLinecap="round"/>
        {/* La flecha de crecimiento azul */}
        <path d="M18 20L22 16L28 22" stroke="currentColor" className={iconPrimary} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M28 16V22H22" stroke="currentColor" className={iconPrimary} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
        {/* Círculo de seguridad */}
        <circle cx="24" cy="8" r="3" fill="currentColor" className={iconSecondary} opacity="0.8"/>
      </svg>

      {/* TEXTO */}
      <span className={`font-extrabold tracking-tight text-2xl ${textColor}`}>
        FISCALYX<span className={accentColor}>.</span>
      </span>
    </div>
  );
};