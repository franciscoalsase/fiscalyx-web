'use client';

import { useState, useEffect } from 'react';

export const MobileActionBar = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      // Solo mostramos la barra si el usuario ha bajado un poco (100px)
      if (window.scrollY > 100) {
        setIsVisible(true);
      } else {
        setIsVisible(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  if (!isVisible) return null;

  return (
    <div className="fixed bottom-0 left-0 w-full bg-white border-t border-slate-200 p-3 z-50 lg:hidden shadow-[0_-5px_20px_rgba(0,0,0,0.05)] animate-in slide-in-from-bottom-full duration-300">
      <div className="grid grid-cols-2 gap-3">
        <a 
          href="https://wa.me/34600000000" 
          target="_blank"
          className="flex items-center justify-center gap-2 bg-green-50 text-green-700 font-bold py-3 rounded-xl border border-green-200"
        >
          <span className="text-xl">💬</span> WhatsApp
        </a>
        <button 
          onClick={() => window.open('https://calendly.com/francisco-alsase/30min', '_blank')}
          className="flex items-center justify-center gap-2 bg-brand-blue text-white font-bold py-3 rounded-xl shadow-lg shadow-blue-500/30"
        >
          📅 Agendar Cita
        </button>
      </div>
    </div>
  );
};