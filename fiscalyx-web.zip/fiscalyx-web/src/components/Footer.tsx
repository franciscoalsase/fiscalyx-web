import Link from "next/link";
import { Logo } from "@/components/Logo";

export const Footer = () => {
  return (
    <footer id="contacto" className="bg-slate-50 border-t border-slate-200 pt-20 pb-10 font-sans">
      <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-12 text-sm">
        
        {/* COLUMNA 1: MARCA Y MAPA */}
        <div className="md:col-span-2 pr-8">
          <Link href="/" className="inline-block hover:opacity-80 transition">
             <Logo className="scale-100 origin-left mb-6" />
          </Link>
          <p className="mt-4 text-slate-500 text-sm leading-relaxed mb-6">
            Tu asesoría inteligente. Combinamos la experiencia de economistas colegiados con tecnología en la nube para darte un servicio rápido, seguro y sin papeles.
          </p>
          
           {/* MAPA (Apunta a ULab Alicante o tu dirección comercial) */}
           <div className="rounded-xl overflow-hidden h-40 shadow-sm border border-slate-200 relative bg-slate-200 group">
              <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3129.544379045366!2d-0.4945256846668483!3d38.33592697966146!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd6237b05057696b%3A0x502af6ed82073c9!2sAv.%20Maisonnave%2C%20Alicante!5e0!3m2!1ses!2ses!4v1678901234567!5m2!1ses!2ses" 
                width="100%" 
                height="100%" 
                style={{border:0}} 
                allowFullScreen 
                loading="lazy"
                className="grayscale group-hover:grayscale-0 transition duration-500"
              ></iframe>
          </div>
        </div>

        {/* COLUMNA 2: FISCAL & CONTABLE */}
        <div>
          <h4 className="font-bold text-brand-dark mb-6 uppercase tracking-wider text-xs border-b border-slate-200 pb-2 inline-block">Fiscal y Contable</h4>
          <ul className="space-y-3 text-slate-500">
            {/* CORRECCIÓN: Añadida la barra '/' para que funcione desde el Blog */}
            <li><Link href="/#servicios" className="hover:text-brand-blue transition">Alta de Autónomos</Link></li>
            <li><Link href="/#servicios" className="hover:text-brand-blue transition">Creación de S.L.</Link></li>
            <li><Link href="/#servicios" className="hover:text-brand-blue transition">Declaración de la Renta</Link></li>
            <li><Link href="/#servicios" className="hover:text-brand-blue transition">IVA e IRPF</Link></li>
            <li><Link href="/#servicios" className="hover:text-brand-blue transition">Contabilidad Analítica</Link></li>
            <li><Link href="/#servicios" className="hover:text-brand-blue transition">Inspecciones AEAT</Link></li>
          </ul>
        </div>

        {/* COLUMNA 3: CRIPTO */}
        <div>
          <h4 className="font-bold text-brand-dark mb-6 uppercase tracking-wider text-xs border-b border-slate-200 pb-2 inline-block">Cripto & Web3</h4>
          <ul className="space-y-3 text-slate-500">
            <li><Link href="/servicios/cripto" className="hover:text-brand-blue transition font-medium text-slate-700">Modelo 721</Link></li>
            <li><Link href="/servicios/cripto" className="hover:text-brand-blue transition">Renta Criptomonedas</Link></li>
            <li><Link href="/servicios/cripto" className="hover:text-brand-blue transition">Trazabilidad DeFi</Link></li>
            <li><Link href="/servicios" className="hover:text-brand-blue transition">E-commerce & FBA</Link></li>
            <li><Link href="/cockpit" className="text-brand-blue font-bold hover:underline transition flex items-center gap-1">
                Área Cliente <span className="text-[10px]">🔒</span>
            </Link></li>
          </ul>
        </div>

        {/* COLUMNA 4: LABORAL & LEGAL */}
        <div>
          <h4 className="font-bold text-brand-dark mb-6 uppercase tracking-wider text-xs border-b border-slate-200 pb-2 inline-block">Laboral y Legal</h4>
          <ul className="space-y-3 text-slate-500">
            <li><Link href="/servicios" className="hover:text-brand-blue transition">Nóminas y Seguros</Link></li>
            <li><Link href="/servicios" className="hover:text-brand-blue transition">Despidos y Finiquitos</Link></li>
            <li><Link href="/servicios" className="hover:text-brand-blue transition">Herencias y Donaciones</Link></li>
            
            <li className="pt-4 mt-2 border-t border-slate-200">
                <Link href="/legal/aviso-legal" className="hover:text-brand-blue transition text-xs">Aviso Legal</Link>
            </li>
            <li>
                <Link href="/legal/privacidad" className="hover:text-brand-blue transition text-xs">Política de Privacidad</Link>
            </li>
          </ul>
        </div>

      </div>
      
      {/* BARRA INFERIOR */}
      <div className="max-w-7xl mx-auto px-6 mt-16 pt-8 border-t border-slate-200 flex flex-col md:flex-row justify-between items-center text-xs text-slate-400 gap-4">
        <p>© 2025 Fiscalyx Asesores. Marca comercial registrada.</p>
        <div className="flex flex-wrap justify-center gap-6">
            <span className="flex items-center gap-1">📍 Alicante: Plaza San Cristóbal, 14</span>
            <a href="tel:+34966000000" className="text-brand-blue font-bold hover:underline flex items-center gap-1">
                📞 966 00 00 00
            </a>
        </div>
      </div>
    </footer>
  );
};