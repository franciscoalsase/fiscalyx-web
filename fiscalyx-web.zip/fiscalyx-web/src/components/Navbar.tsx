'use client';

import { useState } from 'react';
import Link from 'next/link';
import { Logo } from '@/components/Logo';

export const Navbar = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <nav className="sticky top-0 z-40 bg-white/90 backdrop-blur-md border-b border-slate-200/60 shadow-sm">
        <div className="max-w-7xl mx-auto px-6 h-20 flex justify-between items-center">
          <Link href="/" className="z-50 hover:opacity-80 transition" aria-label="FiscalYX - Inicio"><Logo /></Link>

          {/* CENTRO: NAVEGACIÓN PÚBLICA (SEO) */}
          <div className="hidden lg:flex gap-8 text-sm font-bold text-slate-600">
            <Link href="/servicios" className="hover:text-brand-blue transition py-2">Servicios</Link>
            
            <Link href="/servicios/cripto" className="text-brand-blue/80 hover:text-brand-blue transition py-2 flex items-center gap-1">
               <span className="text-xs">💎</span> Cripto
            </Link>
            
            <Link href="/#precios" className="hover:text-brand-blue transition py-2">Precios</Link>
            
            <Link href="/blog" className="hover:text-brand-blue transition py-2">Blog</Link>
          </div>

          {/* DERECHA: ZONA DE ACCIÓN (CONVERSIÓN + CLIENTES) */}
          <div className="hidden lg:flex items-center gap-4">
            
            {/* Área Cliente movida aquí para separar "Info" de "Login" */}
            <Link href="/cockpit" className="text-sm font-bold text-slate-500 hover:text-brand-blue transition flex items-center gap-2 mr-2">
               <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span> Área Cliente
            </Link>

            <Link href="/contratar" className="px-5 py-2.5 text-sm font-bold text-brand-dark border border-slate-300 rounded-lg hover:bg-slate-50 transition">
              Ver Planes
            </Link>
            
            <Link href="/#quiz-section" className="group flex items-center gap-2 px-5 py-2.5 text-sm font-bold text-white bg-brand-blue rounded-lg hover:bg-blue-700 transition shadow-lg shadow-blue-500/20">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
              EMPEZAR
            </Link>
          </div>

          {/* BOTÓN MENÚ MÓVIL */}
          <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className="lg:hidden p-2 text-brand-dark focus:outline-none" aria-label="Menú móvil">
            <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16"></path></svg>
          </button>
        </div>

        {/* MENÚ MÓVIL DESPLEGABLE */}
        {isMobileMenuOpen && (
          <div className="absolute top-20 left-0 w-full bg-white border-b border-slate-200 shadow-xl p-6 flex flex-col gap-4 lg:hidden z-40 animate-in slide-in-from-top-5">
            <Link href="/servicios" onClick={() => setIsMobileMenuOpen(false)} className="text-lg font-bold text-slate-700 py-2 border-b border-slate-50">Servicios</Link>
            
            <Link href="/servicios/cripto" onClick={() => setIsMobileMenuOpen(false)} className="text-lg font-bold text-purple-600 py-2 border-b border-slate-50">Cripto Especializado</Link>
            
            <Link href="/#precios" onClick={() => setIsMobileMenuOpen(false)} className="text-lg font-bold text-slate-700 py-2 border-b border-slate-50">Precios</Link>
            
            <Link href="/blog" onClick={() => setIsMobileMenuOpen(false)} className="text-lg font-bold text-slate-700 py-2 border-b border-slate-50">Blog</Link>
            
            <Link href="/cockpit" onClick={() => setIsMobileMenuOpen(false)} className="text-lg font-bold text-brand-blue py-2 border-b border-slate-50 flex items-center gap-2 bg-slate-50 px-4 rounded-lg">
                <span className="w-2 h-2 bg-green-500 rounded-full"></span> Acceso Área Cliente
            </Link>

            <Link href="/contratar" onClick={() => setIsMobileMenuOpen(false)} className="w-full text-center px-5 py-3 text-sm font-bold text-brand-dark border border-slate-200 rounded-lg">
              Ver Planes
            </Link>
            
            <Link href="/#quiz-section" onClick={() => setIsMobileMenuOpen(false)} className="w-full text-center px-5 py-3 text-sm font-bold text-white bg-brand-blue rounded-lg">DIAGNÓSTICO GRATIS</Link>
          </div>
        )}
      </nav>
  );
};