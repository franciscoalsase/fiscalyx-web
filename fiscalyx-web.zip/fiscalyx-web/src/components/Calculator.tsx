"use client";
import { useState } from "react";
import Link from "next/link";

export const Calculator = () => {
  const [ingresos, setIngresos] = useState<number | "">("");
  const [gastos, setGastos] = useState<number | "">("");
  const [cuota, setCuota] = useState<number | null>(null);

  const calcularCuota = () => {
    // Evitar negativos
    const ing = Number(ingresos) || 0;
    const gas = Number(gastos) || 0;
    const neto = Math.max(0, ing - gas); // Si sale negativo, es 0
    
    let resultado = 0;

    // Estimación Tramos 2025 (Base mínima del tramo aprox)
    if (neto <= 670) resultado = 200; 
    else if (neto <= 900) resultado = 260;
    else if (neto <= 1166) resultado = 275;
    else if (neto <= 1300) resultado = 286;
    else if (neto <= 1500) resultado = 294;
    else if (neto <= 1700) resultado = 310;
    else if (neto <= 1850) resultado = 320;
    else if (neto <= 2030) resultado = 330;
    else if (neto <= 2330) resultado = 340;
    else if (neto <= 2760) resultado = 360;
    else if (neto <= 3190) resultado = 380;
    else if (neto <= 3620) resultado = 400;
    else if (neto <= 4050) resultado = 420;
    else if (neto <= 6000) resultado = 445;
    else resultado = 530; // Tope máximo

    setCuota(resultado);
  };

  return (
    <div className="w-full bg-white p-6 md:p-8 rounded-3xl shadow-2xl border border-slate-100 relative overflow-hidden transform transition-all hover:shadow-3xl">
      {/* Etiqueta Superior */}
      <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-brand-blue to-brand-gold"></div>
      
      <div className="text-center mb-6">
        <span className="bg-green-100 text-green-700 text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-wider">Simulador 2025</span>
        <h3 className="text-2xl font-extrabold text-brand-dark mt-3 leading-tight">Calcula tu Cuota</h3>
        <p className="text-slate-500 text-sm mt-2">Descubre si estás pagando de más a la Seguridad Social.</p>
      </div>

      <div className="space-y-4">
        <div>
          <label className="block text-xs font-bold text-slate-500 uppercase mb-1 ml-1">Ingresos Mensuales (€)</label>
          <input 
            type="number" 
            value={ingresos} 
            onChange={(e) => setIngresos(Number(e.target.value))}
            placeholder="Ej: 2500"
            className="w-full p-4 bg-slate-50 border border-slate-200 rounded-xl font-bold text-brand-dark focus:ring-2 focus:ring-brand-blue outline-none transition text-lg placeholder:font-normal"
          />
        </div>
        
        <div>
          <label className="block text-xs font-bold text-slate-500 uppercase mb-1 ml-1">Gastos Mensuales (€)</label>
          <input 
            type="number" 
            value={gastos} 
            onChange={(e) => setGastos(Number(e.target.value))}
            placeholder="Ej: 500"
            className="w-full p-4 bg-slate-50 border border-slate-200 rounded-xl font-bold text-brand-dark focus:ring-2 focus:ring-brand-blue outline-none transition text-lg placeholder:font-normal"
          />
        </div>

        <button 
          onClick={calcularCuota}
          className="w-full bg-brand-dark text-white font-bold py-4 rounded-xl hover:bg-slate-800 transition shadow-lg transform hover:scale-[1.02] active:scale-95 uppercase tracking-wide text-sm"
        >
          Calcular Ahora
        </button>
      </div>

      {/* RESULTADO CON GANCHO DE VENTA */}
      {cuota !== null && (
        <div className="mt-6 pt-6 border-t border-slate-100 text-center animate-in fade-in slide-in-from-bottom-4 duration-500">
          <p className="text-sm text-slate-500 mb-1">Tu cuota estimada según tablas:</p>
          <div className="text-5xl font-black text-brand-blue mb-4 tracking-tighter">{cuota}€<span className="text-lg font-medium text-slate-400">/mes</span></div>
          
          {/* EL GANCHO DE MIEDO/OPORTUNIDAD */}
          <div className="bg-orange-50 border border-orange-100 rounded-xl p-4 mb-6 text-left relative">
            <div className="absolute -left-1 top-4 w-1 h-8 bg-orange-400 rounded-r"></div>
            <p className="text-xs md:text-sm text-orange-900 leading-relaxed">
                <strong className="block mb-1 text-orange-600 text-base">⚠️ ¿Sabías que podrías pagar menos?</strong>
                Muchos autónomos no deducen correctamente gastos como suministros, vehículo o dietas. Si optimizamos tu tramo, <strong>esta cuota podría bajar.</strong>
            </p>
          </div>
          
          <Link href="/presupuesto" className="block w-full bg-green-600 text-white font-bold py-4 rounded-xl hover:bg-green-500 transition shadow-xl shadow-green-600/20 transform hover:-translate-y-1 flex items-center justify-center gap-2">
            <span>📉</span> QUIERO REVISAR MI TRAMO
          </Link>
          <p className="text-[10px] text-slate-400 mt-3">Estudio de optimización gratuito.</p>
        </div>
      )}
    </div>
  );
};