(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_f6c9c943._.js",
  "static/chunks/src_8ef6aab0._.js"
],
    source: "dynamic"
});
