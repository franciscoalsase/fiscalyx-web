(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_d5e38b9b._.js",
  "static/chunks/src_components_FadeIn_tsx_e6bbaa0a._.js"
],
    source: "dynamic"
});
