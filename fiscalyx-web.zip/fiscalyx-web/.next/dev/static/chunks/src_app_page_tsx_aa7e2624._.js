(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_68abc5ff._.js",
  "static/chunks/node_modules_e78a3e92._.js"
],
    source: "dynamic"
});
