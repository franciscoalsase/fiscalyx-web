module.exports = [
"[project]/.next-internal/server/app/blog/retirar-binance-hacienda/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_blog_retirar-binance-hacienda_page_actions_ed3c506f.js.map