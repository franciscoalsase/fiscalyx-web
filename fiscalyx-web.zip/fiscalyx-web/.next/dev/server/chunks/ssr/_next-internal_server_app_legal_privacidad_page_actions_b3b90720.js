module.exports = [
"[project]/.next-internal/server/app/legal/privacidad/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_legal_privacidad_page_actions_b3b90720.js.map