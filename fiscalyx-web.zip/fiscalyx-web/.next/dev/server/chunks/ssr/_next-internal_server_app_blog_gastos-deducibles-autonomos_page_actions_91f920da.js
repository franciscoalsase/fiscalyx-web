module.exports = [
"[project]/.next-internal/server/app/blog/gastos-deducibles-autonomos/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_blog_gastos-deducibles-autonomos_page_actions_91f920da.js.map