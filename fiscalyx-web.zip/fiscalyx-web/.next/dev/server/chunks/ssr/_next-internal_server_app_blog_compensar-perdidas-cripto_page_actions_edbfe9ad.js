module.exports = [
"[project]/.next-internal/server/app/blog/compensar-perdidas-cripto/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_blog_compensar-perdidas-cripto_page_actions_edbfe9ad.js.map