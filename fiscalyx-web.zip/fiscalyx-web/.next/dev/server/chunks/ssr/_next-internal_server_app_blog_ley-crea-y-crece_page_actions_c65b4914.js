module.exports = [
"[project]/.next-internal/server/app/blog/ley-crea-y-crece/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_blog_ley-crea-y-crece_page_actions_c65b4914.js.map