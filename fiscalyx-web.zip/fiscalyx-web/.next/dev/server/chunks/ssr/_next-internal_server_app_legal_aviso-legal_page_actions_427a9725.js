module.exports = [
"[project]/.next-internal/server/app/legal/aviso-legal/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_legal_aviso-legal_page_actions_427a9725.js.map