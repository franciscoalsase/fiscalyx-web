module.exports = [
"[project]/.next-internal/server/app/blog/factura-electronica-obligatoria/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=ce889_server_app_blog_factura-electronica-obligatoria_page_actions_d3409748.js.map