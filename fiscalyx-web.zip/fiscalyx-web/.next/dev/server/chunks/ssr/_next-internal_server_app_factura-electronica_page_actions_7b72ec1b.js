module.exports = [
"[project]/.next-internal/server/app/factura-electronica/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_factura-electronica_page_actions_7b72ec1b.js.map