module.exports = [
"[project]/.next-internal/server/app/politica-privacidad/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_politica-privacidad_page_actions_218693e0.js.map