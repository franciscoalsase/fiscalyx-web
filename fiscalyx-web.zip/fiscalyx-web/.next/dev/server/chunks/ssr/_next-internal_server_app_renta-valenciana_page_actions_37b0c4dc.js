module.exports = [
"[project]/.next-internal/server/app/renta-valenciana/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_renta-valenciana_page_actions_37b0c4dc.js.map