module.exports = [
"[project]/src/app/layout.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "metadata",
    ()=>metadata
]);
const metadata = {
    title: "Fiscalyx | Asesoría en Alicante, Vega Baja y Online",
    description: "Asesoría fiscal y legal líder en la Vega Baja (Callosa, Orihuela, Torrevieja) y Alicante. Expertos en Fiscalidad Digital y Criptomonedas para toda España.",
    keywords: [
        "asesoría vega baja",
        "gestoría alicante",
        "abogados orihuela",
        "declaración criptomonedas españa",
        "asesor fiscal online"
    ]
};
}),
];

//# sourceMappingURL=src_app_layout_tsx_cc8184fa._.js.map