module.exports = [
"[project]/.next-internal/server/app/servicios/cripto/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_servicios_cripto_page_actions_f314f1ce.js.map