module.exports = [
"[project]/src/app/favicon.ico.mjs { IMAGE => \"[project]/src/app/favicon.ico (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/favicon.ico.mjs { IMAGE => \"[project]/src/app/favicon.ico (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript)"));
}),
"[project]/src/app/icon.svg.mjs { IMAGE => \"[project]/src/app/icon.svg (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/icon.svg.mjs { IMAGE => \"[project]/src/app/icon.svg (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript)"));
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[project]/src/app/layout.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/layout.tsx [app-rsc] (ecmascript)"));
}),
"[project]/src/app/servicios/page.tsx [app-rsc] (ecmascript)", ((__turbopack_context__, module, exports) => {

const { jsxDEV: _jsxDEV } = __turbopack_context__.r("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
{}/*#__PURE__*/ _jsxDEV("section", {
    className: "py-20 bg-white",
    children: /*#__PURE__*/ _jsxDEV("div", {
        className: "max-w-7xl mx-auto px-6",
        children: [
            /*#__PURE__*/ _jsxDEV("div", {
                className: "text-center mb-12",
                children: [
                    /*#__PURE__*/ _jsxDEV("h2", {
                        className: "text-sm font-bold text-brand-blue tracking-widest uppercase mb-2",
                        children: "Método Fiscalyx"
                    }, void 0, false, {
                        fileName: "[project]/src/app/servicios/page.tsx",
                        lineNumber: 5,
                        columnNumber: 17
                    }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                    /*#__PURE__*/ _jsxDEV("h3", {
                        className: "text-3xl font-extrabold text-brand-dark",
                        children: "Tu gestoría en 3 pasos"
                    }, void 0, false, {
                        fileName: "[project]/src/app/servicios/page.tsx",
                        lineNumber: 6,
                        columnNumber: 17
                    }, /*TURBOPACK member replacement*/ __turbopack_context__.e)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/servicios/page.tsx",
                lineNumber: 4,
                columnNumber: 13
            }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
            /*#__PURE__*/ _jsxDEV("div", {
                className: "grid md:grid-cols-3 gap-8 relative",
                children: [
                    /*#__PURE__*/ _jsxDEV("div", {
                        className: "hidden md:block absolute top-1/2 left-0 w-full h-1 bg-slate-100 -z-10 -translate-y-1/2"
                    }, void 0, false, {
                        fileName: "[project]/src/app/servicios/page.tsx",
                        lineNumber: 10,
                        columnNumber: 17
                    }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                    /*#__PURE__*/ _jsxDEV(FadeIn, {
                        delay: 0.1,
                        className: "bg-white p-6 text-center border border-slate-100 rounded-2xl shadow-sm",
                        children: [
                            /*#__PURE__*/ _jsxDEV("div", {
                                className: "w-16 h-16 mx-auto bg-blue-50 rounded-full flex items-center justify-center text-3xl mb-4 border-4 border-white shadow-md",
                                children: "✍️"
                            }, void 0, false, {
                                fileName: "[project]/src/app/servicios/page.tsx",
                                lineNumber: 13,
                                columnNumber: 21
                            }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                            /*#__PURE__*/ _jsxDEV("h4", {
                                className: "font-bold text-brand-dark mb-2",
                                children: "1. Alta / Cambio"
                            }, void 0, false, {
                                fileName: "[project]/src/app/servicios/page.tsx",
                                lineNumber: 14,
                                columnNumber: 21
                            }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                            /*#__PURE__*/ _jsxDEV("p", {
                                className: "text-sm text-slate-500",
                                children: [
                                    "Nos das tus datos. Si eres nuevo, te damos el ",
                                    /*#__PURE__*/ _jsxDEV("strong", {
                                        children: "Alta en Hacienda y RETA Gratis"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/servicios/page.tsx",
                                        lineNumber: 15,
                                        columnNumber: 105
                                    }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                                    ". Si vienes de otro gestor, hacemos el traspaso sin que tú hables con él."
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/servicios/page.tsx",
                                lineNumber: 15,
                                columnNumber: 21
                            }, /*TURBOPACK member replacement*/ __turbopack_context__.e)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/servicios/page.tsx",
                        lineNumber: 12,
                        columnNumber: 17
                    }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                    /*#__PURE__*/ _jsxDEV(FadeIn, {
                        delay: 0.2,
                        className: "bg-white p-6 text-center border border-slate-100 rounded-2xl shadow-sm",
                        children: [
                            /*#__PURE__*/ _jsxDEV("div", {
                                className: "w-16 h-16 mx-auto bg-blue-50 rounded-full flex items-center justify-center text-3xl mb-4 border-4 border-white shadow-md",
                                children: "📱"
                            }, void 0, false, {
                                fileName: "[project]/src/app/servicios/page.tsx",
                                lineNumber: 18,
                                columnNumber: 21
                            }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                            /*#__PURE__*/ _jsxDEV("h4", {
                                className: "font-bold text-brand-dark mb-2",
                                children: "2. Sube tus gastos"
                            }, void 0, false, {
                                fileName: "[project]/src/app/servicios/page.tsx",
                                lineNumber: 19,
                                columnNumber: 21
                            }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                            /*#__PURE__*/ _jsxDEV("p", {
                                className: "text-sm text-slate-500",
                                children: "Haz una foto a la factura o envíanos el PDF por WhatsApp/Email. Nosotros la contabilizamos al momento. Adiós a picar datos."
                            }, void 0, false, {
                                fileName: "[project]/src/app/servicios/page.tsx",
                                lineNumber: 20,
                                columnNumber: 21
                            }, /*TURBOPACK member replacement*/ __turbopack_context__.e)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/servicios/page.tsx",
                        lineNumber: 17,
                        columnNumber: 17
                    }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                    /*#__PURE__*/ _jsxDEV(FadeIn, {
                        delay: 0.3,
                        className: "bg-white p-6 text-center border border-slate-100 rounded-2xl shadow-sm",
                        children: [
                            /*#__PURE__*/ _jsxDEV("div", {
                                className: "w-16 h-16 mx-auto bg-blue-50 rounded-full flex items-center justify-center text-3xl mb-4 border-4 border-white shadow-md",
                                children: "👮"
                            }, void 0, false, {
                                fileName: "[project]/src/app/servicios/page.tsx",
                                lineNumber: 23,
                                columnNumber: 21
                            }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                            /*#__PURE__*/ _jsxDEV("h4", {
                                className: "font-bold text-brand-dark mb-2",
                                children: "3. Escudo Fiscal"
                            }, void 0, false, {
                                fileName: "[project]/src/app/servicios/page.tsx",
                                lineNumber: 24,
                                columnNumber: 21
                            }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                            /*#__PURE__*/ _jsxDEV("p", {
                                className: "text-sm text-slate-500",
                                children: "Un economista colegiado revisa todo antes de presentar. Si Hacienda pregunta, nosotros respondemos por ti."
                            }, void 0, false, {
                                fileName: "[project]/src/app/servicios/page.tsx",
                                lineNumber: 25,
                                columnNumber: 21
                            }, /*TURBOPACK member replacement*/ __turbopack_context__.e)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/servicios/page.tsx",
                        lineNumber: 22,
                        columnNumber: 17
                    }, /*TURBOPACK member replacement*/ __turbopack_context__.e)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/servicios/page.tsx",
                lineNumber: 8,
                columnNumber: 13
            }, /*TURBOPACK member replacement*/ __turbopack_context__.e)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/servicios/page.tsx",
        lineNumber: 3,
        columnNumber: 9
    }, /*TURBOPACK member replacement*/ __turbopack_context__.e)
}, void 0, false, {
    fileName: "[project]/src/app/servicios/page.tsx",
    lineNumber: 2,
    columnNumber: 7
}, /*TURBOPACK member replacement*/ __turbopack_context__.e);
{}/*#__PURE__*/ _jsxDEV("section", {
    id: "servicios",
    className: "py-24 bg-slate-50 border-y border-slate-200",
    children: /*#__PURE__*/ _jsxDEV("div", {
        className: "max-w-7xl mx-auto px-6",
        children: [
            /*#__PURE__*/ _jsxDEV(FadeIn, {
                direction: "up",
                children: /*#__PURE__*/ _jsxDEV("div", {
                    className: "text-center max-w-3xl mx-auto mb-16",
                    children: [
                        /*#__PURE__*/ _jsxDEV("h2", {
                            className: "text-sm font-bold text-brand-blue tracking-widest uppercase mb-2",
                            children: "Tarifas Claras"
                        }, void 0, false, {
                            fileName: "[project]/src/app/servicios/page.tsx",
                            lineNumber: 36,
                            columnNumber: 17
                        }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                        /*#__PURE__*/ _jsxDEV("h3", {
                            className: "text-3xl md:text-4xl font-extrabold text-brand-dark",
                            children: "Elige el plan que te da tranquilidad"
                        }, void 0, false, {
                            fileName: "[project]/src/app/servicios/page.tsx",
                            lineNumber: 37,
                            columnNumber: 17
                        }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                        /*#__PURE__*/ _jsxDEV("p", {
                            className: "text-slate-500 mt-4",
                            children: "Sin permanencia. Precios cerrados. Sin sorpresas a final de mes."
                        }, void 0, false, {
                            fileName: "[project]/src/app/servicios/page.tsx",
                            lineNumber: 38,
                            columnNumber: 17
                        }, /*TURBOPACK member replacement*/ __turbopack_context__.e)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/servicios/page.tsx",
                    lineNumber: 35,
                    columnNumber: 13
                }, /*TURBOPACK member replacement*/ __turbopack_context__.e)
            }, void 0, false, {
                fileName: "[project]/src/app/servicios/page.tsx",
                lineNumber: 34,
                columnNumber: 11
            }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
            /*#__PURE__*/ _jsxDEV("div", {
                className: "grid md:grid-cols-3 gap-8 items-start",
                children: [
                    /*#__PURE__*/ _jsxDEV(FadeIn, {
                        delay: 0.1,
                        className: "bg-white p-8 rounded-2xl shadow-sm hover:shadow-xl transition duration-300 border border-slate-200 relative overflow-hidden group flex flex-col",
                        children: [
                            /*#__PURE__*/ _jsxDEV("div", {
                                className: "absolute top-0 left-0 w-full bg-green-500 text-white text-[10px] font-bold text-center py-1 uppercase tracking-wider",
                                children: "¡Alta de Autónomo Gratis!"
                            }, void 0, false, {
                                fileName: "[project]/src/app/servicios/page.tsx",
                                lineNumber: 46,
                                columnNumber: 17
                            }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                            /*#__PURE__*/ _jsxDEV("div", {
                                className: "mt-4 w-14 h-14 bg-blue-50 rounded-xl flex items-center justify-center text-brand-blue mb-6 text-2xl group-hover:scale-110 transition",
                                children: "🚀"
                            }, void 0, false, {
                                fileName: "[project]/src/app/servicios/page.tsx",
                                lineNumber: 47,
                                columnNumber: 17
                            }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                            /*#__PURE__*/ _jsxDEV("h4", {
                                className: "text-xl font-bold text-brand-dark mb-2",
                                children: "Autónomos"
                            }, void 0, false, {
                                fileName: "[project]/src/app/servicios/page.tsx",
                                lineNumber: 48,
                                columnNumber: 17
                            }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                            /*#__PURE__*/ _jsxDEV("div", {
                                className: "text-4xl font-extrabold text-brand-blue mb-4",
                                children: [
                                    "59€",
                                    /*#__PURE__*/ _jsxDEV("span", {
                                        className: "text-base font-normal text-slate-400",
                                        children: "/mes"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/servicios/page.tsx",
                                        lineNumber: 49,
                                        columnNumber: 82
                                    }, /*TURBOPACK member replacement*/ __turbopack_context__.e)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/servicios/page.tsx",
                                lineNumber: 49,
                                columnNumber: 17
                            }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                            /*#__PURE__*/ _jsxDEV("p", {
                                className: "text-sm text-slate-500 mb-6 pb-6 border-b border-slate-100",
                                children: "Todo incluido para profesionales que quieren seguridad."
                            }, void 0, false, {
                                fileName: "[project]/src/app/servicios/page.tsx",
                                lineNumber: 50,
                                columnNumber: 17
                            }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                            /*#__PURE__*/ _jsxDEV("ul", {
                                className: "space-y-3 text-sm mb-8 flex-grow text-slate-600",
                                children: [
                                    /*#__PURE__*/ _jsxDEV("li", {
                                        className: "flex gap-2",
                                        children: [
                                            "✅ ",
                                            /*#__PURE__*/ _jsxDEV("strong", {
                                                children: "Alta en RETA y Hacienda incluida"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/servicios/page.tsx",
                                                lineNumber: 52,
                                                columnNumber: 50
                                            }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                                            "."
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/servicios/page.tsx",
                                        lineNumber: 52,
                                        columnNumber: 21
                                    }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                                    /*#__PURE__*/ _jsxDEV("li", {
                                        className: "flex gap-2",
                                        children: "✅ Modelos Trimestrales (IVA e IRPF)."
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/servicios/page.tsx",
                                        lineNumber: 53,
                                        columnNumber: 21
                                    }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                                    /*#__PURE__*/ _jsxDEV("li", {
                                        className: "flex gap-2",
                                        children: "✅ Libros de Ingresos y Gastos."
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/servicios/page.tsx",
                                        lineNumber: 54,
                                        columnNumber: 21
                                    }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                                    /*#__PURE__*/ _jsxDEV("li", {
                                        className: "flex gap-2",
                                        children: "✅ Asesor personal (WhatsApp directo)."
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/servicios/page.tsx",
                                        lineNumber: 55,
                                        columnNumber: 21
                                    }, /*TURBOPACK member replacement*/ __turbopack_context__.e)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/servicios/page.tsx",
                                lineNumber: 51,
                                columnNumber: 17
                            }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                            /*#__PURE__*/ _jsxDEV(Link, {
                                href: "/presupuesto",
                                className: "block w-full py-3 text-center font-bold text-brand-blue border-2 border-brand-blue rounded-xl hover:bg-brand-blue hover:text-white transition",
                                children: "Empezar Ahora"
                            }, void 0, false, {
                                fileName: "[project]/src/app/servicios/page.tsx",
                                lineNumber: 57,
                                columnNumber: 17
                            }, /*TURBOPACK member replacement*/ __turbopack_context__.e)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/servicios/page.tsx",
                        lineNumber: 45,
                        columnNumber: 13
                    }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                    /*#__PURE__*/ _jsxDEV(FadeIn, {
                        delay: 0.2,
                        className: "bg-white p-8 rounded-2xl shadow-2xl border-2 border-brand-blue relative transform md:-translate-y-4 flex flex-col",
                        children: [
                            /*#__PURE__*/ _jsxDEV("div", {
                                className: "absolute top-0 right-0 bg-brand-blue text-white text-xs font-bold px-3 py-1 rounded-bl-xl uppercase tracking-wide",
                                children: "Opción Recomendada"
                            }, void 0, false, {
                                fileName: "[project]/src/app/servicios/page.tsx",
                                lineNumber: 64,
                                columnNumber: 17
                            }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                            /*#__PURE__*/ _jsxDEV("div", {
                                className: "mt-2 w-14 h-14 bg-blue-100 rounded-xl flex items-center justify-center text-brand-blue mb-6 text-2xl",
                                children: "🏢"
                            }, void 0, false, {
                                fileName: "[project]/src/app/servicios/page.tsx",
                                lineNumber: 65,
                                columnNumber: 17
                            }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                            /*#__PURE__*/ _jsxDEV("h4", {
                                className: "text-xl font-bold text-brand-dark mb-2",
                                children: "Sociedades (S.L.)"
                            }, void 0, false, {
                                fileName: "[project]/src/app/servicios/page.tsx",
                                lineNumber: 66,
                                columnNumber: 17
                            }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                            /*#__PURE__*/ _jsxDEV("div", {
                                className: "text-4xl font-extrabold text-brand-dark mb-4",
                                children: [
                                    "190€",
                                    /*#__PURE__*/ _jsxDEV("span", {
                                        className: "text-base font-normal text-slate-400",
                                        children: "/mes"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/servicios/page.tsx",
                                        lineNumber: 67,
                                        columnNumber: 83
                                    }, /*TURBOPACK member replacement*/ __turbopack_context__.e)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/servicios/page.tsx",
                                lineNumber: 67,
                                columnNumber: 17
                            }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                            /*#__PURE__*/ _jsxDEV("p", {
                                className: "text-sm text-slate-500 mb-6 pb-6 border-b border-slate-100",
                                children: "Departamento financiero externo completo."
                            }, void 0, false, {
                                fileName: "[project]/src/app/servicios/page.tsx",
                                lineNumber: 68,
                                columnNumber: 17
                            }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                            /*#__PURE__*/ _jsxDEV("ul", {
                                className: "space-y-3 text-sm mb-8 flex-grow text-slate-700 font-medium",
                                children: [
                                    /*#__PURE__*/ _jsxDEV("li", {
                                        className: "flex gap-2",
                                        children: "✅ Contabilidad Analítica y Balances."
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/servicios/page.tsx",
                                        lineNumber: 70,
                                        columnNumber: 21
                                    }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                                    /*#__PURE__*/ _jsxDEV("li", {
                                        className: "flex gap-2",
                                        children: "✅ Impuesto Sociedades (200)."
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/servicios/page.tsx",
                                        lineNumber: 71,
                                        columnNumber: 21
                                    }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                                    /*#__PURE__*/ _jsxDEV("li", {
                                        className: "flex gap-2",
                                        children: "✅ Cuentas Anuales en el Registro."
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/servicios/page.tsx",
                                        lineNumber: 72,
                                        columnNumber: 21
                                    }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                                    /*#__PURE__*/ _jsxDEV("li", {
                                        className: "flex gap-2",
                                        children: [
                                            "✅ ",
                                            /*#__PURE__*/ _jsxDEV("strong", {
                                                children: "Nóminas incluidas"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/servicios/page.tsx",
                                                lineNumber: 73,
                                                columnNumber: 50
                                            }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                                            " (x3)."
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/servicios/page.tsx",
                                        lineNumber: 73,
                                        columnNumber: 21
                                    }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                                    /*#__PURE__*/ _jsxDEV("li", {
                                        className: "flex gap-2",
                                        children: "✅ Planificación Fiscal Pre-Cierre."
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/servicios/page.tsx",
                                        lineNumber: 74,
                                        columnNumber: 21
                                    }, /*TURBOPACK member replacement*/ __turbopack_context__.e)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/servicios/page.tsx",
                                lineNumber: 69,
                                columnNumber: 17
                            }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                            /*#__PURE__*/ _jsxDEV(Link, {
                                href: "/presupuesto",
                                className: "block w-full py-4 text-center font-bold text-white bg-brand-blue rounded-xl hover:bg-blue-700 transition shadow-lg",
                                children: "Solicitar Estudio"
                            }, void 0, false, {
                                fileName: "[project]/src/app/servicios/page.tsx",
                                lineNumber: 76,
                                columnNumber: 17
                            }, /*TURBOPACK member replacement*/ __turbopack_context__.e)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/servicios/page.tsx",
                        lineNumber: 63,
                        columnNumber: 13
                    }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                    /*#__PURE__*/ _jsxDEV(FadeIn, {
                        delay: 0.3,
                        className: "bg-brand-dark p-8 rounded-2xl shadow-lg text-white relative flex flex-col hover:-translate-y-2 transition duration-300",
                        children: [
                            /*#__PURE__*/ _jsxDEV("div", {
                                className: "w-14 h-14 bg-white/10 rounded-xl flex items-center justify-center text-white mb-6 text-2xl",
                                children: "₿"
                            }, void 0, false, {
                                fileName: "[project]/src/app/servicios/page.tsx",
                                lineNumber: 83,
                                columnNumber: 17
                            }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                            /*#__PURE__*/ _jsxDEV("h4", {
                                className: "text-xl font-bold text-white mb-2",
                                children: "Inversor Cripto"
                            }, void 0, false, {
                                fileName: "[project]/src/app/servicios/page.tsx",
                                lineNumber: 84,
                                columnNumber: 17
                            }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                            /*#__PURE__*/ _jsxDEV("div", {
                                className: "text-4xl font-extrabold text-brand-gold mb-4",
                                children: "A medida"
                            }, void 0, false, {
                                fileName: "[project]/src/app/servicios/page.tsx",
                                lineNumber: 85,
                                columnNumber: 17
                            }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                            /*#__PURE__*/ _jsxDEV("p", {
                                className: "text-sm text-slate-400 mb-6 pb-6 border-b border-white/10",
                                children: "Auditoría y regularización de carteras."
                            }, void 0, false, {
                                fileName: "[project]/src/app/servicios/page.tsx",
                                lineNumber: 86,
                                columnNumber: 17
                            }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                            /*#__PURE__*/ _jsxDEV("ul", {
                                className: "space-y-3 text-sm mb-8 flex-grow text-slate-300",
                                children: [
                                    /*#__PURE__*/ _jsxDEV("li", {
                                        className: "flex gap-2",
                                        children: "✅ Integración API CoinTracking / Koinly."
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/servicios/page.tsx",
                                        lineNumber: 88,
                                        columnNumber: 21
                                    }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                                    /*#__PURE__*/ _jsxDEV("li", {
                                        className: "flex gap-2",
                                        children: "✅ Cálculo FIFO de Ganancias."
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/servicios/page.tsx",
                                        lineNumber: 89,
                                        columnNumber: 21
                                    }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                                    /*#__PURE__*/ _jsxDEV("li", {
                                        className: "flex gap-2",
                                        children: [
                                            "✅ ",
                                            /*#__PURE__*/ _jsxDEV("strong", {
                                                children: "Modelo 721"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/servicios/page.tsx",
                                                lineNumber: 90,
                                                columnNumber: 50
                                            }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                                            " y Patrimonio."
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/servicios/page.tsx",
                                        lineNumber: 90,
                                        columnNumber: 21
                                    }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                                    /*#__PURE__*/ _jsxDEV("li", {
                                        className: "flex gap-2",
                                        children: "✅ Staking, DeFi, Pools y NFTs."
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/servicios/page.tsx",
                                        lineNumber: 91,
                                        columnNumber: 21
                                    }, /*TURBOPACK member replacement*/ __turbopack_context__.e)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/servicios/page.tsx",
                                lineNumber: 87,
                                columnNumber: 17
                            }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                            /*#__PURE__*/ _jsxDEV(Link, {
                                href: "/guia-cripto",
                                className: "block w-full py-3 text-center font-bold text-brand-dark bg-brand-gold rounded-xl hover:bg-white transition",
                                children: "Ver Servicios Cripto"
                            }, void 0, false, {
                                fileName: "[project]/src/app/servicios/page.tsx",
                                lineNumber: 93,
                                columnNumber: 17
                            }, /*TURBOPACK member replacement*/ __turbopack_context__.e)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/servicios/page.tsx",
                        lineNumber: 82,
                        columnNumber: 13
                    }, /*TURBOPACK member replacement*/ __turbopack_context__.e)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/servicios/page.tsx",
                lineNumber: 42,
                columnNumber: 11
            }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
            /*#__PURE__*/ _jsxDEV(FadeIn, {
                delay: 0.4,
                className: "mt-16 mx-auto max-w-2xl bg-blue-50 border border-blue-100 p-6 rounded-2xl text-center",
                children: [
                    /*#__PURE__*/ _jsxDEV("h4", {
                        className: "text-brand-blue font-bold text-lg mb-2 flex items-center justify-center gap-2",
                        children: "🛡️ Garantía de Satisfacción 30 Días"
                    }, void 0, false, {
                        fileName: "[project]/src/app/servicios/page.tsx",
                        lineNumber: 101,
                        columnNumber: 13
                    }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                    /*#__PURE__*/ _jsxDEV("p", {
                        className: "text-slate-600 text-sm",
                        children: [
                            "Estamos tan seguros de nuestro servicio que, si durante el primer mes no estás satisfecho con la gestión o el trato recibido, ",
                            /*#__PURE__*/ _jsxDEV("strong", {
                                children: "te devolvemos la cuota mensual íntegra"
                            }, void 0, false, {
                                fileName: "[project]/src/app/servicios/page.tsx",
                                lineNumber: 105,
                                columnNumber: 143
                            }, /*TURBOPACK member replacement*/ __turbopack_context__.e),
                            ". Sin preguntas."
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/servicios/page.tsx",
                        lineNumber: 104,
                        columnNumber: 13
                    }, /*TURBOPACK member replacement*/ __turbopack_context__.e)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/servicios/page.tsx",
                lineNumber: 100,
                columnNumber: 11
            }, /*TURBOPACK member replacement*/ __turbopack_context__.e)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/servicios/page.tsx",
        lineNumber: 33,
        columnNumber: 9
    }, /*TURBOPACK member replacement*/ __turbopack_context__.e)
}, void 0, false, {
    fileName: "[project]/src/app/servicios/page.tsx",
    lineNumber: 32,
    columnNumber: 7
}, /*TURBOPACK member replacement*/ __turbopack_context__.e);
}),
"[project]/src/app/servicios/page.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/servicios/page.tsx [app-rsc] (ecmascript)"));
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__acb46797._.js.map