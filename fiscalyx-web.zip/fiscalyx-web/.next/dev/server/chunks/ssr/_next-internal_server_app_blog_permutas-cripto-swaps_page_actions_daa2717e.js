module.exports = [
"[project]/.next-internal/server/app/blog/permutas-cripto-swaps/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_blog_permutas-cripto-swaps_page_actions_daa2717e.js.map