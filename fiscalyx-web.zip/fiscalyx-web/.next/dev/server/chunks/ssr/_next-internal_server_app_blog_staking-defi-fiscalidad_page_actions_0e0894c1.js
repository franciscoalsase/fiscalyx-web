module.exports = [
"[project]/.next-internal/server/app/blog/staking-defi-fiscalidad/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_blog_staking-defi-fiscalidad_page_actions_0e0894c1.js.map