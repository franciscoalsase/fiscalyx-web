module.exports = [
"[project]/.next-internal/server/app/cockpit/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_cockpit_page_actions_925cd066.js.map