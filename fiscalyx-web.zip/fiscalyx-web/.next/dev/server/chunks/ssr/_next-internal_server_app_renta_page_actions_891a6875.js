module.exports = [
"[project]/.next-internal/server/app/renta/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_renta_page_actions_891a6875.js.map