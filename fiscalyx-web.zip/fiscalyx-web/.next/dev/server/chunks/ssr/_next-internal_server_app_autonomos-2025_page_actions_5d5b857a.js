module.exports = [
"[project]/.next-internal/server/app/autonomos-2025/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_autonomos-2025_page_actions_5d5b857a.js.map