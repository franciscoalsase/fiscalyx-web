module.exports = [
"[project]/.next-internal/server/app/blog/autonomo-vs-sociedad/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_blog_autonomo-vs-sociedad_page_actions_d249a812.js.map