module.exports = [
"[project]/.next-internal/server/app/blog/modelo-721-criptomonedas-guia/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=ce889_server_app_blog_modelo-721-criptomonedas-guia_page_actions_1790cc37.js.map