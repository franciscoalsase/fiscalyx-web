module.exports = [
"[project]/.next-internal/server/app/contratar/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_contratar_page_actions_b2ec4303.js.map