module.exports = [
"[project]/.next-internal/server/app/blog/cuota-autonomos-2025/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_blog_cuota-autonomos-2025_page_actions_ebecaf97.js.map