module.exports = [
"[project]/.next-internal/server/app/guia-cripto/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_guia-cripto_page_actions_e75dd244.js.map