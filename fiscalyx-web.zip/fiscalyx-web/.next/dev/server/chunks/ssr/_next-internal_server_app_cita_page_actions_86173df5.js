module.exports = [
"[project]/.next-internal/server/app/cita/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_cita_page_actions_86173df5.js.map