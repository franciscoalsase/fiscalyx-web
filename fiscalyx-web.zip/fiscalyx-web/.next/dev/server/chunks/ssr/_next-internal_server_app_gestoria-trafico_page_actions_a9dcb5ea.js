module.exports = [
"[project]/.next-internal/server/app/gestoria-trafico/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_gestoria-trafico_page_actions_a9dcb5ea.js.map