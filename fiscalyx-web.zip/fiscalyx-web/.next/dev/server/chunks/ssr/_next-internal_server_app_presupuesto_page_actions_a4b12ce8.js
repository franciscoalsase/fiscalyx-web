module.exports = [
"[project]/.next-internal/server/app/presupuesto/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_presupuesto_page_actions_a4b12ce8.js.map